--
-- PostgreSQL database dump
--

\restrict nrSJjLQGb5xgRvqDsaWwKT1CeHj6o7BY1IpuNVupkqCAvyRVaWUwuJ0l1J10nSE

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA extensions;


--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql;


--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql_public;


--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA vault;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text,
	negate boolean
);


--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: -
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: ActivityLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ActivityLog" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "userName" text NOT NULL,
    "userColor" text NOT NULL,
    action text NOT NULL,
    entity text NOT NULL,
    "entityName" text NOT NULL,
    "entityId" text,
    "timestamp" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: BudgetLine; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BudgetLine" (
    id text NOT NULL,
    site text NOT NULL,
    brands text[],
    entries jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Campaign; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Campaign" (
    id text NOT NULL,
    name text NOT NULL,
    site text NOT NULL,
    service text[],
    type text NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "budgetPlanned" double precision NOT NULL,
    status text NOT NULL,
    roi double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ChatConversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ChatConversation" (
    id text NOT NULL,
    type text NOT NULL,
    participants text[],
    "adminIds" text[] DEFAULT ARRAY[]::text[],
    name text,
    "pinnedBy" text[] DEFAULT ARRAY[]::text[],
    "lastMessage" text,
    "lastMessageAt" timestamp(3) without time zone,
    "unreadCounts" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "mutedBy" text[] DEFAULT ARRAY[]::text[],
    "avatarUrl" text
);


--
-- Name: ChatMessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ChatMessage" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    "senderId" text NOT NULL,
    "senderName" text NOT NULL,
    "senderColor" text NOT NULL,
    content text NOT NULL,
    type text NOT NULL,
    "timestamp" timestamp(3) without time zone NOT NULL,
    edited boolean DEFAULT false NOT NULL,
    "editedAt" timestamp(3) without time zone,
    deleted boolean DEFAULT false NOT NULL,
    reactions jsonb DEFAULT '{}'::jsonb NOT NULL,
    "replyToId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "fileExpiredAt" timestamp(3) without time zone,
    "fileName" text,
    "fileSize" integer
);


--
-- Name: Contact; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Contact" (
    id text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    site text NOT NULL,
    service text NOT NULL,
    type text NOT NULL,
    "rgpdConsent" boolean NOT NULL,
    tags text[],
    "lastContactDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: DigitalTags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DigitalTags" (
    id text NOT NULL,
    networks text[],
    co2 text[]
);


--
-- Name: Equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Equipment" (
    id text NOT NULL,
    name text NOT NULL,
    "totalQuantity" integer NOT NULL,
    category text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: EquipmentBooking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EquipmentBooking" (
    id text NOT NULL,
    "equipmentId" text NOT NULL,
    quantity integer NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    site text NOT NULL,
    service text NOT NULL,
    brand text NOT NULL,
    description text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: FixedExpense; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FixedExpense" (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    service text NOT NULL,
    site text NOT NULL,
    sites text[] DEFAULT ARRAY[]::text[],
    "budgetDistribution" jsonb,
    comment text NOT NULL,
    amount double precision NOT NULL,
    brand text,
    brands text[] DEFAULT ARRAY[]::text[],
    "alpineShare" double precision,
    "proPlus" boolean DEFAULT false NOT NULL,
    "isAnnual" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "nissanShare" double precision
);


--
-- Name: GameChallenge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."GameChallenge" (
    id text NOT NULL,
    "fromUserId" text NOT NULL,
    "toUserId" text NOT NULL,
    game text NOT NULL,
    status text NOT NULL,
    "sessionId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: GameSession; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."GameSession" (
    id text NOT NULL,
    game text NOT NULL,
    "player1Id" text NOT NULL,
    "player2Id" text NOT NULL,
    "currentTurn" text NOT NULL,
    board jsonb NOT NULL,
    status text NOT NULL,
    "winnerId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: OneOffExpense; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."OneOffExpense" (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    service text NOT NULL,
    site text NOT NULL,
    comment text,
    amount double precision NOT NULL,
    "proPlus" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Project" (
    id text NOT NULL,
    name text NOT NULL,
    site text NOT NULL,
    sites text[] DEFAULT ARRAY[]::text[],
    "budgetDistribution" jsonb,
    service text[],
    brands text[],
    "projectType" text NOT NULL,
    status text NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "budgetPlanned" double precision NOT NULL,
    "budgetActual" double precision NOT NULL,
    description text NOT NULL,
    progress double precision NOT NULL,
    "assignedUsers" text[] DEFAULT ARRAY[]::text[],
    "alpineShare" double precision,
    "proPlus" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "nissanShare" double precision
);


--
-- Name: PushSubscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PushSubscription" (
    id text NOT NULL,
    "userId" text NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    "userAgent" text DEFAULT ''::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: SocialPost; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SocialPost" (
    id text NOT NULL,
    title text NOT NULL,
    status text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    targets text[],
    brands text[],
    service text NOT NULL,
    networks text[],
    concessions text[],
    "mediaFiles" text[],
    link text NOT NULL,
    wording text NOT NULL,
    lom text NOT NULL,
    co2 text NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "archivedAt" timestamp(3) without time zone
);


--
-- Name: Task; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Task" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    name text NOT NULL,
    provider text,
    channel text NOT NULL,
    cost double precision NOT NULL,
    status text NOT NULL,
    "assignedUserId" text,
    volumetry double precision,
    "openRate" double precision,
    "npaiRate" double precision,
    "stopRate" double precision,
    "clickRate" double precision,
    "codTxt" text,
    "billedAmount" double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "loginId" text NOT NULL,
    "passwordHash" text NOT NULL,
    name text NOT NULL,
    role text NOT NULL,
    "avatarColor" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "avatarUrl" text,
    birthdate text,
    sites text[] DEFAULT ARRAY[]::text[]
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea
)
PARTITION BY RANGE (inserted_at);


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: ActivityLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ActivityLog" (id, "userId", "userName", "userColor", action, entity, "entityName", "entityId", "timestamp", "createdAt") FROM stdin;
582f60f2-9094-4022-81bf-ae189b2ed666	46dcf78a-a158-4a4a-a064-52a843ddb935	Claire Richard	#bb7f84	a créé le projet	project	testing2	la24fifjy	2026-07-08 15:34:24.152	2026-07-08 15:34:24.615
d3866849-e0c9-4d34-ad23-5563cdc95845	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	OP TEST	izpyi6qtt	2026-07-08 15:43:12.777	2026-07-08 15:43:13.232
f5ed56e8-e6d9-43c7-97b4-5f29473010d7	b91965d9-5dfe-4b54-8306-7a3ca846c53d	Christian Charlier	#11b7dc	a créé le projet	project	testing v2	v8nb69n56	2026-07-08 16:04:58.064	2026-07-08 16:04:58.364
6a0f885c-39d4-4c87-a43f-721b0254ed78	46dcf78a-a158-4a4a-a064-52a843ddb935	Claire Richard	#bb7f84	a créé le projet	project	hhhhhhh	nqo5pyj4u	2026-07-08 16:05:33.069	2026-07-08 16:05:33.365
a76aabe2-7756-4367-963c-d594c2c7272a	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	test test	lfpaabgal	2026-07-09 07:08:58.972	2026-07-09 07:08:58.478
fb9f098a-1c93-45f8-ae71-70e8c9565395	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	123456	qed8mag19	2026-07-09 07:14:42.619	2026-07-09 07:14:42.129
114dd3fc-913a-4cfd-bc6e-483a9c0488a8	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé le projet	project	CCDMD 2026	9mzb33smo	2026-07-09 07:21:08.2	2026-07-09 07:21:08.087
e353a198-7617-48a4-9a4e-e00f0cb95f75	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a archivé le projet	project	123456	qed8mag19	2026-07-09 14:34:15.893	2026-07-09 14:34:15.889
642dec46-b6ac-4985-a7db-c1375d7b95f0	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	RELANCE TEL SEPT - PLAQUE NORD	9ru0q219z	2026-07-09 14:36:34.092	2026-07-09 14:36:34.089
88fd7d31-6164-441b-8610-09294b576e25	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	hhhhhhh	nqo5pyj4u	2026-07-09 14:40:32.452	2026-07-09 14:40:32.358
2b6bb935-a868-4181-97b7-6619a6d7e69d	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	testing v2	v8nb69n56	2026-07-09 14:40:36.002	2026-07-09 14:40:35.849
7d15fc0a-9b82-4cf7-ac73-5008df0abb3b	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	test	f7rncs6cy	2026-07-09 14:40:39.376	2026-07-09 14:40:39.182
836d5b88-7354-4229-bd25-294be767bad8	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	testing2	la24fifjy	2026-07-09 14:40:44.015	2026-07-09 14:40:43.855
703876dc-5985-433f-9119-1016933117ec	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	OP TEST	izpyi6qtt	2026-07-09 14:40:50.462	2026-07-09 14:40:50.291
3ccb9b00-ca7a-4dd0-9c5c-10884fe3ac71	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	Test	mczkmrfhp	2026-07-09 14:40:54.353	2026-07-09 14:40:54.191
386bf403-f5fe-4506-9ed5-ade597b0f29e	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	test test	lfpaabgal	2026-07-09 14:40:59.026	2026-07-09 14:40:58.855
20a2fecb-024a-406a-b965-66d09139da89	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a supprimé le projet	project	RELANCE TEL SEPT - PLAQUE NORD	9ru0q219z	2026-07-09 14:41:01.741	2026-07-09 14:41:01.736
b4bf16fe-120d-4a14-9f3a-d11de48f51eb	af47c934-5e71-4adf-9a0a-92f966af2fdc	Hugo Culetto	#e9202c	a supprimé la publication	post	PUBLICATION BONY	sp-1776345726359	2026-07-09 14:50:02.478	2026-07-09 14:50:01.795
2851a7fc-6a0a-4489-94d8-0d2037d613cf	af47c934-5e71-4adf-9a0a-92f966af2fdc	Hugo Culetto	#e9202c	a supprimé la publication	post	Lancement R5 E-Tech	sp-1	2026-07-09 14:50:14.703	2026-07-09 14:50:14.057
b9decb6d-65ad-4796-8216-0054b6fbd7a7	af47c934-5e71-4adf-9a0a-92f966af2fdc	Hugo Culetto	#e9202c	a supprimé la publication	post	Offre Pneus Hiver	sp-2	2026-07-09 14:50:15.97	2026-07-09 14:50:15.324
9441ba93-04bd-4ca6-ad71-258092fad0b4	af47c934-5e71-4adf-9a0a-92f966af2fdc	Hugo Culetto	#e9202c	a supprimé la publication	post	Oui	sp-1776004881954	2026-07-09 14:50:17.45	2026-07-09 14:50:16.779
3e49a6af-7994-4640-9a4b-5b9f53a41c2b	af47c934-5e71-4adf-9a0a-92f966af2fdc	Hugo Culetto	#e9202c	a supprimé la publication	post	Lancement Twingo	sp-1776200834676	2026-07-09 14:50:18.495	2026-07-09 14:50:17.82
a7148f41-a65a-4b09-a147-92ecf8d220a6	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	TEST 3	2ob6mxss6	2026-07-09 14:50:50.429	2026-07-09 14:50:50.283
27a0aabf-63a9-410e-8a3a-756adfa86792	af47c934-5e71-4adf-9a0a-92f966af2fdc	Hugo Culetto	#e9202c	a créé la publication	post	TEST	10f0defa-ee67-435d-adec-fc1b6d2b80e6	2026-07-09 14:53:44.732	2026-07-09 14:53:44.056
852a9d99-700b-4c35-8083-17d36c6a5155	af47c934-5e71-4adf-9a0a-92f966af2fdc	Hugo Culetto	#e9202c	a supprimé la publication	post	TEST	10f0defa-ee67-435d-adec-fc1b6d2b80e6	2026-07-09 14:55:13.252	2026-07-09 14:55:12.574
fa424b2f-19d7-4ab0-bd3c-7fbd70dac824	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé le projet	project	SPORT & COLLECTION MDC	ztbds4ocd	2026-07-09 14:59:40.178	2026-07-09 14:59:40.011
ba286d9d-fbd9-4a97-be02-100ddaae8a24	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé le projet	project	TRACK DAY MDC	nueo5aojt	2026-07-09 15:01:21.73	2026-07-09 15:01:21.565
f19c71a5-b788-4108-a204-18b0fe2764df	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé le projet	project	BITE	iircbxziu	2026-07-29 14:14:55.368	2026-07-29 14:14:54.316
831207ec-26a2-4426-b628-e8932f603cf1	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé une réservation matériel	booking	Chaises	\N	2026-07-29 14:15:34.354	2026-07-29 14:15:33.298
f0398103-9c4a-43b6-87e2-0bbb16accc10	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	BITE	iircbxziu	2026-07-29 14:16:47.661	2026-07-29 14:16:46.602
0e073ee4-667d-4245-9547-cd7d0574463f	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	projet : visite ateliers Issoire	vpbv5diry	2026-08-04 12:24:31.501	2026-08-04 12:24:31.541
9a80c623-9298-4aae-9a5d-36e2ea4491d2	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé le projet	project	Afterwork Urban Padel	chkbg2n0z	2026-08-04 14:24:33.318	2026-08-04 14:24:33.417
ce7c7a38-139c-438d-9d65-29bdccc3b2d4	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé le projet	project	GT4 MANCHE NOGARO	prqp8174t	2026-08-04 14:36:41.698	2026-08-04 14:36:41.767
32c852f5-8ad0-449c-bebe-30a54d77d961	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	projet : track day mas du clos	5a59bdab-7443-41a8-815f-d6c4aadf67cf	2026-08-04 15:06:35.792	2026-08-04 15:06:35.9
b40d5869-2559-40c2-88ee-2ca58864eb50	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	projet : alpine bony cars & coffee	1fc26749-657f-4bc7-a6d3-1a92155df5de	2026-08-04 15:25:07.106	2026-08-04 15:25:07.239
d060ee32-4085-4858-9509-7fa39c730538	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a supprimé le projet	project	projet : conf de presse CCDMD	5a2a64aa-af1e-4941-b53d-b8715f2cd056	2026-08-04 15:25:17.494	2026-08-04 15:25:17.627
ed60a5eb-3da8-4f9e-baf4-c76ef29af95f	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé le projet	project	BLUE TOUR RODEZ	2du8uofbb	2026-08-04 15:26:30.18	2026-08-04 15:26:30.309
7d1adb0f-1380-44f3-9a4b-ed8a0089a696	b91965d9-5dfe-4b54-8306-7a3ca846c53d	Christian Charlier	#11b7dc	a modifié l'utilisateur	user	Christian Charlier	\N	2026-08-05 09:40:30.04	2026-08-05 09:40:30.202
de1c8d2d-8bb8-4bb1-87b9-ea38487fe9e9	b91965d9-5dfe-4b54-8306-7a3ca846c53d	Christian Charlier	#11b7dc	a modifié l'utilisateur	user	Christian Charlier	\N	2026-08-05 09:40:38.28	2026-08-05 09:40:38.429
18ae73dc-d594-4b1e-a775-aee5bee3352b	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé une réservation matériel	booking	Desk Bony	\N	2026-08-05 12:22:14.293	2026-08-05 12:22:14.338
9feadf49-da0b-4824-ae68-439b9da88c3d	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé une réservation matériel	booking	Mur d'image	\N	2026-08-05 12:22:40.904	2026-08-05 12:22:40.941
6d7722c1-cfa9-4f6d-a1a4-cabfb34a9b26	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé une réservation matériel	booking	Enceinte JBL	\N	2026-08-05 12:23:08.952	2026-08-05 12:23:08.992
c64d618f-2e9f-452b-86a4-15b62f8619f9	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé le projet	project	SPORT & COLLECTION MDC	qz1og9akw	2026-08-06 07:12:31.805	2026-08-06 07:12:31.908
438da24d-2ca3-4943-ba02-36b772340d32	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé le projet	project	SOIREE ASM EN MELEE	4axlcln2x	2026-08-06 07:13:45.711	2026-08-06 07:13:45.78
1413f4e1-41f4-400e-9ce8-f82a5b3afad2	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé le projet	project	SOIREE ASM EN MELEE	l2t8lq4w0	2026-08-06 07:14:53.594	2026-08-06 07:14:53.67
552c8359-c8f3-4d6f-a08f-74f517b8da7f	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	OPO SEPTEMBRE 2026 ALLIER	nxo8lv1u7	2026-08-06 08:02:03.027	2026-08-06 08:02:03.089
9a7973e1-e763-44d5-94e6-f22b9ccaa254	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	VA LE PUY	h6k4gojow	2026-08-06 08:15:06.426	2026-08-06 08:15:06.486
314720cc-faf0-49be-a84a-dbf72a519886	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	a créé le projet	project	Rallye BONY X CMV	g7el0wb3r	2026-08-06 12:50:08.359	2026-08-06 12:50:08.776
544854d4-f4c7-4e03-b67a-f1573fac67fa	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	VA THIERS	4aly4336l	2026-08-06 13:08:38.476	2026-08-06 13:08:38.896
f6421b5d-3561-4a5e-990d-24fe7db324ac	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	VP ISSOIRE	tlquwi84i	2026-08-06 15:20:49.461	2026-08-06 15:20:49.591
9c5d4928-6540-4e56-8f54-8fec578b1f97	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	VA VICHY	6inl5fk7a	2026-08-06 15:22:24.906	2026-08-06 15:22:25.057
20bce273-4420-4576-a269-d5dec4b8579b	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	VP MOULINS	cp06bw9xn	2026-08-06 15:26:10.525	2026-08-06 15:26:10.656
e5bdd95e-9c6a-4afa-882f-e64b2a82ee19	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	VP VICHY	yv84rs9gz	2026-08-06 15:26:48.785	2026-08-06 15:26:48.915
84558532-a3fd-4e4c-a712-42f671ccb65f	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	VP THIERS	e085c0ap2	2026-08-06 15:27:26.755	2026-08-06 15:27:26.914
a3fa3048-156d-4d78-924a-2367c13b5d1f	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	VP LE PUY	b16banc0f	2026-08-06 15:28:00.362	2026-08-06 15:28:00.49
880ff3b4-5d19-4196-9653-73e0f8685dbd	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	VP LE PUY	du1hkirq6	2026-08-06 15:29:52.604	2026-08-06 15:29:52.744
29fbe23e-0f90-4a84-8950-38a14d95bc1f	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	DACIA STRIKER	pxt0m6c2c	2026-08-07 07:53:18.554	2026-08-07 07:53:17.342
4c777752-f2ef-4b52-9584-801ff4d27018	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	DACIA STRIKER - VICHY	j00la0b7t	2026-08-07 07:54:01.674	2026-08-07 07:54:00.455
59679db0-92b1-4a05-8af2-50b9e22ec28b	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	a créé le projet	project	CAMPAGNE SMS CT 39€ ISSOIRE	or83seebd	2026-08-07 08:31:50.315	2026-08-07 08:31:49.11
\.


--
-- Data for Name: BudgetLine; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BudgetLine" (id, site, brands, entries, "createdAt", "updatedAt") FROM stdin;
2973748b-b6fb-4bed-b596-8d5a269318b6	Aurillac	{Renault,Dacia,Mobilize}	{"PR": [250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250], "VN": [2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500], "VO": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000], "APV": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000]}	2026-07-07 21:42:51.161	2026-08-03 16:18:59.086
8b9a3494-dc25-4604-a0aa-6676f7afcce7	Figeac	{Renault,Dacia,Mobilize}	{"PR": [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200], "VN": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000], "VO": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000], "APV": [300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300]}	2026-07-07 21:42:53.475	2026-08-03 16:19:02.738
e07c1d2c-7ea8-45e2-9f69-268f8ef7074e	Alpine-Rodez	{Alpine}	{"PR": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VN": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VO": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "APV": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}	2026-07-07 21:42:49.832	2026-08-03 16:19:07.073
cf98b636-4e41-4500-a8a4-3ee25bee383c	Carmaux	{Renault,Dacia,Mobilize}	{"PR": [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200], "VN": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VO": [1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250], "APV": [300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300]}	2026-07-07 21:42:52.202	2026-08-03 16:19:03.437
d5aee222-90ce-4925-8acd-49e0a5a813af	Brioude	{Renault,Dacia,Mobilize}	{"PR": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VN": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VO": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "APV": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}	2026-07-07 21:42:51.675	2026-07-07 21:42:52.572
17b7a6ef-1087-47b9-83b5-c5b6bdbb88e7	Alpine-Le Puy	{Alpine}	{"PR": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VN": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VO": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "APV": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}	2026-07-07 21:42:49.317	2026-08-03 16:19:06.422
8d9f2856-0b3b-4ba2-a0d7-2bc81acce00d	Alpine-Clermont	{Alpine}	{"PR": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VN": [10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000], "VO": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "APV": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}	2026-07-07 21:42:48.555	2026-08-03 16:18:54.537
c5bb68a5-4cac-4210-80fd-dd49b162f6d1	Albi	{Renault,Dacia,Mobilize}	{"PR": [250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250], "VN": [2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500], "VO": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000], "APV": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000]}	2026-07-07 21:42:48.011	2026-08-03 16:18:57.636
52ee38b5-c4ec-4be8-a952-5777398a545d	Alpine-Vichy	{Alpine}	{"PR": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VN": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VO": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "APV": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}	2026-07-07 21:42:50.375	2026-08-03 16:19:05.641
3198b321-cd75-41cf-afd5-29d43222a5bc	Massagettes	{Renault,Dacia,Mobilize}	{"PR": [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200], "VN": [1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250], "VO": [1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500], "APV": [500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500]}	2026-07-07 21:42:56.76	2026-08-03 16:18:52.353
8fc7a025-04a4-4ff7-a3c1-8cf72b0f5097	Mende	{Renault,Dacia,Mobilize}	{"PR": [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200], "VN": [1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250], "VO": [1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500], "APV": [500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500]}	2026-07-07 21:42:57.306	2026-08-03 16:18:56.026
a7a7d8ed-64b0-43b9-8462-4bf5fc970c27	Millau	{Renault,Dacia,Mobilize}	{"PR": [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200], "VN": [1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250], "VO": [1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250], "APV": [500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500]}	2026-07-07 21:42:57.853	2026-08-03 16:19:00.553
eaee273e-1ebf-4df8-b69c-e89ee81e6b6b	Lavaur	{Renault,Dacia,Mobilize}	{"PR": [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200], "VN": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VO": [750, 750, 750, 750, 750, 750, 750, 750, 750, 750, 750, 750], "APV": [300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300]}	2026-07-07 21:42:55.559	2026-08-03 16:19:01.32
42f80f39-09cd-4a09-8553-bc394b60f6fb	Clermont	{Renault,Dacia,Mobilize}	{"PR": [5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000, 5000], "VN": [12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000, 12000], "VO": [7000, 7000, 7000, 7000, 7000, 7000, 7000, 7000, 7000, 7000, 7000, 7000], "APV": [3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000]}	2026-07-07 21:42:52.93	2026-08-03 16:18:50.753
52fa33de-a8ee-4ec6-8449-019a8b38c413	Issoire	{Renault,Dacia,Mobilize}	{"PR": [250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250], "VN": [2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500], "VO": [2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500], "APV": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000]}	2026-07-07 21:42:54.706	2026-08-03 16:18:53.845
6de6103b-9ca7-443a-a7b2-bb67c1a09a31	Ricoux	{Renault,Dacia,Mobilize}	{"PR": [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200], "VN": [1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500], "VO": [1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500], "APV": [500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500]}	2026-07-07 21:43:00.212	2026-08-03 16:19:04.188
e75a7b1b-9c27-410e-b432-70fa50a40af3	Nissan	{Nissan}	{"PR": [250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250], "VN": [2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500], "VO": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000], "APV": [300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300]}	2026-07-07 21:42:59.706	2026-08-03 16:19:04.939
fa37532d-52d1-4a8a-b33e-994923793c97	Mozac	{Renault,Dacia,Mobilize}	{"PR": [300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300], "VN": [2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500], "VO": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000], "APV": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000]}	2026-07-07 21:42:59.166	2026-08-03 16:18:51.437
ade46e68-8777-456c-8180-6bcb526fb2e1	Vichy	{Renault,Dacia,Mobilize}	{"PR": [500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500], "VN": [3250, 3250, 3250, 3250, 3250, 3250, 3250, 3250, 3250, 3250, 3250, 3250], "VO": [3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000], "APV": [1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500]}	2026-07-07 21:43:02.171	2026-08-03 16:18:44.948
3c3ef01c-a0fe-4c90-9be8-e77050eb325d	Le Puy-en-Velay	{Renault,Dacia,Mobilize}	{"PR": [500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500], "VN": [3500, 3500, 3500, 3500, 3500, 3500, 3500, 3500, 3500, 3500, 3500, 3500], "VO": [2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500, 2500], "APV": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000]}	2026-07-07 21:42:56.136	2026-08-03 16:18:55.303
83fa609c-640c-4834-9eba-f9f34b6b76a6	Gaillac	{Renault,Dacia,Mobilize}	{"PR": [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200], "VN": [1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250], "VO": [1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250], "APV": [500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500]}	2026-07-07 21:42:54.176	2026-08-03 16:18:59.854
c69d8f54-bdb3-48b1-8d9f-9cdb735ace20	Rodez	{Renault,Dacia,Mobilize}	{"PR": [500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500], "VN": [3250, 3250, 3250, 3250, 3250, 3250, 3250, 3250, 3250, 3250, 3250, 3250], "VO": [3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000], "APV": [1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500]}	2026-07-07 21:43:00.997	2026-08-03 16:18:58.437
982de66c-d626-4ae1-b83f-f7296c1f5973	Villefranche	{Renault,Dacia,Mobilize}	{"PR": [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200], "VN": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "VO": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000], "APV": [300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300]}	2026-07-07 21:43:02.773	2026-08-03 16:19:01.987
855071dc-8c26-4f3a-8ce8-631b6fc58d36	Moulins	{Renault,Dacia,Mobilize}	{"PR": [350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350, 350], "VN": [3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000, 3000], "VO": [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000], "APV": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000]}	2026-07-07 21:42:58.456	2026-08-03 16:18:47.57
45f75750-e5ab-4816-a182-61ed09458b0d	Ussel	{Renault,Dacia,Mobilize}	{"PR": [200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200, 200], "VN": [1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250, 1250], "VO": [1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500, 1500], "APV": [500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500]}	2026-07-07 21:43:01.626	2026-08-03 16:18:53.088
\.


--
-- Data for Name: Campaign; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Campaign" (id, name, site, service, type, "startDate", "endDate", "budgetPlanned", status, roi, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ChatConversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ChatConversation" (id, type, participants, "adminIds", name, "pinnedBy", "lastMessage", "lastMessageAt", "unreadCounts", "createdAt", "updatedAt", "mutedBy", "avatarUrl") FROM stdin;
a2438c4b-3ef0-44ce-81f7-cbca26f9ad15	private	{3939fc4c-1695-43de-887a-f36aa87363fb,15025839-a51c-4bf2-8cff-703d5e7be91c}	{}	\N	{}	📷 Image	2026-07-31 09:21:08.523	{"15025839-a51c-4bf2-8cff-703d5e7be91c": 0, "3939fc4c-1695-43de-887a-f36aa87363fb": 0}	2026-07-31 09:20:20.651	2026-08-03 13:00:31.416	{}	\N
acda278a-1898-4b16-8474-f45900f3faf7	private	{3939fc4c-1695-43de-887a-f36aa87363fb,744a1e04-b73b-4d48-b2b3-bc290a14ec80}	{}	\N	{}	appelle moi quand t'as 2min	2026-08-04 07:29:42.223	{"3939fc4c-1695-43de-887a-f36aa87363fb": 0, "744a1e04-b73b-4d48-b2b3-bc290a14ec80": 0}	2026-07-08 15:49:57.148	2026-08-06 15:30:36.258	{}	\N
0094fccc-5556-42c2-a69d-a3f593c21f29	private	{e14f87c3-cc26-4be1-97c6-2799600d6ccd,eb92e149-0fa4-4ffe-a2eb-bd8e74c6d50d}	{}	\N	{}	Bonjour B	2026-07-08 10:41:47.095	{"eb92e149-0fa4-4ffe-a2eb-bd8e74c6d50d": 0}	2026-07-08 10:41:45.598	2026-07-08 10:41:48.097	{}	\N
48cd49b2-e671-429f-b415-47b583640b98	private	{3939fc4c-1695-43de-887a-f36aa87363fb,de9c517b-0c41-4b81-9c34-87fde2f4f4d8}	{}	\N	{}	On s'est emballés ça arrive	2026-08-06 15:23:54.686	{"3939fc4c-1695-43de-887a-f36aa87363fb": 0, "de9c517b-0c41-4b81-9c34-87fde2f4f4d8": 0}	2026-08-04 07:56:03.01	2026-08-06 18:54:56.843	{}	\N
5e937c35-22eb-4e0b-9456-1f7bd3bdd5e6	private	{46dcf78a-a158-4a4a-a064-52a843ddb935,3939fc4c-1695-43de-887a-f36aa87363fb}	{}	\N	{}	📷 Image	2026-07-30 19:25:05.542	{"3939fc4c-1695-43de-887a-f36aa87363fb": 0, "46dcf78a-a158-4a4a-a064-52a843ddb935": 0}	2026-07-30 19:24:28.075	2026-08-06 14:30:58.972	{}	\N
general	general	{}	{}	Chat Général	{}	Holà 	2026-08-03 13:01:09.813	{"15025839-a51c-4bf2-8cff-703d5e7be91c": 0, "3939fc4c-1695-43de-887a-f36aa87363fb": 0, "46dcf78a-a158-4a4a-a064-52a843ddb935": 1, "52311211-b9dc-4c59-a808-8d3fdcb21891": 1, "744a1e04-b73b-4d48-b2b3-bc290a14ec80": 0, "a7e87340-b7ff-4efc-991b-e83db4ebcc62": 1, "aa54e618-335f-43ee-8ae5-d67ceebd968a": 0, "af47c934-5e71-4adf-9a0a-92f966af2fdc": 1, "b7d91c00-d926-4665-a67a-48ad186097b0": 0, "b91965d9-5dfe-4b54-8306-7a3ca846c53d": 1, "ceefebb1-4c69-42f3-95d5-91e7e3b34cf9": 1, "de9c517b-0c41-4b81-9c34-87fde2f4f4d8": 0, "e14f87c3-cc26-4be1-97c6-2799600d6ccd": 0, "eb92e149-0fa4-4ffe-a2eb-bd8e74c6d50d": 1, "f777e039-859f-4632-aaba-92ea63a64eb8": 0}	2026-07-08 07:47:24.117	2026-08-06 15:05:09.667	{}	\N
b4f26db7-9fb2-497d-bf52-14a686d30ad4	group	{3939fc4c-1695-43de-887a-f36aa87363fb,f777e039-859f-4632-aaba-92ea63a64eb8,46dcf78a-a158-4a4a-a064-52a843ddb935,de9c517b-0c41-4b81-9c34-87fde2f4f4d8,744a1e04-b73b-4d48-b2b3-bc290a14ec80,15025839-a51c-4bf2-8cff-703d5e7be91c,af47c934-5e71-4adf-9a0a-92f966af2fdc}	{3939fc4c-1695-43de-887a-f36aa87363fb}	Team Market	{}	📷 Image	2026-08-06 15:39:23.164	{"15025839-a51c-4bf2-8cff-703d5e7be91c": 39, "3939fc4c-1695-43de-887a-f36aa87363fb": 0, "46dcf78a-a158-4a4a-a064-52a843ddb935": 44, "744a1e04-b73b-4d48-b2b3-bc290a14ec80": 0, "af47c934-5e71-4adf-9a0a-92f966af2fdc": 39, "de9c517b-0c41-4b81-9c34-87fde2f4f4d8": 4, "f777e039-859f-4632-aaba-92ea63a64eb8": 0}	2026-08-05 09:07:24.942	2026-08-07 07:17:14.216	{}	/uploads/avatar/64db9ad3-1d24-4eb8-83f1-167285a82b0e.jpg
\.


--
-- Data for Name: ChatMessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ChatMessage" (id, "conversationId", "senderId", "senderName", "senderColor", content, type, "timestamp", edited, "editedAt", deleted, reactions, "replyToId", "createdAt", "updatedAt", "fileExpiredAt", "fileName", "fileSize") FROM stdin;
0b290f35-da79-404a-89c4-78cc2705c269	a2438c4b-3ef0-44ce-81f7-cbca26f9ad15	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	Ça va ma canaille ?	text	2026-07-31 09:20:26.674	f	\N	f	{}	\N	2026-07-31 09:20:26.676	2026-07-31 09:20:26.676	\N	\N	\N
ed1c0fe2-f614-41e1-8571-43ee377c652d	a2438c4b-3ef0-44ce-81f7-cbca26f9ad15	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	/uploads/chat/d5352e31-89e8-4497-baf5-4c20c4651d06.jpg	image	2026-07-31 09:21:05.893	f	\N	f	{}	\N	2026-07-31 09:21:05.895	2026-07-31 09:21:05.895	\N	\N	\N
46a81a5c-d950-4327-bb7c-6c953b89bf24	a2438c4b-3ef0-44ce-81f7-cbca26f9ad15	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	/uploads/chat/51b50e64-5abd-428a-95bc-ebce79bbc9a8.jpg	image	2026-07-31 09:21:08.523	f	\N	f	{}	\N	2026-07-31 09:21:08.524	2026-07-31 09:21:08.524	\N	\N	\N
6be7224b-3ade-4231-b112-9c44591dcfb8	general	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	coucou	text	2026-07-08 08:06:27.131	f	\N	f	{}	\N	2026-07-08 08:06:27.133	2026-07-08 08:06:27.133	\N	\N	\N
9b3725e6-d358-467c-9e35-3fa77fb120fa	acda278a-1898-4b16-8474-f45900f3faf7	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	HOLAAAAAAAAAAAAAAAAAAAAA	text	2026-08-03 13:00:54.993	f	\N	f	{}	\N	2026-08-03 13:00:54.994	2026-08-03 13:00:54.994	\N	\N	\N
3ead3040-07da-4c9f-803e-ee2f8dc8cf1e	0094fccc-5556-42c2-a69d-a3f593c21f29	e14f87c3-cc26-4be1-97c6-2799600d6ccd	Admin User	#8f12ab		text	2026-07-08 10:41:47.095	t	2026-07-08 10:41:48.605	t	{"👍": ["eb92e149-0fa4-4ffe-a2eb-bd8e74c6d50d"]}	\N	2026-07-08 10:41:47.097	2026-07-08 10:41:49.738	\N	\N	\N
09951078-bb4e-469f-a497-8bd0cb272fa4	general	e14f87c3-cc26-4be1-97c6-2799600d6ccd	Admin User	#8f12ab	Hello general	text	2026-07-08 10:41:51.164	f	\N	f	{}	\N	2026-07-08 10:41:51.165	2026-07-08 10:41:51.165	\N	\N	\N
634fc6c0-318e-4526-88e2-058522ee59e1	acda278a-1898-4b16-8474-f45900f3faf7	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	coucou	text	2026-07-08 15:50:00.61	f	\N	f	{}	\N	2026-07-08 15:50:00.612	2026-07-08 15:50:00.612	\N	\N	\N
5f8fb806-74d6-4814-bd51-ac7b61d5b438	acda278a-1898-4b16-8474-f45900f3faf7	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	HOLAAAAAAA	text	2026-07-08 15:50:08.396	f	\N	f	{}	\N	2026-07-08 15:50:08.397	2026-07-08 15:50:08.397	\N	\N	\N
7acb20e8-9d8f-4af6-b59b-59416403c5a8	acda278a-1898-4b16-8474-f45900f3faf7	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	/uploads/chat/53d87d88-ab9a-49ce-bb0d-20e19d2b155b.png	image	2026-07-08 15:50:16.94	f	\N	f	{"❤️": ["744a1e04-b73b-4d48-b2b3-bc290a14ec80"]}	\N	2026-07-08 15:50:16.942	2026-07-08 15:50:20.756	\N	\N	\N
00860b8c-a0b3-4af1-b413-2014f48aa205	acda278a-1898-4b16-8474-f45900f3faf7	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	miaou	text	2026-07-09 07:35:00.176	f	\N	f	{}	\N	2026-07-09 07:35:00.178	2026-07-09 07:35:00.178	\N	\N	\N
e1fb2da4-e184-433f-a07a-4e3ae4e286b6	acda278a-1898-4b16-8474-f45900f3faf7	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	calme toi wsh	text	2026-07-09 07:42:52.294	f	\N	f	{}	\N	2026-07-09 07:42:52.296	2026-07-09 07:42:52.296	\N	\N	\N
abf19e3f-e628-4c7b-9f58-43f2e692aec7	acda278a-1898-4b16-8474-f45900f3faf7	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	JPPPP JE VIENS DE TAPER UN FOU RIRE 	text	2026-07-09 08:03:26.914	f	\N	f	{}	\N	2026-07-09 08:03:26.917	2026-07-09 08:03:26.917	\N	\N	\N
46772c41-31f0-47f7-8d6b-905bedfc3ae7	acda278a-1898-4b16-8474-f45900f3faf7	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	/uploads/chat/6da4e1c9-d8de-4163-9314-519779447960.png	image	2026-07-09 07:42:45.329	f	\N	f	{"😂": ["744a1e04-b73b-4d48-b2b3-bc290a14ec80"]}	\N	2026-07-09 07:42:45.33	2026-07-09 08:06:49.02	\N	\N	\N
4c981fc5-fe38-48ba-9f9e-4f9dceae6611	acda278a-1898-4b16-8474-f45900f3faf7	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	le sang c'est quoi la logistique à midi ???	text	2026-07-09 08:56:41.899	f	\N	f	{}	\N	2026-07-09 08:56:41.901	2026-07-09 08:56:41.901	\N	\N	\N
cc6f31bb-fa5a-4c19-a09c-d70ca86dcf7d	acda278a-1898-4b16-8474-f45900f3faf7	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	/uploads/chat/29b465b4-9d1e-43ef-9827-e47eb8712274.png	image	2026-07-09 08:51:53.634	f	\N	f	{"😂": ["744a1e04-b73b-4d48-b2b3-bc290a14ec80"]}	\N	2026-07-09 08:51:53.636	2026-07-09 08:56:46.545	\N	\N	\N
cd52e23e-2039-4384-ad2b-8d95ee1a6e74	acda278a-1898-4b16-8474-f45900f3faf7	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	t'as pas reçu mon invitation pour le morpion ???	text	2026-07-09 09:21:15.748	f	\N	f	{}	\N	2026-07-09 09:21:15.75	2026-07-09 09:21:15.75	\N	\N	\N
82fdff17-bf9b-4bdb-8b72-ce0092465630	acda278a-1898-4b16-8474-f45900f3faf7	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	naaaan\nj'ai pas branché les jeux encore ;)	text	2026-07-09 12:23:46.783	f	\N	f	{}	\N	2026-07-09 12:23:46.784	2026-07-09 12:23:46.784	\N	\N	\N
895f66e6-65bf-4ea5-81a3-3c6af9152672	acda278a-1898-4b16-8474-f45900f3faf7	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	ptnnnnnnnnn	text	2026-07-09 12:35:44.259	f	\N	f	{}	\N	2026-07-09 12:35:44.26	2026-07-09 12:35:44.26	\N	\N	\N
85776bd4-435f-47ae-97e1-9472bbb81989	acda278a-1898-4b16-8474-f45900f3faf7	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	c'est le seul truc que je voulais tester 	text	2026-07-09 12:35:54.876	f	\N	f	{}	\N	2026-07-09 12:35:54.877	2026-07-09 12:35:54.877	\N	\N	\N
7d0481e5-6cc8-4b98-809d-f091469036d1	5e937c35-22eb-4e0b-9456-1f7bd3bdd5e6	46dcf78a-a158-4a4a-a064-52a843ddb935	Claire Richard	#bb7f84	Coucou test	text	2026-07-30 19:24:32.11	f	\N	f	{}	\N	2026-07-30 19:24:32.112	2026-07-30 19:24:32.112	\N	\N	\N
ea3747bd-3158-4b44-ad03-dddbbcc82934	5e937c35-22eb-4e0b-9456-1f7bd3bdd5e6	46dcf78a-a158-4a4a-a064-52a843ddb935	Claire Richard	#bb7f84	/uploads/chat/36aad8b3-883b-41c9-9b9b-f18afc978f94.png	image	2026-07-30 19:25:05.542	f	\N	f	{"😂": ["3939fc4c-1695-43de-887a-f36aa87363fb"]}	\N	2026-07-30 19:25:05.543	2026-07-30 19:25:30.321	\N	\N	\N
e7bb133c-1519-4425-b111-2e64738dd332	acda278a-1898-4b16-8474-f45900f3faf7	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	yooo le sang	text	2026-08-04 07:29:29.458	f	\N	f	{}	\N	2026-08-04 07:29:29.46	2026-08-04 07:29:29.46	\N	\N	\N
f43b9034-d117-4652-be54-db6b4ba2da04	acda278a-1898-4b16-8474-f45900f3faf7	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	appelle moi quand t'as 2min	text	2026-08-04 07:29:42.223	f	\N	f	{}	\N	2026-08-04 07:29:42.224	2026-08-04 07:29:42.224	\N	\N	\N
ce2bea7f-f689-4188-a733-6e5d9b757ed9	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Oh le sannnggg	text	2026-08-04 07:56:41.035	f	\N	f	{}	\N	2026-08-04 07:56:41.036	2026-08-04 07:56:41.036	\N	\N	\N
26596853-7028-4c8c-b1f3-215fd6e383ba	general	15025839-a51c-4bf2-8cff-703d5e7be91c	Bastien Fuziol	#270bc0	Holà 	text	2026-08-03 13:01:09.813	f	\N	f	{"❤️": ["de9c517b-0c41-4b81-9c34-87fde2f4f4d8", "744a1e04-b73b-4d48-b2b3-bc290a14ec80", "3939fc4c-1695-43de-887a-f36aa87363fb"]}	\N	2026-08-03 13:01:09.815	2026-08-05 07:35:54.968	\N	\N	\N
cc1cf5d3-82f1-4278-aa10-8beadc0f6875	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	Salut les loulous	text	2026-08-05 09:07:32.826	f	\N	f	{}	\N	2026-08-05 09:07:32.828	2026-08-05 09:07:32.828	\N	\N	\N
1b5ae2c9-4713-40e0-95b2-0a0933092489	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	Petite update vous pouvez envoyer des fichiers via le chat maintenant	text	2026-08-05 09:08:04.308	f	\N	f	{}	\N	2026-08-05 09:08:04.31	2026-08-05 09:08:04.31	\N	\N	\N
eaf387df-6066-4378-9242-0dedc16efbe5	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	/uploads/chat/5dbb2242-c267-4d4c-b1f2-c81e57fb7fcb.pdf	file	2026-08-05 09:09:07.431	f	\N	f	{}	\N	2026-08-05 09:09:07.433	2026-08-05 09:09:07.433	\N	corporace 2026 clf.pdf	4546980
a8d01855-e2e0-468c-a996-23d3388e69e0	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	pdf, word, excels...	text	2026-08-05 09:09:40.403	f	\N	f	{}	\N	2026-08-05 09:09:40.405	2026-08-05 09:09:40.405	\N	\N	\N
51751394-055e-45cc-9aae-9dbb1c0f454c	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	en détente le sang	text	2026-08-04 07:56:15.34	f	\N	f	{"👍": []}	\N	2026-08-04 07:56:15.342	2026-08-05 18:15:46.714	\N	\N	\N
70d65c88-0188-47f1-bbb7-2297fa5fbb62	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	t'es un crack 	text	2026-08-05 09:14:16.472	f	\N	f	{"😮": ["3939fc4c-1695-43de-887a-f36aa87363fb"]}	\N	2026-08-05 09:14:16.473	2026-08-05 09:16:47.042	\N	\N	\N
142ddf16-64db-43b4-96ea-adb362341095	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	-> Les dates d'anniversaire refonctionnent, vous pouvez enfin les rajouter sur vos profils 😊	text	2026-08-06 13:23:06.026	f	\N	f	{}	\N	2026-08-06 13:23:06.027	2026-08-06 13:23:06.027	\N	\N	\N
9396118d-4a6a-4006-95e6-aaa55aec6837	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Belle guerre	text	2026-08-06 14:20:47.781	f	\N	f	{}	\N	2026-08-06 14:20:47.783	2026-08-06 14:20:47.783	\N	\N	\N
3e60f489-f44e-426c-934c-7911ec9213e0	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	la bataille navale ça déconne	text	2026-08-06 14:20:48.791	f	\N	f	{}	\N	2026-08-06 14:20:48.793	2026-08-06 14:20:48.793	\N	\N	\N
eda6177e-3856-4f3e-87b1-dfae1849f94a	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	On doit pouvoir rejouer quand on touche non ?	text	2026-08-06 14:21:00.119	f	\N	f	{}	\N	2026-08-06 14:21:00.12	2026-08-06 14:21:00.12	\N	\N	\N
ada7b144-e290-4368-8db5-63d2d1c0bd8e	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	ouais, je fais la maj et jte remets la misère ;)	text	2026-08-06 14:21:18.319	f	\N	f	{}	\N	2026-08-06 14:21:18.32	2026-08-06 14:21:18.32	\N	\N	\N
58da9469-2579-41a1-bc62-c92cf533b5fc	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Il manque le petit bateau de 1 aussi	text	2026-08-06 14:21:24.036	f	\N	f	{}	\N	2026-08-06 14:21:24.037	2026-08-06 14:21:24.037	\N	\N	\N
0a40eacc-ad6a-400a-affa-27e9165311e4	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Psq c'est pour ça que j'ai perdu	text	2026-08-06 14:21:44.892	f	\N	f	{}	\N	2026-08-06 14:21:44.893	2026-08-06 14:21:44.893	\N	\N	\N
a830b57a-6166-4f1f-adf7-aab912807631	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Quand le jeu marche c'est normal	text	2026-08-06 14:51:14.939	f	\N	f	{}	\N	2026-08-06 14:51:14.941	2026-08-06 14:51:14.941	\N	\N	\N
1b128772-236e-4da0-b80c-46825e34a686	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	nan pas de petit bateau de 1 dans les règles classiques je crois 😅	text	2026-08-06 14:22:54.633	f	\N	f	{}	\N	2026-08-06 14:22:54.634	2026-08-06 14:22:54.634	\N	\N	\N
2830be51-c7ec-4caf-b76e-9c95243cc4b5	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	Salut les loulous, double mise à jour :\n\n-> Retour des jeux : Morpion, Puissance 4 et Bataille Navale !\n-> Possibilité de créer des comptes spécifiques pour vos chefs de site respectifs. Rang : "Site Manager", ils n'auront accès qu'aux informations de leurs sites, à certaines rubriques seulement et en lecture seule uniquement.	text	2026-08-06 13:19:29.613	f	\N	f	{"❤️": ["de9c517b-0c41-4b81-9c34-87fde2f4f4d8", "f777e039-859f-4632-aaba-92ea63a64eb8"]}	\N	2026-08-06 13:19:29.615	2026-08-06 14:22:58.551	\N	\N	\N
0816b1f9-1087-4e6f-8c39-ce975dc47c39	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Après vérification cela s'avère vrai	text	2026-08-06 14:24:27.165	f	\N	f	{}	\N	2026-08-06 14:24:27.166	2026-08-06 14:24:27.166	\N	\N	\N
eb365dbc-0c54-4e4b-a97d-0e03e0c86392	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Tu peux pas coller les bateaux aussi jsp si c'est dans les règles ça	text	2026-08-06 14:25:09.292	f	\N	f	{}	\N	2026-08-06 14:25:09.294	2026-08-06 14:25:09.294	\N	\N	\N
bb764535-fcaf-4f1a-b21e-a1d744315ab9	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	nan on peut pas c'est bien dans les règles 	text	2026-08-06 14:29:15.275	f	\N	f	{}	eb365dbc-0c54-4e4b-a97d-0e03e0c86392	2026-08-06 14:29:15.276	2026-08-06 14:29:15.276	\N	\N	\N
e50ccf14-246b-46f6-9940-67220854ded0	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Foutu règles	text	2026-08-06 14:31:46.892	f	\N	f	{}	\N	2026-08-06 14:31:46.893	2026-08-06 14:31:46.893	\N	\N	\N
06ca2ad8-5969-4a2a-b1e9-14c789483b83	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Je joue plus	text	2026-08-06 14:45:17.219	f	\N	f	{}	\N	2026-08-06 14:45:17.22	2026-08-06 14:45:17.22	\N	\N	\N
31405f84-c2ff-4d23-90e3-ac508587e242	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	J'aime pas les jeux	text	2026-08-06 14:45:24.564	f	\N	f	{}	\N	2026-08-06 14:45:24.566	2026-08-06 14:45:24.566	\N	\N	\N
1a936092-ddfe-421c-acad-173a37d2fa9f	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	67	text	2026-08-06 14:45:49.966	f	\N	f	{}	\N	2026-08-06 14:45:49.967	2026-08-06 14:45:49.967	\N	\N	\N
ad8a3424-d9e0-4eeb-a54a-2c3977e8a7bf	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Ptdr	text	2026-08-06 14:45:54.48	f	\N	f	{}	\N	2026-08-06 14:45:54.481	2026-08-06 14:45:54.481	\N	\N	\N
deac8f9c-4fef-40d6-aec7-a880bab9d52c	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	morpion ça c'est du bon jeu de con	text	2026-08-06 14:47:23.085	f	\N	f	{}	\N	2026-08-06 14:47:23.087	2026-08-06 14:47:23.087	\N	\N	\N
4ef851b3-8a4b-4676-8a03-8703cb4df0a5	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Jte jure	text	2026-08-06 14:47:29.69	f	\N	f	{}	\N	2026-08-06 14:47:29.691	2026-08-06 14:47:29.691	\N	\N	\N
0ca3ea1a-4fc1-4a48-a0f5-5816740e948a	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	la bataille navale est réparée d'ailleurs	text	2026-08-06 14:47:31.752	f	\N	f	{}	\N	2026-08-06 14:47:31.754	2026-08-06 14:47:31.754	\N	\N	\N
8d77ce01-3259-4746-84b8-8859eedd70ad	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	A bah voilà !	text	2026-08-06 14:47:37.479	f	\N	f	{}	\N	2026-08-06 14:47:37.481	2026-08-06 14:47:37.481	\N	\N	\N
f9be2686-5c6c-4f47-b25a-666dda382c74	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	l'heure de la revanche à sonné	text	2026-08-06 14:47:49.4	f	\N	f	{}	\N	2026-08-06 14:47:49.402	2026-08-06 14:47:49.402	\N	\N	\N
6754fc55-b13e-46e8-a3c6-fe000433a314	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	starfoulah	text	2026-08-06 14:51:02.53	f	\N	f	{}	\N	2026-08-06 14:51:02.531	2026-08-06 14:51:02.531	\N	\N	\N
7fe4eafd-6a76-43c4-b2ad-8d2b38dd9590	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	batard 😂😂	text	2026-08-06 14:51:28.206	f	\N	f	{}	\N	2026-08-06 14:51:28.208	2026-08-06 14:51:28.208	\N	\N	\N
91695477-e920-4ba2-a352-52068deeb521	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Jvais me prendre un sale karma a la prochaine 😭	text	2026-08-06 14:52:17.686	f	\N	f	{}	\N	2026-08-06 14:52:17.687	2026-08-06 14:52:17.687	\N	\N	\N
a40e9c18-4406-4eb5-99a4-b081df430822	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	je t'attends de pied ferme	text	2026-08-06 14:52:27.059	f	\N	f	{}	\N	2026-08-06 14:52:27.061	2026-08-06 14:52:27.061	\N	\N	\N
195cc417-8e31-46c9-9d63-7c8dbd8f79de	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	KARMA	text	2026-08-06 14:56:57.026	f	\N	f	{}	\N	2026-08-06 14:56:57.028	2026-08-06 14:56:57.028	\N	\N	\N
9e02315d-fb16-482c-9e17-c0aa82bfc533	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	C'était sur mdr	text	2026-08-06 14:57:04.69	f	\N	f	{}	\N	2026-08-06 14:57:04.692	2026-08-06 14:57:04.692	\N	\N	\N
2b50f184-5a21-4b1f-9753-5d305890cca8	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	J'ai torpillé partout ils faisaient 1 case tes bateaux	text	2026-08-06 14:57:38.687	f	\N	f	{}	\N	2026-08-06 14:57:38.688	2026-08-06 14:57:38.688	\N	\N	\N
bc457583-1ea6-41ba-b2a6-5bfd7d15c18c	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	Théo arrête de mettre des branlés à tout le monde sur les jeux stppp 	text	2026-08-06 14:57:45.088	f	\N	f	{}	\N	2026-08-06 14:57:45.09	2026-08-06 14:57:45.09	\N	\N	\N
bb91b2f5-a031-4de1-827c-fa9b16ed00cc	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	si on parle de salaire	text	2026-08-06 15:05:21.202	f	\N	f	{}	\N	2026-08-06 15:05:21.204	2026-08-06 15:05:21.204	\N	\N	\N
4f2b9bf5-1eda-483c-9776-32d169c5a21a	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	alors non	text	2026-08-06 15:05:22.744	f	\N	f	{}	\N	2026-08-06 15:05:22.746	2026-08-06 15:05:22.746	\N	\N	\N
c24959d5-f77a-4c50-a83a-f447d56df8f9	b4f26db7-9fb2-497d-bf52-14a686d30ad4	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Oui stp	text	2026-08-06 14:57:53.559	f	\N	f	{}	\N	2026-08-06 14:57:53.56	2026-08-06 14:57:53.56	\N	\N	\N
3dea7208-b38c-438c-92bd-f9db33600d10	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	/uploads/chat/62efe6df-e707-4b46-b39d-3e3635812b2f.jpg	image	2026-08-06 15:01:03.899	f	\N	f	{}	\N	2026-08-06 15:01:03.901	2026-08-06 15:01:03.901	\N	\N	15088
94b17eff-aa54-4bd5-a372-28b3cbc46858	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	faudrait que je mette des codes de triche	text	2026-08-06 15:01:47.736	f	\N	f	{}	\N	2026-08-06 15:01:47.738	2026-08-06 15:01:47.738	\N	\N	\N
0e2215b1-e901-41d3-b2ad-c753823f8599	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	à la GTA	text	2026-08-06 15:01:50.379	f	\N	f	{}	\N	2026-08-06 15:01:50.38	2026-08-06 15:01:50.38	\N	\N	\N
7fb64966-4c4d-4dc7-af91-1c22078d3ad4	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	attend parce que là jviens de prendre une déculottée sur la bataille navale jvais jamais m'en remettre en fait	text	2026-08-06 15:04:34.229	f	\N	f	{}	\N	2026-08-06 15:04:34.231	2026-08-06 15:04:34.231	\N	\N	\N
924a741a-152a-42f8-8b0c-f58cd2595dbc	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	t'aurais pu envoyer le nain 	text	2026-08-06 15:03:05.86	f	\N	f	{}	\N	2026-08-06 15:03:05.862	2026-08-06 15:03:05.862	\N	\N	\N
391c4a0d-e059-42d2-9e33-db80ddd0da02	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d		image	2026-08-06 15:04:52.154	f	\N	t	{}	\N	2026-08-06 15:04:52.156	2026-08-06 15:05:13.097	\N	\N	107261
45047530-20cc-4420-81b4-d7f5d45466f2	b4f26db7-9fb2-497d-bf52-14a686d30ad4	f777e039-859f-4632-aaba-92ea63a64eb8	Morgane Barthe	#8cc7d	je l'ai gagné à la bataille 🚢	text	2026-08-06 15:04:44.33	f	\N	f	{"😂": ["3939fc4c-1695-43de-887a-f36aa87363fb"]}	\N	2026-08-06 15:04:44.332	2026-08-06 15:05:45.375	\N	\N	\N
40731ded-e9da-428f-87ac-8c095cf45ab8	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	/uploads/chat/7cd0d3dd-14db-4cc7-bcba-8beb24b292a2.png	image	2026-08-06 15:04:52.154	f	\N	f	{"😂": ["3939fc4c-1695-43de-887a-f36aa87363fb", "744a1e04-b73b-4d48-b2b3-bc290a14ec80"]}	\N	2026-08-06 15:04:52.156	2026-08-06 15:06:01.233	\N	\N	107261
a8a495b4-08d2-421f-9fe8-389d08ce3aba	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Tu gagnes pas déjà assez ?	text	2026-08-06 15:05:00.743	f	\N	f	{}	\N	2026-08-06 15:05:00.744	2026-08-06 15:05:00.744	\N	\N	\N
33dddba4-953d-4177-830f-0aacf501c097	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	seul hic, les échecs je sais pas y jouer donc pour le développer c'est pas le top 😅	text	2026-08-06 15:19:53.99	f	\N	f	{}	\N	2026-08-06 15:19:53.991	2026-08-06 15:19:53.991	\N	\N	\N
1c00bc60-764b-4e9b-ad87-f87309bc0dd5	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Mdr	text	2026-08-06 15:06:06.118	f	\N	f	{}	\N	2026-08-06 15:06:06.119	2026-08-06 15:06:06.119	\N	\N	\N
f76d3421-a7db-48b9-b1f7-5e82998f95a9	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Arretons de nous plaindre 	text	2026-08-06 15:06:10.964	f	\N	f	{}	\N	2026-08-06 15:06:10.965	2026-08-06 15:06:10.965	\N	\N	\N
066af708-bbab-4d0c-9731-e115696158f0	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	On touche a nous tous réunis le salaire d'un metteur en main	text	2026-08-06 15:06:24.008	f	\N	f	{}	\N	2026-08-06 15:06:24.01	2026-08-06 15:06:24.01	\N	\N	\N
76b35980-8d3d-4937-9551-624c66d44ecc	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Et ça c'est beau	text	2026-08-06 15:06:28.971	f	\N	f	{}	\N	2026-08-06 15:06:28.972	2026-08-06 15:06:28.972	\N	\N	\N
0dd50ef0-2311-4fdb-9dae-d6ef52febb81	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Cette solidarité laaaa	text	2026-08-06 15:06:34.941	f	\N	f	{}	\N	2026-08-06 15:06:34.942	2026-08-06 15:06:34.942	\N	\N	\N
bec74057-3659-4f83-a2bb-3ca7e1b22d08	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Qui sait jouer aux échec justement j'allais demandé	text	2026-08-06 15:20:04.121	f	\N	f	{}	\N	2026-08-06 15:20:04.123	2026-08-06 15:20:04.123	\N	\N	\N
5a1d0692-3d15-499c-86a9-378007d09661	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	On respire la productivité ça me rassure 	text	2026-08-06 15:05:51.111	f	\N	f	{"😂": ["f777e039-859f-4632-aaba-92ea63a64eb8"]}	\N	2026-08-06 15:05:51.113	2026-08-06 15:06:40.49	\N	\N	\N
506e0c24-5ac6-48f4-a96c-18612057e382	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	balancez des idées de jeux que vous aimez bien histoire que je rajoute ça 	text	2026-08-06 15:20:32.737	f	\N	f	{}	\N	2026-08-06 15:20:32.739	2026-08-06 15:20:32.739	\N	\N	\N
df5aca9a-f6c0-4621-ad10-cd8517770f99	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	si il voyait ça l'autre grande tige mdrrr	text	2026-08-06 15:06:40.896	f	\N	f	{"😂": ["f777e039-859f-4632-aaba-92ea63a64eb8", "de9c517b-0c41-4b81-9c34-87fde2f4f4d8", "744a1e04-b73b-4d48-b2b3-bc290a14ec80"]}	\N	2026-08-06 15:06:40.898	2026-08-06 15:07:03.721	\N	\N	\N
210a3618-ac09-4bbf-af15-caa09feab724	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	/uploads/chat/f4757f59-1c98-4059-953b-5ad4e4efb058.png	image	2026-08-06 15:07:32.42	f	\N	f	{}	\N	2026-08-06 15:07:32.422	2026-08-06 15:07:32.422	\N	\N	100311
a3faacfc-12f2-4069-b896-1df0933e05e2	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Foutu préparateur	text	2026-08-06 15:07:49.63	f	\N	f	{}	\N	2026-08-06 15:07:49.632	2026-08-06 15:07:49.632	\N	\N	\N
a2d44a00-49e4-4059-87ba-cf42ece2fefc	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	mec le préparateur EAA prend plus nous 	text	2026-08-06 15:07:30.444	f	\N	f	{"😮": ["de9c517b-0c41-4b81-9c34-87fde2f4f4d8"]}	\N	2026-08-06 15:07:30.446	2026-08-06 15:08:03.498	\N	\N	\N
e1d0c62d-a2ba-45bb-adc6-09a0060c4092	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	c'est JB	text	2026-08-06 15:08:10.651	f	\N	f	{}	\N	2026-08-06 15:08:10.653	2026-08-06 15:08:10.653	\N	\N	\N
50a49129-c972-4a1a-9c44-75c3f2a59fca	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	faut pas lui chercher des noises	text	2026-08-06 15:08:16.259	f	\N	f	{}	\N	2026-08-06 15:08:16.26	2026-08-06 15:08:16.26	\N	\N	\N
9a29cf3b-33c3-4370-ad24-2f8a9b2f9066	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Merde	text	2026-08-06 15:08:21.841	f	\N	f	{}	\N	2026-08-06 15:08:21.842	2026-08-06 15:08:21.842	\N	\N	\N
4b3c7236-84a1-43ce-add4-72431165f531	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Déso JB	text	2026-08-06 15:08:42.538	f	\N	f	{}	\N	2026-08-06 15:08:42.539	2026-08-06 15:08:42.539	\N	\N	\N
351a8d9a-e0fa-4819-b7a3-6128542f5df6	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	bon ok prochaine maj je rajoute les gifs	text	2026-08-06 15:08:38.633	f	\N	f	{"😂": ["de9c517b-0c41-4b81-9c34-87fde2f4f4d8"]}	210a3618-ac09-4bbf-af15-caa09feab724	2026-08-06 15:08:38.634	2026-08-06 15:08:58.895	\N	\N	\N
142aaaab-63b1-47bf-a679-da8a8a0328ed	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	RORO HEUREUSE 	text	2026-08-06 15:09:33.134	f	\N	f	{}	351a8d9a-e0fa-4819-b7a3-6128542f5df6	2026-08-06 15:09:33.136	2026-08-06 15:09:33.136	\N	\N	\N
a4412d57-2992-4614-b1fb-cbef5b6c8acf	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	On peut pas rajouter les échec par pur hasard ?	text	2026-08-06 15:18:22.961	f	\N	f	{}	\N	2026-08-06 15:18:22.962	2026-08-06 15:18:22.962	\N	\N	\N
b7292018-d409-451d-a6d8-1f3679f6a6c0	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	alors j'allais justement envoyer un message dans le groupe pour vous demander des idées de jeux 	text	2026-08-06 15:19:10.131	f	\N	f	{"❤️": ["de9c517b-0c41-4b81-9c34-87fde2f4f4d8"]}	\N	2026-08-06 15:19:10.132	2026-08-06 15:19:32.529	\N	\N	\N
e3a6b009-f7aa-413f-8585-73fe15c64c87	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	Dans l'optique de passer de bons moments de détente la semaine prochaine	text	2026-08-06 15:20:53.902	f	\N	f	{}	\N	2026-08-06 15:20:53.904	2026-08-06 15:20:53.904	\N	\N	\N
d85c87be-22af-4a7e-b6b3-7c0051b6737c	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	bah alors ok mais si personne sait y jouer ça sert à rien d'y rajouter non ? 😭😭	text	2026-08-06 15:21:28.061	f	\N	f	{}	\N	2026-08-06 15:21:28.064	2026-08-06 15:21:28.064	\N	\N	\N
db3278fd-28e1-40e1-8404-9e312c9a4167	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Psq moi non plus en fait	text	2026-08-06 15:20:09.087	t	2026-08-06 15:20:38.142	f	{"😂": ["3939fc4c-1695-43de-887a-f36aa87363fb"]}	\N	2026-08-06 15:20:09.089	2026-08-06 15:21:35.975	\N	\N	\N
bf50da03-4040-427f-9df8-a4479085e257	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Les dames c'est plus simple	text	2026-08-06 15:22:47.638	f	\N	f	{}	\N	2026-08-06 15:22:47.64	2026-08-06 15:22:47.64	\N	\N	\N
acd1d0aa-235c-41d3-abf4-b710f43608a0	48cd49b2-e671-429f-b415-47b583640b98	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	Oui ça conviendra mieux à des gens simple comme nous 	text	2026-08-06 15:23:23.962	f	\N	f	{"😂": ["de9c517b-0c41-4b81-9c34-87fde2f4f4d8"]}	\N	2026-08-06 15:23:23.963	2026-08-06 15:23:32.628	\N	\N	\N
89c155b2-6134-4c22-88a8-1864fa924e50	b4f26db7-9fb2-497d-bf52-14a686d30ad4	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Genre en 2v2 ?	text	2026-08-06 15:24:14.438	f	\N	f	{}	\N	2026-08-06 15:24:14.439	2026-08-06 15:24:14.439	\N	\N	\N
15283675-d809-450a-9519-60fce2b71793	48cd49b2-e671-429f-b415-47b583640b98	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	On s'est emballés ça arrive	text	2026-08-06 15:23:54.686	f	\N	f	{"😂": ["3939fc4c-1695-43de-887a-f36aa87363fb"]}	\N	2026-08-06 15:23:54.688	2026-08-06 15:32:35.822	\N	\N	\N
c2c9c3a5-88c0-4714-be7d-d3cd460c3260	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	on peut faire des jeux à plusieurs ??	text	2026-08-06 15:23:57.35	f	\N	f	{}	\N	2026-08-06 15:23:57.351	2026-08-06 15:23:57.351	\N	\N	\N
a3e0ab9d-173e-408b-a488-a6cda203e5e1	b4f26db7-9fb2-497d-bf52-14a686d30ad4	f777e039-859f-4632-aaba-92ea63a64eb8	Morgane Barthe	#8cc7d	belote ?	text	2026-08-06 15:26:10.804	f	\N	f	{}	\N	2026-08-06 15:26:10.805	2026-08-06 15:26:10.805	\N	\N	\N
84f766fb-09ce-430e-9d1c-59a19242a20e	b4f26db7-9fb2-497d-bf52-14a686d30ad4	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Un poker ça serait stylé	text	2026-08-06 15:26:14.064	f	\N	f	{}	\N	2026-08-06 15:26:14.066	2026-08-06 15:26:14.066	\N	\N	\N
e61c1f08-b9b3-4cbe-b454-efd5814c0f51	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	je sais pas mais qu'on joue tous ensemble 	text	2026-08-06 15:24:49.158	f	\N	f	{}	\N	2026-08-06 15:24:49.159	2026-08-06 15:24:49.159	\N	\N	\N
8e7a11c4-c701-40ff-8a7a-775d2c24ec28	b4f26db7-9fb2-497d-bf52-14a686d30ad4	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Un UNO c'est faisable ?	text	2026-08-06 15:25:03.839	f	\N	f	{}	\N	2026-08-06 15:25:03.84	2026-08-06 15:25:03.84	\N	\N	\N
7e90fb89-9ab2-422b-9509-5d10764324b7	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	genre un skyjo 	text	2026-08-06 15:25:41.552	f	\N	f	{}	\N	2026-08-06 15:25:41.553	2026-08-06 15:25:41.553	\N	\N	\N
a69e5b70-69c2-4056-a802-acfd16e839c9	b4f26db7-9fb2-497d-bf52-14a686d30ad4	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	Le tarot sinon	text	2026-08-06 15:30:00.531	f	\N	f	{}	\N	2026-08-06 15:30:00.532	2026-08-06 15:30:00.532	\N	\N	\N
15c27bd4-2b1d-45d2-a1d2-12b66a56467a	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	il va te dire oui 	text	2026-08-06 15:25:17.027	f	\N	f	{}	\N	2026-08-06 15:25:17.028	2026-08-06 15:25:17.028	\N	\N	\N
42f235de-23bb-494c-a507-097b80f5e052	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	je sais pas jouer snif 	text	2026-08-06 15:28:17.47	f	\N	f	{}	84f766fb-09ce-430e-9d1c-59a19242a20e	2026-08-06 15:28:17.472	2026-08-06 15:28:17.472	\N	\N	\N
1ec830d5-5f00-4756-a84b-0f2bf7856540	b4f26db7-9fb2-497d-bf52-14a686d30ad4	f777e039-859f-4632-aaba-92ea63a64eb8	Morgane Barthe	#8cc7d	les échecs	text	2026-08-06 15:26:42.453	f	\N	f	{}	\N	2026-08-06 15:26:42.454	2026-08-06 15:26:42.454	\N	\N	\N
31872003-5b7a-41de-bebc-022e924b16f6	b4f26db7-9fb2-497d-bf52-14a686d30ad4	f777e039-859f-4632-aaba-92ea63a64eb8	Morgane Barthe	#8cc7d	ouais moi non plus sorry	text	2026-08-06 15:28:42.109	f	\N	f	{}	84f766fb-09ce-430e-9d1c-59a19242a20e	2026-08-06 15:28:42.111	2026-08-06 15:28:42.111	\N	\N	\N
ae7f31a0-332b-416e-9fd0-a1b51fd2f5b0	b4f26db7-9fb2-497d-bf52-14a686d30ad4	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	Alexis Perz	#1cce70	FIFA j'aime bien perso	text	2026-08-06 15:23:15.784	f	\N	f	{"😂": ["3939fc4c-1695-43de-887a-f36aa87363fb"]}	\N	2026-08-06 15:23:15.785	2026-08-06 15:29:20.06	\N	\N	\N
e2880941-acff-45b2-a6f9-41c29802f340	b4f26db7-9fb2-497d-bf52-14a686d30ad4	f777e039-859f-4632-aaba-92ea63a64eb8	Morgane Barthe	#8cc7d	non	text	2026-08-06 15:30:14.273	f	\N	f	{}	a69e5b70-69c2-4056-a802-acfd16e839c9	2026-08-06 15:30:14.275	2026-08-06 15:30:14.275	\N	\N	\N
67e84bfa-c18e-4b77-a55e-43beadcb830a	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	Tu peux faire un monopoly ? 	text	2026-08-06 15:30:55.226	f	\N	f	{}	\N	2026-08-06 15:30:55.227	2026-08-06 15:30:55.227	\N	\N	\N
9a456976-5828-4d6d-a81e-5661a8e3f9f2	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	Infaisable 	text	2026-08-06 15:31:11.63	f	\N	f	{}	\N	2026-08-06 15:31:11.631	2026-08-06 15:31:11.631	\N	\N	\N
5898283d-363f-4d89-a274-d0431ff46bcf	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	mais sur un malentendu 	text	2026-08-06 15:31:20.903	f	\N	f	{}	\N	2026-08-06 15:31:20.904	2026-08-06 15:31:20.904	\N	\N	\N
3758c51f-5ac8-47d1-8024-988c56ce8fc5	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	Ok Monopoly premier degrés jvais me chauffer je crois je suis séduit par l'idée	text	2026-08-06 15:31:42.545	f	\N	f	{}	\N	2026-08-06 15:31:42.546	2026-08-06 15:31:42.546	\N	\N	\N
594286ed-220d-4734-a990-4e0aeb7a1dd8	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	Jeu de dame parce que je suis trop con pour les échecs	text	2026-08-06 15:32:16.458	f	\N	f	{}	\N	2026-08-06 15:32:16.459	2026-08-06 15:32:16.459	\N	\N	\N
3c092ac1-834f-4131-af2d-289aa8c830f5	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	je connais ni l'un ni l'autre 	text	2026-08-06 15:36:52.064	f	\N	f	{}	594286ed-220d-4734-a990-4e0aeb7a1dd8	2026-08-06 15:36:52.067	2026-08-06 15:36:52.067	\N	\N	\N
50284000-fe5a-4592-9702-52a903a4f63a	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	ça fait de toi le con du groupe	text	2026-08-06 15:37:19.225	f	\N	f	{}	\N	2026-08-06 15:37:19.227	2026-08-06 15:37:19.227	\N	\N	\N
91a5b788-9cd1-4250-9fe5-947504e25545	b4f26db7-9fb2-497d-bf52-14a686d30ad4	3939fc4c-1695-43de-887a-f36aa87363fb	Théo Labonne	#f75632	c'est pas grave il en faut un	text	2026-08-06 15:37:25.514	f	\N	f	{}	\N	2026-08-06 15:37:25.515	2026-08-06 15:37:25.515	\N	\N	\N
7fe57e0f-9879-4f08-9a6c-24faaca8e89f	b4f26db7-9fb2-497d-bf52-14a686d30ad4	744a1e04-b73b-4d48-b2b3-bc290a14ec80	Romane Chambon	#dac06d	/uploads/chat/67d6a057-8ae1-45af-8808-0fe7c5ba96aa.png	image	2026-08-06 15:39:23.164	f	\N	f	{"😂": ["3939fc4c-1695-43de-887a-f36aa87363fb"]}	50284000-fe5a-4592-9702-52a903a4f63a	2026-08-06 15:39:23.165	2026-08-06 15:41:29.571	\N	\N	397776
\.


--
-- Data for Name: Contact; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Contact" (id, "firstName", "lastName", email, phone, site, service, type, "rgpdConsent", tags, "lastContactDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: DigitalTags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DigitalTags" (id, networks, co2) FROM stdin;
f9fc311d-8c67-4b76-9b42-2bd16ec5e354	{Facebook,Instagram,LinkedIn}	{A,B,C,D,E,F,G}
\.


--
-- Data for Name: Equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Equipment" (id, name, "totalQuantity", category, "createdAt", "updatedAt") FROM stdin;
5636b7fa-d14f-401c-8273-5c0ea0fa2a20	Desk Bony	1	Mobilier	2026-07-08 22:07:25.591	2026-07-08 22:07:25.591
7124218a-11f8-44fd-9687-1761cff7be7f	Desk Alpine	1	Mobilier	2026-07-08 22:07:25.675	2026-07-08 22:07:25.675
5ef271ef-e960-4e6f-8c99-3b45240afd04	Mur d'image	1	PLV	2026-07-08 22:07:26.713	2026-07-08 22:07:26.713
5d606d9f-4520-4c62-b604-7b68ed13e48a	Kakémono ID	2	PLV	2026-07-08 22:07:27.03	2026-07-08 22:07:27.03
2cbca9b0-c1a7-4341-9b00-ef6ff877053e	Kakémono Carte RH	1	PLV	2026-07-08 22:07:27.236	2026-07-08 22:07:27.236
4d72379a-cc0d-4845-92f3-b61d638dc620	Kakémono Métiers RH	1	PLV	2026-07-08 22:07:28.257	2026-07-08 22:07:28.257
fe849c52-89aa-4e72-95f8-6ea0d5baed64	Kakémono Valeurs RH	1	PLV	2026-07-08 22:07:28.991	2026-07-08 22:07:28.991
eb36a7d8-02cf-4118-b7d3-ae06d83414af	Kit Kakémono VA	1	PLV	2026-07-08 22:07:29.024	2026-07-08 22:07:29.024
f0a11684-5df2-4cb0-8206-b8cf48382601	Tonelle Renault	1	Structure	2026-07-08 22:07:30.537	2026-07-08 22:07:30.537
8c857e1a-1f9f-4896-9938-caf03ee7ddb5	Tonelle Blanche	1	Structure	2026-07-08 22:07:30.841	2026-07-08 22:07:30.841
c4a472fa-6276-4524-ba38-76584142b738	Tonelle Dacia	2	Structure	2026-07-08 22:07:31.029	2026-07-08 22:07:31.029
65cf96bc-c08f-4908-9626-2bea7e4efe18	Transat Dacia	2	Mobilier	2026-07-08 22:07:31.336	2026-07-08 22:07:31.336
395c65b6-926c-4589-8f18-a00e0a55b6fb	Tables	10	Mobilier	2026-07-08 22:07:31.84	2026-07-08 22:07:31.84
d0f30566-69df-4bec-a287-09b3414a2d93	Chaises	28	Mobilier	2026-07-08 22:07:32.347	2026-07-08 22:07:32.347
a64c0bc6-432b-4f0c-a7bd-2b7398cdc149	Mange-debout	12	Mobilier	2026-07-08 22:07:32.859	2026-07-08 22:07:32.859
ab4d4d57-c768-4a21-a478-7d1979fa210c	Enceinte JBL	2	Son	2026-07-08 22:07:24.66	2026-08-03 13:04:43.286
\.


--
-- Data for Name: EquipmentBooking; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EquipmentBooking" (id, "equipmentId", quantity, "startDate", "endDate", site, service, brand, description, "createdAt", "updatedAt") FROM stdin;
29a60781-361b-4f54-8c40-42da07eaabe4	ab4d4d57-c768-4a21-a478-7d1979fa210c	1	2026-02-04 00:00:00	2026-02-04 00:00:00	GROUPE BONY	Tous Services	Groupe		2026-07-08 22:07:33.636	2026-07-08 22:07:33.636
35eee30d-a442-48ce-85f5-b3e0dff1e28c	ab4d4d57-c768-4a21-a478-7d1979fa210c	1	2026-04-08 00:00:00	2026-04-08 00:00:00	GROUPE BONY	Tous Services	Groupe		2026-07-08 22:07:34.14	2026-07-08 22:07:34.14
25f6a33f-3133-4dae-af92-0a0ca0482976	ab4d4d57-c768-4a21-a478-7d1979fa210c	1	2026-04-03 00:00:00	2026-04-05 00:00:00	Vichy	VN	Groupe	Salon du vin	2026-07-08 22:07:35.039	2026-07-08 22:07:35.039
ed5e56c7-cde9-4859-998d-ca2b2241ed40	ab4d4d57-c768-4a21-a478-7d1979fa210c	1	2026-07-03 00:00:00	2026-07-03 00:00:00	GROUPE BONY	Tous Services	Groupe		2026-07-08 22:07:35.54	2026-07-08 22:07:35.54
1514000f-3789-4d01-88ce-d37678e6ea48	7124218a-11f8-44fd-9687-1761cff7be7f	1	2026-08-04 00:00:00	2026-08-07 00:00:00	Clermont	VN	Alpine	DEMO — Essai piste Alpine	2026-07-30 13:03:59.176	2026-07-30 13:03:59.176
75ed98bc-0261-40de-b750-a9f00f856675	7124218a-11f8-44fd-9687-1761cff7be7f	1	2026-08-05 00:00:00	2026-08-08 00:00:00	Vichy	VN	Alpine	DEMO — Chevauchement volontaire	2026-07-30 13:04:00.225	2026-07-30 13:04:00.225
699b904b-3aab-4dab-90e0-0205685349c7	ab4d4d57-c768-4a21-a478-7d1979fa210c	2	2026-08-11 00:00:00	2026-08-13 00:00:00	Moulins	VN	Nissan	DEMO — Business Days	2026-07-30 13:04:00.637	2026-07-30 13:04:00.637
2d2d7527-8d43-40b8-bafd-9c4a483009a3	d0f30566-69df-4bec-a287-09b3414a2d93	15	2026-07-23 00:00:00	2026-07-25 00:00:00	Clermont	Tous Services	Holding		2026-07-30 16:09:53.546	2026-07-30 16:09:53.546
511a84d2-1f80-4f5f-a54b-3b219b243a36	5636b7fa-d14f-401c-8273-5c0ea0fa2a20	1	2026-09-24 00:00:00	2026-09-24 00:00:00	Issoire	APV	Holding	VA ISSOIRE	2026-08-05 12:22:14.227	2026-08-05 12:22:14.227
8ccb8231-43a2-452a-a03a-22df13cd2bfc	5ef271ef-e960-4e6f-8c99-3b45240afd04	1	2026-09-24 00:00:00	2026-09-24 00:00:00	Issoire	APV	Holding	VA ISSOIRE	2026-08-05 12:22:40.858	2026-08-05 12:22:40.858
7b1b0631-18d6-43d1-a46c-5d23cb22ccc0	ab4d4d57-c768-4a21-a478-7d1979fa210c	1	2026-09-24 00:00:00	2026-09-24 00:00:00	Issoire	APV	Holding	VA ISSOIRE	2026-08-05 12:23:08.875	2026-08-05 12:23:08.875
\.


--
-- Data for Name: FixedExpense; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FixedExpense" (id, date, service, site, sites, "budgetDistribution", comment, amount, brand, brands, "alpineShare", "proPlus", "isAnnual", "createdAt", "updatedAt", "nissanShare") FROM stdin;
0f77a54b-e493-400a-8e03-8e1278fa1494	2026-01-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:19:14.486	2026-08-03 16:19:14.486	\N
869ea720-8136-466d-806e-04865fd4a3e0	2026-01-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.730351, "Mende": 4.23889, "Mozac": 6.031122, "Rodez": 7.643223, "Ussel": 3.239074, "Vichy": 8.820692, "Figeac": 2.866208, "Lavaur": 1.910806, "Millau": 1.90874, "Ricoux": 4.643774, "Carmaux": 0.764322, "Gaillac": 3.43945, "Issoire": 7.694453, "Moulins": 5.916267, "Aurillac": 3.821611, "Clermont": 19.037822, "Massagettes": 3.239074, "Villefranche": 1.910806, "Le Puy-en-Velay": 7.143315}	Le bon coin — boutique	24204.45	Renault	{Renault}	\N	f	f	2026-08-03 16:19:07.895	2026-08-03 16:19:07.895	\N
5796d44b-6ba8-4c3e-b109-43edb3107159	2026-01-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	3604	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:08.488	2026-08-03 16:19:08.488	\N
802c6506-5889-49f7-b578-d614490b800c	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	453	Renault	{Renault}	\N	f	f	2026-08-03 16:19:09.326	2026-08-03 16:19:09.326	\N
ffc35dac-f777-41cf-b56a-05d61f56c4e8	2026-01-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:19:10.006	2026-08-03 16:19:10.006	\N
20145223-6ea1-4667-b535-c5d3c708e32b	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:10.803	2026-08-03 16:19:10.803	\N
deec56ea-ca60-482f-8146-413c9fd97aa4	2026-01-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:19:11.52	2026-08-03 16:19:11.52	\N
dee5a32e-d59f-4529-9102-35dfdf55655b	2026-01-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:12.319	2026-08-03 16:19:12.319	\N
7b902224-68b1-48f6-a0b7-8f53975e4cc0	2026-01-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:13.837	2026-08-03 16:19:13.837	\N
9b44fef8-876b-44e7-9ab2-d295191e8638	2026-01-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:15.288	2026-08-03 16:19:15.288	\N
eebaa32a-6907-4dca-97a0-6af72d706dc9	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LE QG — accueil café	756	Alpine	{Alpine}	\N	f	f	2026-08-03 16:19:15.956	2026-08-03 16:19:15.956	\N
90c1c26f-42bb-4599-bfdd-4d0808ca9155	2026-01-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	NRJ GLOBAL — RADIO CARE SERVICE MINUTE CUSSET	1288.92	Renault	{Renault}	\N	f	f	2026-08-03 16:19:16.775	2026-08-03 16:19:16.775	\N
d6335433-a492-415a-8669-b2ed19097341	2026-01-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	TOMMY MULTIMEDIA — ENREGISTREMENT SPOT RADIO CARE SERVICE MINUTE CUSSET	110	Renault	{Renault}	\N	f	f	2026-08-03 16:19:17.438	2026-08-03 16:19:17.438	\N
89ffaa42-6a2f-4ef3-aacf-9e5a0c5c6884	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — Pochettes A4 VN	618	Alpine	{Alpine}	\N	f	f	2026-08-03 16:19:18.172	2026-08-03 16:19:18.172	\N
916a5919-0f5e-465e-ba61-766b380317d4	2026-01-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — Pochettes A5 APV	618	Alpine	{Alpine}	\N	f	f	2026-08-03 16:19:18.89	2026-08-03 16:19:18.89	\N
7e89a3ca-7b8b-4245-8a6b-24b08bfe7ecf	2026-01-01 00:00:00	VN	Mende	{Mende}	{"Mende": 100}	GRAPHIC — STICKERS BONY	174.34	Renault	{Renault}	\N	f	f	2026-08-03 16:19:19.938	2026-08-03 16:19:19.938	\N
1eac367b-3718-436a-b0f2-97764470e09b	2026-01-01 00:00:00	VN	Figeac	{Figeac}	{"Figeac": 100}	GRAPHIC — Stickers Mobilize	122.5	Renault	{Renault}	\N	f	f	2026-08-03 16:19:23.971	2026-08-03 16:19:23.971	\N
26969643-575f-45e6-8937-0fda9119c6af	2026-01-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:19:13.006	2026-08-03 16:19:13.006	\N
39147626-6691-4cda-b9b4-0c5f43ceb362	2026-01-01 00:00:00	VN	Albi	{Albi}	{"Albi": 100}	GRAPHIC — Stickers Mobilize	224.5	Renault	{Renault}	\N	f	f	2026-08-03 16:19:21.57	2026-08-03 16:19:21.57	\N
c5def568-2956-4922-86c0-9868117427ab	2026-01-01 00:00:00	VN	Millau	{Millau}	{"Millau": 100}	GRAPHIC — Stickers Mobilize	224.5	Renault	{Renault}	\N	f	f	2026-08-03 16:19:25.821	2026-08-03 16:19:25.821	\N
c3e98527-009d-4bff-8915-fa2cc2ebfd87	2026-01-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.674674, "Mende": 2.762526, "Mozac": 5.096088, "Rodez": 8.442004, "Ussel": 2.556623, "Vichy": 7.687028, "Figeac": 2.814001, "Lavaur": 0.7035, "Millau": 2.47083, "Ricoux": 4.392588, "Carmaux": 1.76733, "Gaillac": 3.877831, "Issoire": 5.490734, "Moulins": 5.490734, "Aurillac": 6.674674, "Clermont": 22.614962, "Massagettes": 1.595745, "Villefranche": 1.76733, "Le Puy-en-Velay": 7.120796}	GOODICOM — portes cartes grises	5828	Renault	{Renault}	\N	f	f	2026-08-03 16:19:28.004	2026-08-03 16:19:28.004	\N
27a546d9-e4ec-451b-bf8e-a2ba06656c53	2026-01-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	GOODICOM — portes cartes grises	576	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:28.753	2026-08-03 16:19:28.753	\N
1fa43a69-cad4-461a-9ca0-6aa3fadb2df9	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	CISCAR — portes cartes jaunes	164	Renault	{Renault}	\N	f	f	2026-08-03 16:19:30.154	2026-08-03 16:19:30.154	\N
bc9d3bd1-5a43-4771-ab4a-239d93a2f6ca	2026-01-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.674674, "Mende": 2.762526, "Mozac": 5.096088, "Rodez": 8.442004, "Ussel": 2.556623, "Vichy": 7.687028, "Figeac": 2.814001, "Lavaur": 0.7035, "Millau": 2.47083, "Ricoux": 4.392588, "Carmaux": 1.76733, "Gaillac": 3.877831, "Issoire": 5.490734, "Moulins": 5.490734, "Aurillac": 6.674674, "Clermont": 22.614962, "Massagettes": 1.595745, "Villefranche": 1.76733, "Le Puy-en-Velay": 7.120796}	GOODICOM — portes cartes grises	5828	Renault	{Renault}	\N	f	f	2026-08-03 16:19:26.536	2026-08-03 16:19:26.536	\N
07eff6dc-3e3e-4301-9bac-c5d3abd97b55	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GOODICOM — portes cartes grises	576	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:27.321	2026-08-03 16:19:27.321	\N
3dcd66b5-2fba-4ade-a5e5-f2de08155bc2	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Point Marquage — Stickers Clio	105	Renault	{Renault}	\N	f	f	2026-08-03 16:19:29.469	2026-08-03 16:19:29.469	\N
ff13d7a4-6aa7-40ff-825a-5f7c56ffbc84	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	AHB — étiquettes jaunes	218	Renault	{Renault}	\N	f	f	2026-08-03 16:19:30.888	2026-08-03 16:19:30.888	\N
e1bbfba2-17a8-48ae-97a9-8337430c4594	2026-01-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	graphic — stickers pare brise 888	553.87	Renault	{Renault}	\N	f	f	2026-08-03 16:19:31.654	2026-08-03 16:19:31.654	\N
7b18a26c-169b-4616-a729-3f40f750ad29	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Graphic — kits Alpine	142.52	Alpine	{Alpine}	\N	f	f	2026-08-03 16:19:32.404	2026-08-03 16:19:32.404	\N
c891e437-8a46-4aff-a7a6-582b346992e2	2026-01-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	Point Marquage — PLV et stickers clio	98	Renault	{Renault}	\N	f	f	2026-08-03 16:19:33.122	2026-08-03 16:19:33.122	\N
ddd8882d-f856-45e1-88e1-81578b01fb88	2026-01-01 00:00:00	VN	Massagettes	{Massagettes}	{"Massagettes": 100}	Graphic — Stickers vitrine Clio massagettes	340	Renault	{Renault}	\N	f	f	2026-08-03 16:19:33.89	2026-08-03 16:19:33.89	\N
8203ac27-2f9d-4526-a8e5-22fcb7768807	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Graphic — Stickers vitrine Clio clermont	340	Renault	{Renault}	\N	f	f	2026-08-03 16:19:34.574	2026-08-03 16:19:34.574	\N
d54ab05a-b0c5-4a22-8754-127b402d1ace	2026-01-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:19:35.341	2026-08-03 16:19:35.341	\N
e73696ff-05b0-4d70-88f0-0b2f0586eda8	2026-01-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:19:36.029	2026-08-03 16:19:36.029	\N
fecead01-db71-4fc4-a444-9b1cb44f2245	2026-01-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:19:36.823	2026-08-03 16:19:36.823	\N
5f805c13-84d8-407f-aa1a-11932da92d23	2026-01-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.25, "Mende": 6.25, "Mozac": 6.25, "Rodez": 6.25, "Ussel": 6.25, "Vichy": 6.25, "Figeac": 6.25, "Millau": 6.25, "Ricoux": 6.25, "Gaillac": 6.25, "Issoire": 6.25, "Moulins": 6.25, "Aurillac": 6.25, "Clermont": 6.25, "Massagettes": 6.25, "Le Puy-en-Velay": 6.25}	DACIA — KIT PLV DACIA R1	2416	Renault	{Renault}	\N	f	f	2026-08-03 16:19:37.49	2026-08-03 16:19:37.49	\N
3510a7c2-5a86-4e78-8121-fb2e1a388bd8	2026-01-01 00:00:00	VN	Ussel	{Ussel}	{"Ussel": 100}	Point Marquage — stickers + plv clio	98	Renault	{Renault}	\N	f	f	2026-08-03 16:19:38.294	2026-08-03 16:19:38.294	\N
cec8e37c-3bc9-43c0-a11a-3e7ad0f036c9	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LVMR — HOUSSE DYNABUY	84.85	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:38.956	2026-08-03 16:19:38.956	\N
b0f7b2bd-1379-4502-a949-4e597afd57fa	2026-01-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Graphic — taux horaires	69	Renault	{Renault}	\N	f	f	2026-08-03 16:19:39.791	2026-08-03 16:19:39.791	\N
1be4a1bd-b251-4c3a-93ca-ced75275b9c9	2026-01-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:19:40.425	2026-08-03 16:19:40.425	\N
65424c94-b6ff-449f-a233-86b4d966c73f	2026-01-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — MAJ LOGO BONY SHOWROOM	95.25	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:42.69	2026-08-03 16:19:42.69	\N
6a8e43b8-68ea-4fb5-9bf4-9b066a46ddcb	2026-01-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — MAJ LOGO BONY SHOWROOM	95.25	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:43.409	2026-08-03 16:19:43.409	\N
779c51d5-bcd2-4fa0-8382-22b1e3da6a3d	2026-01-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — phtoo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:19:52.953	2026-08-03 16:19:52.953	\N
98e56d3e-5790-4433-9a0c-c4016cd974a6	2026-02-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	3604	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:55.236	2026-08-03 16:19:55.236	\N
d125a0f7-fe07-4a00-bb50-7c170b7b05f9	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	453	Renault	{Renault}	\N	f	f	2026-08-03 16:19:55.891	2026-08-03 16:19:55.891	\N
e8999970-4c35-433c-b0e5-63ee2aec6222	2026-02-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:19:56.688	2026-08-03 16:19:56.688	\N
77e3efc7-c950-4782-87cd-38c4a56b9d93	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:57.333	2026-08-03 16:19:57.333	\N
8a386cf4-8fb7-4c07-9ff1-314bab15f445	2026-02-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:19:58.158	2026-08-03 16:19:58.158	\N
b02f51dd-c49c-49bc-9efb-5de8ad582738	2026-02-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	debrez — voile BSO	478	Renault	{Renault}	\N	f	f	2026-08-03 16:20:21.072	2026-08-03 16:20:21.072	\N
71e8d180-5b44-415d-9ab5-69ce7229bde2	2026-02-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.408296, "Mende": 5.127265, "Mozac": 3.845187, "Rodez": 7.690374, "Ussel": 3.949932, "Vichy": 8.972452, "Figeac": 2.563109, "Lavaur": 2.563109, "Millau": 3.845187, "Ricoux": 5.127265, "Carmaux": 2.563109, "Gaillac": 3.845187, "Issoire": 6.408296, "Moulins": 3.845187, "Aurillac": 5.127265, "Clermont": 15.301142, "Massagettes": 3.845187, "Villefranche": 3.845187, "Le Puy-en-Velay": 5.127265}	stickers perf vo — stickers perf vo	954.7	Renault	{Renault}	\N	f	f	2026-08-03 16:20:21.755	2026-08-03 16:20:21.755	\N
05bc71c4-c56c-4f87-9419-9b4032d41edc	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	SALON EXPO VU — STAND RENAULT PRO + & NISSAN	2575	Renault	{Renault}	\N	f	f	2026-08-03 16:20:24.07	2026-08-03 16:20:24.07	\N
2944402d-5ac3-443a-9718-3374008ed21a	2026-02-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	KIWANIS VICHY — ENCART PLAQUETTE SOIREE ELEGANCE	37.5	Renault	{Renault}	\N	f	f	2026-08-03 16:20:27.424	2026-08-03 16:20:27.424	\N
e977a327-31ee-42d3-8345-2336e7322784	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — MAJ LOGO BONY SHOWROOM	95.25	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:41.209	2026-08-03 16:19:41.209	\N
5843e6aa-7ea1-4790-9874-d9d620168b6e	2026-01-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	GRAPHIC — Bâche Renault Rodez	113	Renault	{Renault}	\N	f	f	2026-08-03 16:19:44.209	2026-08-03 16:19:44.209	\N
f3a63770-3f2d-4f32-8d3b-1ecad8815c77	2026-02-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:20:02.143	2026-08-03 16:20:02.143	\N
e781995c-4877-4fb8-89e3-8700869d10c0	2026-02-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	vidéo voeux	13	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:12.306	2026-08-03 16:20:12.306	\N
33111675-6083-4dad-8941-7864239d8b8d	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Phonecontact — Sms conquete A110	231	Alpine	{Alpine}	\N	f	f	2026-08-03 16:20:20.306	2026-08-03 16:20:20.306	\N
999b90e3-d16c-4940-b51a-a0a25e31b031	2026-01-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — MAJ LOGO BONY SHOWROOM	95.25	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:41.908	2026-08-03 16:19:41.908	\N
ba32e38d-cd4f-41b0-be8b-7a529e3f0e8e	2026-01-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:19:45.69	2026-08-03 16:19:45.69	\N
b939df0d-8ea0-4180-895e-8b50bcf43431	2026-01-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:19:47.136	2026-08-03 16:19:47.136	\N
bcbc6e86-54aa-4b33-94fd-b02273e1a867	2026-01-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:47.86	2026-08-03 16:19:47.86	\N
a5cf7e1e-63fa-4f9d-a190-4be6ae92f182	2026-01-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:19:48.657	2026-08-03 16:19:48.657	\N
f1fc19f9-04a0-44ec-8f15-444d64152f07	2026-01-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:19:50.121	2026-08-03 16:19:50.121	\N
192314a6-7529-4203-b2b9-6a3fd867e4a9	2026-01-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — phtoo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:53.74	2026-08-03 16:19:53.74	\N
9133f03e-43de-4c38-988b-e368ab4dc873	2026-02-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.730351, "Mende": 4.23889, "Mozac": 6.031122, "Rodez": 7.643223, "Ussel": 3.239074, "Vichy": 8.820692, "Figeac": 2.866208, "Lavaur": 1.910806, "Millau": 1.90874, "Ricoux": 4.643774, "Carmaux": 0.764322, "Gaillac": 3.43945, "Issoire": 7.694453, "Moulins": 5.916267, "Aurillac": 3.821611, "Clermont": 19.037822, "Massagettes": 3.239074, "Villefranche": 1.910806, "Le Puy-en-Velay": 7.143315}	Le bon coin — boutique	24204.45	Renault	{Renault}	\N	f	f	2026-08-03 16:19:54.386	2026-08-03 16:19:54.386	\N
4bcbbfa9-2d01-473f-bc89-01c63c5209d1	2026-02-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:20:03.922	2026-08-03 16:20:03.922	\N
f8c34fd0-2d19-4c8e-8b12-4a4e9ad99046	2026-02-01 00:00:00	VN	Clermont, Ricoux	{Clermont,Ricoux}	{"Ricoux": 10, "Clermont": 90}	CISCAR — porte cartes véhicules	6100	Renault	{Renault}	\N	f	f	2026-08-03 16:20:06.904	2026-08-03 16:20:06.904	\N
42018a51-5c0b-4398-9449-b530659e3b54	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Marquage Moderne — Commande plaques A110	405	Alpine	{Alpine}	\N	f	f	2026-08-03 16:20:07.509	2026-08-03 16:20:07.509	\N
695d8994-c6ef-4a2e-be66-61fc4a9bf804	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Coutellerie Robert David — commande couteaux coffret A110	2547	Alpine	{Alpine}	\N	f	f	2026-08-03 16:20:07.851	2026-08-03 16:20:07.851	\N
e73c3d3e-4666-4a40-9d97-2ab57338e39c	2026-02-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:43.106	2026-08-03 16:20:43.106	\N
ef572240-16c6-449f-b5a2-8ed7c4ee5d08	2026-01-01 00:00:00	VN	Albi, Aurillac, Figeac, Gaillac, Lavaur, Ricoux, Villefranche	{Albi,Aurillac,Figeac,Gaillac,Lavaur,Ricoux,Villefranche}	{"Albi": 34.006734, "Figeac": 1.515152, "Lavaur": 10.774411, "Ricoux": 5.555556, "Gaillac": 25.757576, "Aurillac": 19.023569, "Villefranche": 3.367003}	Point marquage — Stickers Mobilize Share	594	Renault	{Renault}	\N	f	f	2026-08-03 16:19:44.855	2026-08-03 16:19:44.855	\N
b37d7bc9-9da1-4b33-90e0-6bb6eecd482b	2026-01-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:46.371	2026-08-03 16:19:46.371	\N
274831ac-19b8-42c4-87db-5e5fa43a5ca1	2026-01-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:19:51.543	2026-08-03 16:19:51.543	\N
efc13f17-5653-4598-8143-9cacd486e2ed	2026-01-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:52.294	2026-08-03 16:19:52.294	\N
d6b8404e-911c-4dbf-a10f-bff95f438489	2026-02-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:20:00.206	2026-08-03 16:20:00.206	\N
9446200d-7878-4595-b4f5-f84dd770eb98	2026-02-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:20:04.756	2026-08-03 16:20:04.756	\N
1aa8f35a-fe7a-47cb-9a3f-fd0d608c87bf	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Point Marquage — Vitrophanie Alpine	2660	Alpine	{Alpine}	\N	f	f	2026-08-03 16:20:19.621	2026-08-03 16:20:19.621	\N
172dce77-66b6-4b5d-9908-d72f5b833dec	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	KILOUTOU — LOCATION CHAUFFAGE SALON EXPO VU	139.5	Renault	{Renault}	\N	f	f	2026-08-03 16:20:22.593	2026-08-03 16:20:22.593	\N
3ecde00c-7b87-49b5-9890-c60e7fa336f5	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	KILOUTOU — LOCATION CHAUFFAGE SALON EXPO VU	139.5	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:23.206	2026-08-03 16:20:23.206	\N
1edd6628-ec95-41d3-83b1-338b19c587cd	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	CISCAR — Commande kit marquage A390	333	Alpine	{Alpine}	\N	f	f	2026-08-03 16:20:25.507	2026-08-03 16:20:25.507	\N
5251a41f-2eaa-42e3-b197-5549f75908c7	2026-02-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	KIWANIS VICHY — ENCART PLAQUETTE SOIREE ELEGANCE	37.5	Renault	{Renault}	\N	f	f	2026-08-03 16:20:28.257	2026-08-03 16:20:28.257	\N
bf6e1a20-82fd-41b7-b64e-906ff078e7ef	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — STICKERS BONY LUNETTE ARRIERE	480	Renault	{Renault}	\N	f	f	2026-08-03 16:20:30.374	2026-08-03 16:20:30.374	\N
4bd1930c-3d92-4b0b-915b-c3fb35d6ef7b	2026-01-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:49.355	2026-08-03 16:19:49.355	\N
5538d270-9de8-447f-88bc-d3191e1279bf	2026-01-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:50.855	2026-08-03 16:19:50.855	\N
08800eb7-bd2e-40c7-89f7-8773126e765d	2026-02-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:19:59.297	2026-08-03 16:19:59.297	\N
fa52212d-310c-4e6d-8a9d-694f229d963d	2026-02-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:01.342	2026-08-03 16:20:01.342	\N
e5eafe41-df39-45f1-b86f-0ee15989df1c	2026-02-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:03.27	2026-08-03 16:20:03.27	\N
0b746dfe-ba6e-439d-bc42-0a4f8a3700e1	2026-02-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:20:05.455	2026-08-03 16:20:05.455	\N
e7666c2b-72dd-478e-a0be-6aaad37010a2	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	CMON EVENT — EXPO VU STUDIO 120	5150	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:06.038	2026-08-03 16:20:06.038	\N
6912e6e7-8d2f-463c-af9f-25fc67aec89e	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	vidéo voeux	13	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:09.356	2026-08-03 16:20:09.356	\N
e2251641-1623-476c-bbe7-a0d363387e20	2026-02-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.451613, "Mende": 2.419355, "Mozac": 4.83871, "Rodez": 8.870968, "Ussel": 2.419355, "Vichy": 8.064516, "Figeac": 3.225806, "Lavaur": 0.806452, "Millau": 2.419355, "Ricoux": 4.032258, "Carmaux": 1.612903, "Gaillac": 4.032258, "Issoire": 5.645161, "Moulins": 5.645161, "Aurillac": 6.451613, "Clermont": 22.580645, "Massagettes": 1.612903, "Villefranche": 1.612903, "Le Puy-en-Velay": 7.258065}	vidéo voeux	124	Renault	{Renault}	\N	f	f	2026-08-03 16:20:09.662	2026-08-03 16:20:09.662	\N
95dd0f8b-78fb-42b5-ab7d-6ddb46c7c1b9	2026-02-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	vidéo voeux	13	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:10.225	2026-08-03 16:20:10.225	\N
244ad256-d0b2-49bf-bcca-b55ff9e6c3a4	2026-02-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.451613, "Mende": 2.419355, "Mozac": 4.83871, "Rodez": 8.870968, "Ussel": 2.419355, "Vichy": 8.064516, "Figeac": 3.225806, "Lavaur": 0.806452, "Millau": 2.419355, "Ricoux": 4.032258, "Carmaux": 1.612903, "Gaillac": 4.032258, "Issoire": 5.645161, "Moulins": 5.645161, "Aurillac": 6.451613, "Clermont": 22.580645, "Massagettes": 1.612903, "Villefranche": 1.612903, "Le Puy-en-Velay": 7.258065}	vidéo voeux	124	Renault	{Renault}	\N	f	f	2026-08-03 16:20:11.073	2026-08-03 16:20:11.073	\N
51e1fcea-ea1f-4e73-8fa0-6a4e23c35d62	2026-02-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	vidéo voeux	13	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:14.623	2026-08-03 16:20:14.623	\N
10298946-0ee0-4c5f-8f6d-74c5a992f0da	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Hotel Henri 4 — Nuit nogaro	585	Alpine	{Alpine}	\N	f	f	2026-08-03 16:20:16.421	2026-08-03 16:20:16.421	\N
646cf186-50c3-4c8c-b046-10ddbf70557c	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Cruzilles — Pates de fruit	394	Alpine	{Alpine}	\N	f	f	2026-08-03 16:20:18.806	2026-08-03 16:20:18.806	\N
798517b7-b38b-43de-af03-c5796c2156fc	2026-02-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	KIWANIS VICHY — ENCART PLAQUETTE SOIREE ELEGANCE	37.5	Renault	{Renault}	\N	f	f	2026-08-03 16:20:28.925	2026-08-03 16:20:28.925	\N
3f3d10a3-13bf-4375-bcb4-3c3b3e3e11bf	2026-02-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	KIWANIS VICHY — ENCART PLAQUETTE SOIREE ELEGANCE	37.5	Renault	{Renault}	\N	f	f	2026-08-03 16:20:29.707	2026-08-03 16:20:29.707	\N
a069eb42-e8fc-49b9-87ca-1ee53694c9d8	2026-02-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:20:08.438	2026-08-03 16:20:08.438	\N
ed975840-ab79-4adb-9c29-f00f7d02d5fc	2026-02-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.451613, "Mende": 2.419355, "Mozac": 4.83871, "Rodez": 8.870968, "Ussel": 2.419355, "Vichy": 8.064516, "Figeac": 3.225806, "Lavaur": 0.806452, "Millau": 2.419355, "Ricoux": 4.032258, "Carmaux": 1.612903, "Gaillac": 4.032258, "Issoire": 5.645161, "Moulins": 5.645161, "Aurillac": 6.451613, "Clermont": 22.580645, "Massagettes": 1.612903, "Villefranche": 1.612903, "Le Puy-en-Velay": 7.258065}	vidéo voeux	124	Renault	{Renault}	\N	f	f	2026-08-03 16:20:08.767	2026-08-03 16:20:08.767	\N
698d9fc4-5b6e-43f2-84b0-9dc781fb1b1d	2026-02-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.451613, "Mende": 2.419355, "Mozac": 4.83871, "Rodez": 8.870968, "Ussel": 2.419355, "Vichy": 8.064516, "Figeac": 3.225806, "Lavaur": 0.806452, "Millau": 2.419355, "Ricoux": 4.032258, "Carmaux": 1.612903, "Gaillac": 4.032258, "Issoire": 5.645161, "Moulins": 5.645161, "Aurillac": 6.451613, "Clermont": 22.580645, "Massagettes": 1.612903, "Villefranche": 1.612903, "Le Puy-en-Velay": 7.258065}	vidéo voeux	124	Renault	{Renault}	\N	f	f	2026-08-03 16:20:13.075	2026-08-03 16:20:13.075	\N
47e0bfe3-d59b-4462-b3c4-4e950990ee2b	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	SALON EXPO VU — STAND RENAULT PRO + & NISSAN	2575	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:24.74	2026-08-03 16:20:24.74	\N
1a09ab86-41c2-40e5-b43d-854b2f3b2bbd	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LVMR — location 6 housses MD	91	Renault	{Renault}	\N	f	f	2026-08-03 16:20:26.716	2026-08-03 16:20:26.716	\N
ea0e692b-e931-46e7-85ab-26e695b7e139	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LVMR — HOUSSES X2	18.3	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:31.174	2026-08-03 16:20:31.174	\N
06998656-82e3-4d93-b37f-39b72f80e6a2	2026-02-01 00:00:00	VO	Ricoux	{Ricoux}	{"Ricoux": 100}	RVO — POCHETTES CLIENTS	84	Renault	{Renault}	\N	f	f	2026-08-03 16:20:31.857	2026-08-03 16:20:31.857	\N
64cda0f8-0d9b-42c2-b4f8-9a892597eb0d	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	CISCAR — POCHETTES CLIENTS	1384.68	Renault	{Renault}	\N	f	f	2026-08-03 16:20:32.607	2026-08-03 16:20:32.607	\N
cdd8a724-1366-417c-b2f6-c6d729d8dfd6	2026-02-01 00:00:00	VN	Ricoux	{Ricoux}	{"Ricoux": 100}	CISCAR — POCHETTES CLIENTS	436.2	Renault	{Renault}	\N	f	f	2026-08-03 16:20:33.339	2026-08-03 16:20:33.339	\N
aa4cabb7-0100-44df-88ea-af4ea3ca409f	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	POINT MARQUAGE — STICKERS MOBILIZE	282.72	Renault	{Renault}	\N	f	f	2026-08-03 16:20:34.057	2026-08-03 16:20:34.057	\N
206851e0-2651-41b8-8669-cd6cfa4887ff	2026-02-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	GRAPHIC — STICKERS BONY COTE	240	Renault	{Renault}	\N	f	f	2026-08-03 16:20:34.791	2026-08-03 16:20:34.791	\N
d94546d6-1897-47a0-93b2-ef8b230a1531	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LVAF — Bracelets Alpine	940	Alpine	{Alpine}	\N	f	f	2026-08-03 16:20:35.474	2026-08-03 16:20:35.474	\N
e63fee65-fb1f-4491-8c82-75a7da8576fe	2026-02-01 00:00:00	VN	Ussel	{Ussel}	{"Ussel": 100}	graphic — sous retro ussel	312.34	Renault	{Renault}	\N	f	f	2026-08-03 16:20:36.274	2026-08-03 16:20:36.274	\N
4524cf54-aca0-4562-8d0b-f608bcbbc1a4	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	graphic — sous retro clf	960	Renault	{Renault}	\N	f	f	2026-08-03 16:20:36.926	2026-08-03 16:20:36.926	\N
6deabf16-7d81-4f40-a1ba-6921855d976d	2026-02-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:20:37.774	2026-08-03 16:20:37.774	\N
9013ccf8-1f45-4f7d-b93d-d74ffc31b016	2026-02-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:38.409	2026-08-03 16:20:38.409	\N
bca65935-9ff5-4dd6-a0a5-1669f76d55fd	2026-02-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:39.843	2026-08-03 16:20:39.843	\N
11831800-d466-4573-a305-20e04cc6702a	2026-02-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:41.509	2026-08-03 16:20:41.509	\N
4703d2a1-5d57-4977-8120-26e2a50959f0	2026-02-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:20:39.226	2026-08-03 16:20:39.226	\N
bdbeacd7-6458-4697-bff7-3db0087fd35c	2026-03-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:52.706	2026-08-03 16:20:52.706	\N
eb973571-9b8e-47c3-8a80-ca0fc0fe9b4d	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — STICKERS BONY	72	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:23.273	2026-08-03 16:21:23.273	\N
2690b904-686f-4583-bd8e-d6364f839148	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — STICKERS MOBILIZE - FUMER + CARBURANT	262.98	Renault	{Renault}	\N	f	f	2026-08-03 16:21:27.99	2026-08-03 16:21:27.99	\N
9ec54ff8-d1b7-48ed-a648-02b00fdd7172	2026-02-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:20:40.774	2026-08-03 16:20:40.774	\N
258e1cf4-9eb5-4059-b94c-b234e05eb220	2026-02-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — phtoo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:46.09	2026-08-03 16:20:46.09	\N
7fd2c473-9e49-4a59-890f-7b9ba7a79f96	2026-03-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	3604	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:47.557	2026-08-03 16:20:47.557	\N
cae8c4e5-54df-4d29-9c38-3543fe59a0a4	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	453	Renault	{Renault}	\N	f	f	2026-08-03 16:20:48.29	2026-08-03 16:20:48.29	\N
a605b773-3cb4-4bf9-9185-1395b8c8d767	2026-03-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:20:50.408	2026-08-03 16:20:50.408	\N
38bfdf78-c4b8-4169-8807-7fb69359017d	2026-03-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:55.041	2026-08-03 16:20:55.041	\N
9b043ebf-1820-4693-a6df-4216988ea64e	2026-03-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:20:59.14	2026-08-03 16:20:59.14	\N
5cbfe4ff-6c68-474a-8e82-3c31eb3e948a	2026-03-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — sandartd	72	Renault	{Renault}	\N	f	f	2026-08-03 16:21:08.759	2026-08-03 16:21:08.759	\N
13c2a587-a0e1-4808-b76a-290af6530ecb	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	TKT PRODUCTION — MDA	40	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:10.993	2026-08-03 16:21:10.993	\N
233698c0-1707-4732-ad8c-ebcaca78d3bf	2026-03-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.683168, "Mende": 2.722772, "Mozac": 5.19802, "Rodez": 8.415842, "Ussel": 2.475248, "Vichy": 7.673267, "Figeac": 2.722772, "Lavaur": 0.742574, "Millau": 2.475248, "Ricoux": 4.455446, "Carmaux": 1.732673, "Gaillac": 3.960396, "Issoire": 5.445545, "Moulins": 5.445545, "Aurillac": 6.683168, "Clermont": 22.772277, "Massagettes": 1.485149, "Villefranche": 1.732673, "Le Puy-en-Velay": 7.178218}	TKT PRODUCTION — MDA	404	Renault	{Renault}	\N	f	f	2026-08-03 16:21:17.156	2026-08-03 16:21:17.156	\N
90240eb7-11fe-4809-bf8d-576a9e23886c	2026-03-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.320908, "Mende": 6.320908, "Mozac": 3.079417, "Rodez": 9.400324, "Ussel": 6.320908, "Vichy": 6.320908, "Figeac": 3.079417, "Millau": 3.079417, "Ricoux": 3.079417, "Gaillac": 3.079417, "Issoire": 9.23825, "Moulins": 6.320908, "Aurillac": 6.320908, "Clermont": 12.479741, "Massagettes": 3.079417, "Villefranche": 3.079417, "Le Puy-en-Velay": 9.400324}	Print — Doc ROOLE	617	Renault	{Renault}	\N	f	f	2026-08-03 16:21:20.524	2026-08-03 16:21:20.524	\N
faaea117-998b-4d3a-86e6-504a7ad40c27	2026-03-01 00:00:00	VO	Clermont, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Ussel, Vichy	{Clermont,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Ussel,Vichy}	{"Mende": 4.918283, "Mozac": 6.55262, "Ussel": 4.918283, "Vichy": 8.20223, "Ricoux": 4.093478, "Issoire": 8.20223, "Moulins": 8.20223, "Clermont": 40.980602, "Massagettes": 2.459142, "Le Puy-en-Velay": 11.470903}	CISCAR — portes cartes véhicules	6547	Renault	{Renault}	\N	f	f	2026-08-03 16:21:25.356	2026-08-03 16:21:25.356	\N
d4bcbff8-45e6-4716-8dd3-2a306981197e	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC	202.5	Alpine	{Alpine}	\N	f	f	2026-08-03 16:21:29.251	2026-08-03 16:21:29.251	\N
fa72eeb3-620c-4534-a88b-1542a65eb5ea	2026-02-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:20:42.458	2026-08-03 16:20:42.458	\N
dbf9f623-4aa0-40dc-b6ca-4ebabc127fb8	2026-02-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:20:43.907	2026-08-03 16:20:43.907	\N
803bc66d-9b21-4459-9a3b-01c82ca5b6e1	2026-02-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:44.656	2026-08-03 16:20:44.656	\N
a5d4df54-3ad4-4511-917c-1c78ac9803fd	2026-03-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:51.24	2026-08-03 16:20:51.24	\N
30839509-41eb-4085-aa05-501b15c9d3ad	2026-03-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:20:51.873	2026-08-03 16:20:51.873	\N
96e1c51f-a8ae-4310-8c58-503be648682d	2026-03-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:20:53.36	2026-08-03 16:20:53.36	\N
a60ab47e-d245-43f0-a609-bed6bdbc02b9	2026-03-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:20:58.281	2026-08-03 16:20:58.281	\N
86c56983-7ae4-46be-9987-949c323da60e	2026-03-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:20:59.873	2026-08-03 16:20:59.873	\N
8e5e41b6-309a-4c0d-9623-eb51787ff92b	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	ALLIANCE EXPO — SALON REST'HOTEL	1800	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:00.641	2026-08-03 16:21:00.641	\N
93f3594c-54c9-4d64-a68b-c1a165c60092	2026-03-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	TOUBKALPES — DIGITAL VO NISSAN	1000	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:01.341	2026-08-03 16:21:01.341	\N
65729cee-5a4c-4760-bb8d-c6a1251aac8b	2026-03-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — sandartd	72	Renault	{Renault}	\N	f	f	2026-08-03 16:21:06.526	2026-08-03 16:21:06.526	\N
50b41b0d-00f8-43c7-a994-5f0ca846b0ae	2026-03-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — sandartd	72	Renault	{Renault}	\N	f	f	2026-08-03 16:21:07.926	2026-08-03 16:21:07.926	\N
f8b98848-738e-4c54-8a71-9faa5ad61561	2026-03-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	TKT PRODUCTION — MDA	40	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:18.26	2026-08-03 16:21:18.26	\N
0f776046-3e55-4d72-b3b6-b45c3dc1baa8	2026-02-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — phtoo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:20:45.407	2026-08-03 16:20:45.407	\N
4ea214c7-2d9c-422f-94b1-868f035b33d3	2026-03-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — ADHESIFS + BACHE VO NISSAN	1949.2	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:02.821	2026-08-03 16:21:02.821	\N
03978023-eadb-4399-912d-53c234210d25	2026-03-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — sandartd	222	Renault	{Renault}	\N	f	f	2026-08-03 16:21:04.321	2026-08-03 16:21:04.321	\N
d88c29fc-3f2a-4ec1-aefb-f88fd922b0d7	2026-03-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — sandartd	72	Renault	{Renault}	\N	f	f	2026-08-03 16:21:09.45	2026-08-03 16:21:09.45	\N
989f854f-8282-4e9e-9ebe-cd70ba97cc72	2026-03-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.683168, "Mende": 2.722772, "Mozac": 5.19802, "Rodez": 8.415842, "Ussel": 2.475248, "Vichy": 7.673267, "Figeac": 2.722772, "Lavaur": 0.742574, "Millau": 2.475248, "Ricoux": 4.455446, "Carmaux": 1.732673, "Gaillac": 3.960396, "Issoire": 5.445545, "Moulins": 5.445545, "Aurillac": 6.683168, "Clermont": 22.772277, "Massagettes": 1.485149, "Villefranche": 1.732673, "Le Puy-en-Velay": 7.178218}	TKT PRODUCTION — MDA	404	Renault	{Renault}	\N	f	f	2026-08-03 16:21:11.743	2026-08-03 16:21:11.743	\N
5b041779-236a-40f0-a2bc-b02cabdff0d8	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — STICKERS BONY	456	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:26.572	2026-08-03 16:21:26.572	\N
8e0c6c1c-856d-41e3-837f-6740f6668d8a	2026-03-01 00:00:00	APV	Albi, Aurillac, Carmaux, Figeac, Gaillac, Millau, Rodez, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Millau,Rodez,Villefranche}	{"Albi": 19.402985, "Rodez": 24.626866, "Figeac": 8.208955, "Millau": 7.089552, "Carmaux": 5.037313, "Gaillac": 11.19403, "Aurillac": 19.402985, "Villefranche": 5.037313}	Print conseil — affiche pneus	536	Renault	{Renault}	\N	f	f	2026-08-03 16:21:27.185	2026-08-03 16:21:27.185	\N
777bff0b-4297-4426-a9c0-5c5c977df1f5	2026-03-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.730351, "Mende": 4.23889, "Mozac": 6.031122, "Rodez": 7.643223, "Ussel": 3.239074, "Vichy": 8.820692, "Figeac": 2.866208, "Lavaur": 1.910806, "Millau": 1.90874, "Ricoux": 4.643774, "Carmaux": 0.764322, "Gaillac": 3.43945, "Issoire": 7.694453, "Moulins": 5.916267, "Aurillac": 3.821611, "Clermont": 19.037822, "Massagettes": 3.239074, "Villefranche": 1.910806, "Le Puy-en-Velay": 7.143315}	Le bon coin — boutique	24204.45	Renault	{Renault}	\N	f	f	2026-08-03 16:20:46.872	2026-08-03 16:20:46.872	\N
e1317d47-0acd-4b8d-9b54-2b451cf12f29	2026-03-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:20:48.99	2026-08-03 16:20:48.99	\N
fddc4272-1060-4eb9-ad94-0abb9676748c	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:20:49.757	2026-08-03 16:20:49.757	\N
36497cac-6f13-448f-8700-37bea7873335	2026-03-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:20:56.873	2026-08-03 16:20:56.873	\N
73be7592-6daf-4e90-89c7-3f5905ef5f98	2026-03-01 00:00:00	VO	Rodez	{Rodez}	{"Rodez": 100}	GRAPHIC — ADHESIFS + BACHE VO NISSAN	671.68	Renault	{Renault}	\N	f	f	2026-08-03 16:21:02.146	2026-08-03 16:21:02.146	\N
c170314a-9e20-4bb8-951c-60ca44f3a39d	2026-03-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — sandartd	222	Renault	{Renault}	\N	f	f	2026-08-03 16:21:03.572	2026-08-03 16:21:03.572	\N
86d82ed5-cf80-4f4f-a741-14eb60e861c9	2026-03-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — sandartd	222	Renault	{Renault}	\N	f	f	2026-08-03 16:21:05.076	2026-08-03 16:21:05.076	\N
29311c3f-825c-4b5d-93b2-057dd7dba28e	2026-03-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — sandartd	222	Renault	{Renault}	\N	f	f	2026-08-03 16:21:05.86	2026-08-03 16:21:05.86	\N
774bc146-02b8-4297-9164-26d61cfdd709	2026-03-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.683168, "Mende": 2.722772, "Mozac": 5.19802, "Rodez": 8.415842, "Ussel": 2.475248, "Vichy": 7.673267, "Figeac": 2.722772, "Lavaur": 0.742574, "Millau": 2.475248, "Ricoux": 4.455446, "Carmaux": 1.732673, "Gaillac": 3.960396, "Issoire": 5.445545, "Moulins": 5.445545, "Aurillac": 6.683168, "Clermont": 22.772277, "Massagettes": 1.485149, "Villefranche": 1.732673, "Le Puy-en-Velay": 7.178218}	TKT PRODUCTION — MDA	404	Renault	{Renault}	\N	f	f	2026-08-03 16:21:10.26	2026-08-03 16:21:10.26	\N
1e0aac32-01a1-4162-a42e-af86edaf39e4	2026-03-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	TKT PRODUCTION — MDA	40	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:14.64	2026-08-03 16:21:14.64	\N
1df67848-af3a-45c2-8238-e828ff96a7f2	2026-03-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.320908, "Mende": 6.320908, "Mozac": 3.079417, "Rodez": 9.400324, "Ussel": 6.320908, "Vichy": 6.320908, "Figeac": 3.079417, "Millau": 3.079417, "Ricoux": 3.079417, "Gaillac": 3.079417, "Issoire": 9.23825, "Moulins": 6.320908, "Aurillac": 6.320908, "Clermont": 12.479741, "Massagettes": 3.079417, "Villefranche": 3.079417, "Le Puy-en-Velay": 9.400324}	Print — Doc ROOLE	617	Renault	{Renault}	\N	f	f	2026-08-03 16:21:21.129	2026-08-03 16:21:21.129	\N
49fadabf-e174-4952-94b4-1546e0f46164	2026-03-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	GRAPHIC — BACHE RENAULT VDR	112.6	Renault	{Renault}	\N	f	f	2026-08-03 16:21:21.842	2026-08-03 16:21:21.842	\N
5a603c9f-5a56-4e6f-a2bf-7f432e1ba160	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	POINT MARQUAGE — supplément plv twingo clf	178	Renault	{Renault}	\N	f	f	2026-08-03 16:21:26.005	2026-08-03 16:21:26.005	\N
896a3ef7-284a-4eeb-9911-34f6f8d52725	2026-03-01 00:00:00	APV	Rodez	{Rodez}	{"Rodez": 100}	Brugier Sérigraphie — Bon pour lavage	40	Renault	{Renault}	\N	f	f	2026-08-03 16:21:30.106	2026-08-03 16:21:30.106	\N
91196343-64c0-4717-b1a2-d05c3ba65905	2026-03-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.683168, "Mende": 2.722772, "Mozac": 5.19802, "Rodez": 8.415842, "Ussel": 2.475248, "Vichy": 7.673267, "Figeac": 2.722772, "Lavaur": 0.742574, "Millau": 2.475248, "Ricoux": 4.455446, "Carmaux": 1.732673, "Gaillac": 3.960396, "Issoire": 5.445545, "Moulins": 5.445545, "Aurillac": 6.683168, "Clermont": 22.772277, "Massagettes": 1.485149, "Villefranche": 1.732673, "Le Puy-en-Velay": 7.178218}	TKT PRODUCTION — MDA	404	Renault	{Renault}	\N	f	f	2026-08-03 16:21:18.876	2026-08-03 16:21:18.876	\N
e4c5d4cc-d4f0-4665-97de-f03d7d40a415	2026-03-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	TKT PRODUCTION — MDA	40	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:19.676	2026-08-03 16:21:19.676	\N
f68d9b39-0975-4bc2-83de-2825a23a664c	2026-03-01 00:00:00	VN	Albi	{Albi}	{"Albi": 100}	GRAPHIC — BACHE DACIA ALBI	112.6	Renault	{Renault}	\N	f	f	2026-08-03 16:21:22.572	2026-08-03 16:21:22.572	\N
076ca7d4-4a49-4bb4-b4fb-31b3d000a19f	2026-03-01 00:00:00	VN	Clermont, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Ussel, Vichy	{Clermont,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Ussel,Vichy}	{"Mende": 4.917908, "Mozac": 6.559756, "Ussel": 4.917908, "Vichy": 8.193967, "Ricoux": 4.100802, "Issoire": 8.193967, "Moulins": 8.193967, "Clermont": 40.985109, "Massagettes": 2.458954, "Le Puy-en-Velay": 11.477663}	CISCAR — portes cartes véhicules	13095	Renault	{Renault}	\N	f	f	2026-08-03 16:21:24.021	2026-08-03 16:21:24.021	\N
7e2649a5-39ef-49cd-b2af-dd3f9ffb2ee1	2026-03-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	GRAPHIC — Bâches Renault Dacia / Issoire et Brioude	427	Renault	{Renault}	\N	f	f	2026-08-03 16:21:31.339	2026-08-03 16:21:31.339	\N
1295de00-99c2-4bfb-9097-f6aaba7361c8	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	lacoulisse — Loc ecran	63	Renault	{Renault}	\N	f	f	2026-08-03 16:21:32.206	2026-08-03 16:21:32.206	\N
6281afc9-d5d3-4aca-bee0-2bc23f487cc8	2026-03-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	GRAPHIC — Stickers CT PRET A PARTIR	150	Renault	{Renault}	\N	f	f	2026-08-03 16:21:33.29	2026-08-03 16:21:33.29	\N
6f6bc2d3-a619-42e1-b7f5-39b786dee4cc	2026-03-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	GRAPHIC — Kit Mobilize pour VL	190	Renault	{Renault}	\N	f	f	2026-08-03 16:21:34.14	2026-08-03 16:21:34.14	\N
247b39a4-a11d-4f1e-8009-60c12a184fe6	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — bony pass nissan	211	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:35.189	2026-08-03 16:21:35.189	\N
268f3517-dc16-412c-8323-dd11d3b85e46	2026-03-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — bony pass nissan	211	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:36.107	2026-08-03 16:21:36.107	\N
911ce8dd-ce6d-4872-b61a-33aabe638746	2026-03-01 00:00:00	VN	Albi, Clermont, Mozac	{Albi,Clermont,Mozac}	{"Albi": 24.888889, "Mozac": 24.888889, "Clermont": 50.222222}	PRINT CONSEIL — invitation papier twingo	225	Renault	{Renault}	\N	f	f	2026-08-03 16:21:37.24	2026-08-03 16:21:37.24	\N
8d5b3701-3847-489c-af7f-4dcea29499b4	2026-03-01 00:00:00	VN	Massagettes	{Massagettes}	{"Massagettes": 100}	LVMR — mobilier retraite eric	102.89	Renault	{Renault}	\N	f	f	2026-08-03 16:21:38.156	2026-08-03 16:21:38.156	\N
27c62db9-289a-4fc9-ab91-c6d36e89b161	2026-03-01 00:00:00	VO	Massagettes	{Massagettes}	{"Massagettes": 100}	LVMR — mobilier retraite eric	102.89	Renault	{Renault}	\N	f	f	2026-08-03 16:21:39.322	2026-08-03 16:21:39.322	\N
687b37e0-858e-4dad-84ae-03aba89a046f	2026-03-01 00:00:00	PR	Massagettes	{Massagettes}	{"Massagettes": 100}	LVMR — mobilier retraite eric	102.89	Renault	{Renault}	\N	f	f	2026-08-03 16:21:40.207	2026-08-03 16:21:40.207	\N
0b0e77ca-8311-4ebe-868c-be87a7ff7afc	2026-03-01 00:00:00	APV	Massagettes	{Massagettes}	{"Massagettes": 100}	LVMR — mobilier retraite eric	102.89	Renault	{Renault}	\N	f	f	2026-08-03 16:21:41.256	2026-08-03 16:21:41.256	\N
8ba2e3f4-0880-42a3-be8c-6ec6301de2df	2026-03-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	TOUBKALPES — OPERATION VO NISSAN	1000	Nissan	{Nissan}	\N	f	f	2026-08-03 16:21:42.489	2026-08-03 16:21:42.489	\N
219e2c8b-4a97-4cef-8110-584bc18e18df	2026-03-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	LE VENT A LA FRANCAISE — 30 bracelets Alpine	607	Renault	{Renault}	\N	f	f	2026-08-03 16:21:43.124	2026-08-03 16:21:43.124	\N
73015163-d23b-4a48-89a6-76e3516cdbf9	2026-03-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	LE VENT A LA FRANCAISE — 30 bracelets Alpine	607	Renault	{Renault}	\N	f	f	2026-08-03 16:21:44.157	2026-08-03 16:21:44.157	\N
6bff6c77-3e3b-4f00-9f3f-21944e6a81f5	2026-03-01 00:00:00	VN	Clermont, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ussel, Vichy	{Clermont,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ussel,Vichy}	{"Mende": 11.095843, "Mozac": 11.095843, "Ussel": 11.095843, "Vichy": 11.095843, "Issoire": 11.095843, "Moulins": 11.130196, "Clermont": 11.164548, "Massagettes": 11.095843, "Le Puy-en-Velay": 11.130196}	PUBLICIS ACTIV — KIT PLV JOURNEES ESSAIS	2911	Renault	{Renault}	\N	f	f	2026-08-03 16:21:45.106	2026-08-03 16:21:45.106	\N
b354b04f-2433-4347-aa2a-8bd39e60874a	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — affiche pro+	46	Renault	{Renault}	\N	f	f	2026-08-03 16:21:46.222	2026-08-03 16:21:46.222	\N
a76a3c2e-f996-4c3b-b5ea-d91487fdfbf4	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — croquis twingo	36	Renault	{Renault}	\N	f	f	2026-08-03 16:21:47.154	2026-08-03 16:21:47.154	\N
428fd8d5-0cb0-4605-9d10-49053e973134	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — pochette A5 APV	529	Alpine	{Alpine}	\N	f	f	2026-08-03 16:21:48.344	2026-08-03 16:21:48.344	\N
33fcee26-bda5-4e09-84db-5846388664f0	2026-03-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — pochette A4 VN	707	Alpine	{Alpine}	\N	f	f	2026-08-03 16:21:49.141	2026-08-03 16:21:49.141	\N
dc165ac9-f480-4383-8015-05eea254be3b	2026-03-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — etiquette vidange	362	Alpine	{Alpine}	\N	f	f	2026-08-03 16:21:50.207	2026-08-03 16:21:50.207	\N
2f34ea07-b357-4d51-b48b-611ff7cfb096	2026-03-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	lineshift	225	Renault	{Renault}	\N	f	f	2026-08-03 16:22:07.541	2026-08-03 16:22:07.541	\N
6c531e27-16d3-4657-b5fd-bf5f1b8408c3	2026-03-01 00:00:00	VO	Issoire	{Issoire}	{"Issoire": 100}	lineshift	225	Renault	{Renault}	\N	f	f	2026-08-03 16:22:08.324	2026-08-03 16:22:08.324	\N
1a231fe7-9240-4c8c-be5f-0f87bb1dba27	2026-03-01 00:00:00	VN	Mozac	{Mozac}	{"Mozac": 100}	point marquage — stickers five blanc	87	Renault	{Renault}	\N	f	f	2026-08-03 16:22:11.173	2026-08-03 16:22:11.173	\N
ba189531-fba2-4dfb-bcea-825a85f22d76	2026-03-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.734694, "Mende": 2.857143, "Mozac": 5.102041, "Rodez": 8.367347, "Ussel": 2.44898, "Vichy": 7.755102, "Figeac": 2.857143, "Lavaur": 0.612245, "Millau": 2.44898, "Ricoux": 4.285714, "Carmaux": 1.836735, "Gaillac": 3.877551, "Issoire": 5.510204, "Moulins": 5.510204, "Aurillac": 6.734694, "Clermont": 22.44898, "Massagettes": 1.632653, "Villefranche": 1.836735, "Le Puy-en-Velay": 7.142857}	TKT PRODUCTION — MDA	490	Renault	{Renault}	\N	f	f	2026-08-03 16:22:19.356	2026-08-03 16:22:19.356	\N
b93c944b-e5b2-4e3b-8154-81ff0a8941bd	2026-03-01 00:00:00	VN	Clermont, Le Puy-en-Velay, Rodez, Vichy	{Clermont,"Le Puy-en-Velay",Rodez,Vichy}	{"Rodez": 25.225225, "Vichy": 24.924925, "Clermont": 24.924925, "Le Puy-en-Velay": 24.924925}	DEBREZ — VOILES VENTES PRIVEES	333	Renault	{Renault}	\N	f	f	2026-08-03 16:22:23.123	2026-08-03 16:22:23.123	\N
03ff9530-dff1-4a8d-9382-5d7fb83e9141	2026-03-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:22:36.106	2026-08-03 16:22:36.106	\N
e8708086-391c-4039-95dc-f424133523c4	2026-04-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:22:46.328	2026-08-03 16:22:46.328	\N
f1776459-9ef2-4796-81b9-762ce443f8bf	2026-04-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:50.361	2026-08-03 16:22:50.361	\N
79f5cc3e-7741-4b94-b55d-330a3f38af51	2026-04-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:22:54.182	2026-08-03 16:22:54.182	\N
b99c3212-d013-489a-aa3e-0df757f1e1d2	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Print — ROOLE nisan	211	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:57.278	2026-08-03 16:22:57.278	\N
01921971-b368-4a3f-9e84-9e9cd4b1a578	2026-04-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:22:59.403	2026-08-03 16:22:59.403	\N
62f86233-0665-41ee-9ad0-d62813acfe80	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Bloctel — worldwine	285	Renault	{Renault}	\N	f	f	2026-08-03 16:23:15.379	2026-08-03 16:23:15.379	\N
0f3230ab-4f97-4e24-8410-2ad961a00bff	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	lacoulisse — ecran projo	78.75	Renault	{Renault}	\N	f	f	2026-08-03 16:23:20.192	2026-08-03 16:23:20.192	\N
b6ef62ae-c582-476b-88ac-6ee8ceb6acce	2026-03-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	PRINT CONSEIL — 100 étiquettes Google	51	Renault	{Renault}	\N	f	f	2026-08-03 16:21:51.106	2026-08-03 16:21:51.106	\N
0253b920-2809-44e1-bec9-1ab1dd5902b6	2026-03-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	PRINT CONSEIL — 100 pochettes VN A4 Vichy	353	Renault	{Renault}	\N	f	f	2026-08-03 16:22:01.189	2026-08-03 16:22:01.189	\N
ecd0ddee-09ee-456c-ac7c-b0135a250fe4	2026-03-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	PRINT CONSEIL — 50 pochettes APV A5 Vichy	176	Renault	{Renault}	\N	f	f	2026-08-03 16:22:02.155	2026-08-03 16:22:02.155	\N
ca19b246-cbcb-4ddc-a003-855d9026a4ac	2026-03-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	PRINT CONSEIL — 50 pochettes APV A5 Le Puy	177	Renault	{Renault}	\N	f	f	2026-08-03 16:22:04.154	2026-08-03 16:22:04.154	\N
f20b381d-6c22-406c-9f34-9b19297a5202	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — MUR D'IMAGE	345.5	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:06.24	2026-08-03 16:22:06.24	\N
ebbf8ece-6164-42fc-8fd5-a3e76f7c9ce4	2026-03-01 00:00:00	APV	Issoire	{Issoire}	{"Issoire": 100}	lineshift	225	Renault	{Renault}	\N	f	f	2026-08-03 16:22:09.139	2026-08-03 16:22:09.139	\N
6f20e58c-cf94-4c3c-8d55-42957ce90ee9	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	TKT PRODUCTION — MDA	48	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:14.174	2026-08-03 16:22:14.174	\N
d470feb0-50ad-4508-b430-89ef184c1a1f	2026-03-01 00:00:00	VN	Clermont, Le Puy-en-Velay, Rodez, Vichy	{Clermont,"Le Puy-en-Velay",Rodez,Vichy}	{"Rodez": 25.405405, "Vichy": 24.864865, "Clermont": 24.864865, "Le Puy-en-Velay": 24.864865}	PRINT CONSEIL — PRINT VENTES PRIVEES	185	Renault	{Renault}	\N	f	f	2026-08-03 16:22:22.256	2026-08-03 16:22:22.256	\N
e667f4a0-f118-44d3-9a07-20947a4b21a7	2026-03-01 00:00:00	VN	Clermont, Le Puy-en-Velay, Rodez, Vichy	{Clermont,"Le Puy-en-Velay",Rodez,Vichy}	{"Rodez": 24.879227, "Vichy": 25.120773, "Clermont": 25.120773, "Le Puy-en-Velay": 24.879227}	LPTENT — DESK VENTES PRIVEES	414	Renault	{Renault}	\N	f	f	2026-08-03 16:22:24.174	2026-08-03 16:22:24.174	\N
31661812-c150-4f1e-aa6e-e0a3d1d4f953	2026-03-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — phtoo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:22:41.962	2026-08-03 16:22:41.962	\N
7b1b770a-1890-429a-b6b1-302c72bbc25e	2026-04-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	3604	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:45.159	2026-08-03 16:22:45.159	\N
98a6d84f-56c4-4fcd-b64d-0eba3a3cee99	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	453	Renault	{Renault}	\N	f	f	2026-08-03 16:22:45.748	2026-08-03 16:22:45.748	\N
09722e9d-a957-4311-9604-deb87d52b3b4	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:47.3	2026-08-03 16:22:47.3	\N
041110ab-067e-423d-898b-5d7e89eaace1	2026-04-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:22:47.994	2026-08-03 16:22:47.994	\N
efe10e50-dd10-4846-b6e8-132eb90e2282	2026-04-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:48.709	2026-08-03 16:22:48.709	\N
5fb7be8e-25bd-4859-a1ad-26dc4b737a7a	2026-04-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:22:52.612	2026-08-03 16:22:52.612	\N
66578dee-d15b-4282-a3de-39b671f272b7	2026-04-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:23:00.876	2026-08-03 16:23:00.876	\N
28a6277f-19e8-4f6a-9b00-215dee5aa248	2026-04-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:23:01.767	2026-08-03 16:23:01.767	\N
f8e39410-c39e-4943-a43a-2d8ebd5be715	2026-03-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	PRINT CONSEIL — 100 étiquettes Google	51	Renault	{Renault}	\N	f	f	2026-08-03 16:21:52.34	2026-08-03 16:21:52.34	\N
e8276cb1-ff6e-47a8-a944-262ff4266f2b	2026-03-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	PRINT CONSEIL — 50 pochettes VN A4 Le Puy	176	Renault	{Renault}	\N	f	f	2026-08-03 16:22:03.207	2026-08-03 16:22:03.207	\N
55dadc7f-e40c-4192-bf71-db100dcc7705	2026-03-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	TKT PRODUCTION — MDA	48	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:16.123	2026-08-03 16:22:16.123	\N
8eb62e0e-52c2-400f-9a13-47291066a082	2026-03-01 00:00:00	VO	Issoire	{Issoire}	{"Issoire": 100}	GRAPHIC — stickers 888€ + affaire de la semaine	428.15	Renault	{Renault}	\N	f	f	2026-08-03 16:22:21.156	2026-08-03 16:22:21.156	\N
bfa67845-5afd-4674-9561-c270b08ff3b6	2026-03-01 00:00:00	VN	Clermont, Le Puy-en-Velay, Rodez, Vichy	{Clermont,"Le Puy-en-Velay",Rodez,Vichy}	{"Rodez": 25, "Vichy": 25, "Clermont": 25, "Le Puy-en-Velay": 25}	GRAPHIC — KAKEMONO VENTES PRIVEES	151.6	Renault	{Renault}	\N	f	f	2026-08-03 16:22:25.14	2026-08-03 16:22:25.14	\N
124eee1f-282c-46a5-845a-3f29307bd160	2026-03-01 00:00:00	VN	Albi, Aurillac, Figeac, Gaillac	{Albi,Aurillac,Figeac,Gaillac}	{"Albi": 24.884438, "Figeac": 24.961479, "Gaillac": 25.038521, "Aurillac": 25.115562}	PUBLICIS ACTIV — KIT PLV JOURNEES ESSAIS	1298	Renault	{Renault}	\N	f	f	2026-08-03 16:22:27.158	2026-08-03 16:22:27.158	\N
4d4f3cd1-2095-444a-88f9-05615757cac6	2026-03-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:22:30.207	2026-08-03 16:22:30.207	\N
defe835c-d042-480c-a1b4-f2fa2b9712df	2026-03-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:22:32.258	2026-08-03 16:22:32.258	\N
5f14fdb1-1382-4757-a5d4-557c2ee19df0	2026-03-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:33.206	2026-08-03 16:22:33.206	\N
b53e40db-e0ac-4e6b-b38c-34047f06f123	2026-04-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.730351, "Mende": 4.23889, "Mozac": 6.031122, "Rodez": 7.643223, "Ussel": 3.239074, "Vichy": 8.820692, "Figeac": 2.866208, "Lavaur": 1.910806, "Millau": 1.90874, "Ricoux": 4.643774, "Carmaux": 0.764322, "Gaillac": 3.43945, "Issoire": 7.694453, "Moulins": 5.916267, "Aurillac": 3.821611, "Clermont": 19.037822, "Massagettes": 3.239074, "Villefranche": 1.910806, "Le Puy-en-Velay": 7.143315}	Le bon coin — boutique	24204.45	Renault	{Renault}	\N	f	f	2026-08-03 16:22:44.11	2026-08-03 16:22:44.11	\N
3b0e99a8-9537-4679-9361-986f04c83a1c	2026-04-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:22:54.929	2026-08-03 16:22:54.929	\N
a81c8be1-ee84-4a6c-beae-9b6fa7344666	2026-04-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:22:58.177	2026-08-03 16:22:58.177	\N
a742ca31-2e05-4392-abec-1066d25a64a8	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:58.827	2026-08-03 16:22:58.827	\N
16a86f8f-8410-43cb-a888-f7323da547ba	2026-04-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:23:00.236	2026-08-03 16:23:00.236	\N
574d568e-f062-4732-8ebb-1c3551bcc51e	2026-04-01 00:00:00	VN	Ussel	{Ussel}	{"Ussel": 100}	rugby store — vetement ussel	75	Renault	{Renault}	\N	f	f	2026-08-03 16:23:21.292	2026-08-03 16:23:21.292	\N
7e785d9b-40e2-4c70-a75d-ffa2d7806494	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — 150 étiquettes Google	76	Alpine	{Alpine}	\N	f	f	2026-08-03 16:21:53.156	2026-08-03 16:21:53.156	\N
283ff5c3-3141-49c9-9e5d-c03c8f3f30de	2026-03-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — 300 pochettes APV A5 Clermont	1058	Alpine	{Alpine}	\N	f	f	2026-08-03 16:22:00.357	2026-08-03 16:22:00.357	\N
9874088c-16fe-41db-881c-4b72f314541c	2026-03-01 00:00:00	VN	Mozac	{Mozac}	{"Mozac": 100}	print conseil — chevalets et stickers mozac dacia	166	Renault	{Renault}	\N	f	f	2026-08-03 16:22:10.157	2026-08-03 16:22:10.157	\N
7ea9a60a-e556-4c65-92dc-93b14a6a26e2	2026-03-01 00:00:00	VN	Ricoux	{Ricoux}	{"Ricoux": 100}	GRAPHIC — PLAQUES PORTE THIERS	307.54	Renault	{Renault}	\N	f	f	2026-08-03 16:22:12.291	2026-08-03 16:22:12.291	\N
686b24a4-6216-4a9b-b1ef-0cacad1b5419	2026-03-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	point marquage — plv pro+	74	Renault	{Renault}	\N	f	f	2026-08-03 16:22:26.258	2026-08-03 16:22:26.258	\N
b0613308-0ec0-47b0-8dbe-be6a0d945786	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:29.124	2026-08-03 16:22:29.124	\N
8adbc85a-7236-4489-be9c-aae2e95d96c6	2026-03-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:35.174	2026-08-03 16:22:35.174	\N
16fbd125-2a70-49d0-aa20-ad79c94c2844	2026-04-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:22:49.368	2026-08-03 16:22:49.368	\N
b78c2703-592b-4698-8250-4b021a3ab36a	2026-04-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:22:53.233	2026-08-03 16:22:53.233	\N
e051cddc-ea2b-4cb5-b011-0cebf817c9e1	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — STICKERS MOBILIZE ESSENCE SANS PLOMB	128.25	Renault	{Renault}	\N	f	f	2026-08-03 16:22:55.848	2026-08-03 16:22:55.848	\N
4683342e-d492-43c4-93c7-d983fc4bcac6	2026-04-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	SPOT2COM — STICKERS TOWNSTAR	197.5	Renault	{Renault}	\N	f	f	2026-08-03 16:23:05.263	2026-08-03 16:23:05.263	\N
193d68a7-b719-4582-8c99-b7226bb8f2a8	2026-04-01 00:00:00	VN	Massagettes	{Massagettes}	{"Massagettes": 100}	GRAPHIC — Stickage Vitrine	425	Renault	{Renault}	\N	f	f	2026-08-03 16:23:07.495	2026-08-03 16:23:07.495	\N
d1d952d2-2a5b-433a-bdb8-5471c8bf8224	2026-04-01 00:00:00	VN	Figeac, Villefranche	{Figeac,Villefranche}	{"Figeac": 18.424963, "Villefranche": 81.575037}	GRAPHIC — Stickers Bony	336.5	Renault	{Renault}	\N	f	f	2026-08-03 16:23:13.98	2026-08-03 16:23:13.98	\N
3236e514-c9aa-400b-9ec4-b45f4496a50f	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	CISCAR — portes cartes véhicules	222	Renault	{Renault}	\N	f	f	2026-08-03 16:23:14.661	2026-08-03 16:23:14.661	\N
20e3f57e-d009-4829-a91b-3a74b2f75025	2026-04-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Bloctel — worldwine	285	Renault	{Renault}	\N	f	f	2026-08-03 16:23:16.04	2026-08-03 16:23:16.04	\N
7f9237a7-8755-4294-8fbf-8a43bf2ad808	2026-04-01 00:00:00	PR	Ussel	{Ussel}	{"Ussel": 100}	rugby store — vetement ussel	75	Renault	{Renault}	\N	f	f	2026-08-03 16:23:23.358	2026-08-03 16:23:23.358	\N
4f173d62-f358-4a9e-8bdd-fb842fecd39b	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	AHB — attache cache plaque	109	Renault	{Renault}	\N	f	f	2026-08-03 16:23:25.193	2026-08-03 16:23:25.193	\N
7f19a535-fcb0-444b-ba00-c8ed4f600e41	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LLD BONY — véhicule rougerie	985	Renault	{Renault}	\N	f	f	2026-08-03 16:23:29.158	2026-08-03 16:23:29.158	\N
482bb512-2f3e-4f63-b654-66da1c674d66	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — 100 Pochettes VN A4 Clermont	353	Alpine	{Alpine}	\N	f	f	2026-08-03 16:21:56.914	2026-08-03 16:21:56.914	\N
f70db640-b62e-430f-b9cd-ef9c1f2da835	2026-03-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	point marquage — plv pro+	74	Renault	{Renault}	\N	f	f	2026-08-03 16:22:05.256	2026-08-03 16:22:05.256	\N
9caad676-b593-46f6-956e-df9472807478	2026-03-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	TKT PRODUCTION — MDA	48	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:18.277	2026-08-03 16:22:18.277	\N
09bca2ed-2163-4fb3-89e3-959ba08bcaef	2026-03-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	TKT PRODUCTION — MDA	48	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:20.239	2026-08-03 16:22:20.239	\N
dc9fb468-d1fb-4484-bbd9-6bff20e8120a	2026-03-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:39.877	2026-08-03 16:22:39.877	\N
a63b8437-75b6-4dc6-bfee-5d43a721f201	2026-03-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — phtoo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:43.125	2026-08-03 16:22:43.125	\N
98fba999-0a40-4f74-83ba-50e51fe4588b	2026-04-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:22:51.112	2026-08-03 16:22:51.112	\N
1c37a09e-e4d8-4bb4-b8b4-c2257f1f86ee	2026-04-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:51.828	2026-08-03 16:22:51.828	\N
cfed6447-2758-47f3-98d6-b693a3c44694	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	JPH PUB — Merch alpine bony staff	493	Alpine	{Alpine}	\N	f	f	2026-08-03 16:23:04.62	2026-08-03 16:23:04.62	\N
70edbece-7f4a-435f-8b7d-b46757edd05a	2026-03-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.734694, "Mende": 2.857143, "Mozac": 5.102041, "Rodez": 8.367347, "Ussel": 2.44898, "Vichy": 7.755102, "Figeac": 2.857143, "Lavaur": 0.612245, "Millau": 2.44898, "Ricoux": 4.285714, "Carmaux": 1.836735, "Gaillac": 3.877551, "Issoire": 5.510204, "Moulins": 5.510204, "Aurillac": 6.734694, "Clermont": 22.44898, "Massagettes": 1.632653, "Villefranche": 1.836735, "Le Puy-en-Velay": 7.142857}	TKT PRODUCTION — MDA	490	Renault	{Renault}	\N	f	f	2026-08-03 16:22:13.138	2026-08-03 16:22:13.138	\N
51da1f07-1a62-4350-9bc5-0e174fd7885a	2026-03-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.734694, "Mende": 2.857143, "Mozac": 5.102041, "Rodez": 8.367347, "Ussel": 2.44898, "Vichy": 7.755102, "Figeac": 2.857143, "Lavaur": 0.612245, "Millau": 2.44898, "Ricoux": 4.285714, "Carmaux": 1.836735, "Gaillac": 3.877551, "Issoire": 5.510204, "Moulins": 5.510204, "Aurillac": 6.734694, "Clermont": 22.44898, "Massagettes": 1.632653, "Villefranche": 1.836735, "Le Puy-en-Velay": 7.142857}	TKT PRODUCTION — MDA	490	Renault	{Renault}	\N	f	f	2026-08-03 16:22:15.19	2026-08-03 16:22:15.19	\N
27a9df8c-564b-41d9-b52e-e81346e713e1	2026-03-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.734694, "Mende": 2.857143, "Mozac": 5.102041, "Rodez": 8.367347, "Ussel": 2.44898, "Vichy": 7.755102, "Figeac": 2.857143, "Lavaur": 0.612245, "Millau": 2.44898, "Ricoux": 4.285714, "Carmaux": 1.836735, "Gaillac": 3.877551, "Issoire": 5.510204, "Moulins": 5.510204, "Aurillac": 6.734694, "Clermont": 22.44898, "Massagettes": 1.632653, "Villefranche": 1.836735, "Le Puy-en-Velay": 7.142857}	TKT PRODUCTION — MDA	490	Renault	{Renault}	\N	f	f	2026-08-03 16:22:17.257	2026-08-03 16:22:17.257	\N
a9db3142-21dd-4166-92b6-efab572f8143	2026-03-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:22:28.123	2026-08-03 16:22:28.123	\N
db9960e5-310c-4c33-ab75-9b9a971c2b37	2026-03-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:31.106	2026-08-03 16:22:31.106	\N
958ed22b-b111-4f80-af27-f01ba78984cc	2026-03-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:22:34.137	2026-08-03 16:22:34.137	\N
3005413c-dc5d-4914-93a5-413892582e14	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Print — ROOLE nisan	211	Nissan	{Nissan}	\N	f	f	2026-08-03 16:22:56.712	2026-08-03 16:22:56.712	\N
8b1ec935-353b-4dfd-8a8e-b20466d42c86	2026-04-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:23:03.258	2026-08-03 16:23:03.258	\N
3c6e517e-9bb7-449a-a790-7ba2203f9632	2026-04-01 00:00:00	VN	Ussel	{Ussel}	{"Ussel": 100}	GRAPHIC — Stickage Vitrine	425	Renault	{Renault}	\N	f	f	2026-08-03 16:23:10.431	2026-08-03 16:23:10.431	\N
6b40fb30-fd77-459c-9dfe-63e6325f3dac	2026-04-01 00:00:00	VN	Clermont, Le Puy-en-Velay, Rodez, Vichy	{Clermont,"Le Puy-en-Velay",Rodez,Vichy}	{"Rodez": 25, "Vichy": 25, "Clermont": 25, "Le Puy-en-Velay": 25}	PRINT CONSEIL — VISUELS VP RAPHAEL	185	Renault	{Renault}	\N	f	f	2026-08-03 16:23:16.692	2026-08-03 16:23:16.692	\N
8d0967de-0179-401c-ae3f-65dea8a918cd	2026-04-01 00:00:00	VN	Ricoux	{Ricoux}	{"Ricoux": 100}	PROTEXTILES — Tee-shirts Thiers	107	Renault	{Renault}	\N	f	f	2026-08-03 16:23:17.284	2026-08-03 16:23:17.284	\N
e2d2de55-551e-4270-93ec-d38afb581b93	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	CHAB EVOLUTION — week-end Nogaro	700	Alpine	{Alpine}	\N	f	f	2026-08-03 16:23:18.209	2026-08-03 16:23:18.209	\N
17c88216-8065-4dc7-a335-8688d9364f79	2026-04-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:23:02.58	2026-08-03 16:23:02.58	\N
ba35c3fe-6957-4950-95e6-e429c2c03c46	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	MALARTRE ERIC — 15 revue Alpine Spirit	750	Alpine	{Alpine}	\N	f	f	2026-08-03 16:23:06.095	2026-08-03 16:23:06.095	\N
21bc8621-9d2e-4198-b75a-4c83967c2ccb	2026-04-01 00:00:00	VN	Mozac	{Mozac}	{"Mozac": 100}	GRAPHIC — Stickage Vitrine	425	Renault	{Renault}	\N	f	f	2026-08-03 16:23:06.757	2026-08-03 16:23:06.757	\N
ce47ee29-de64-4a95-86a5-a5a0c7456c81	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — Stickage Vitrine	935	Renault	{Renault}	\N	f	f	2026-08-03 16:23:13.112	2026-08-03 16:23:13.112	\N
45c662df-e9ed-461e-bac4-aac95fb754e2	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — STICKER VH AURELIEN ROUGERIE	130	Renault	{Renault}	\N	f	f	2026-08-03 16:23:19.26	2026-08-03 16:23:19.26	\N
ed7e7d18-26c0-41e1-a8bf-7f0ef4483d52	2026-04-01 00:00:00	APV	Ussel	{Ussel}	{"Ussel": 100}	rugby store — vetement ussel	75	Renault	{Renault}	\N	f	f	2026-08-03 16:23:24.208	2026-08-03 16:23:24.208	\N
356f245e-382e-491a-8a88-eac76ca2a2fb	2026-04-01 00:00:00	APV	Mozac	{Mozac}	{"Mozac": 100}	GRAPHIC — panneau atelier mozac	164.7	Renault	{Renault}	\N	f	f	2026-08-03 16:23:26.357	2026-08-03 16:23:26.357	\N
26490724-5617-4548-8b3d-447ee4fef9b3	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — stickers vitre arrière x300 prepa	720	Renault	{Renault}	\N	f	f	2026-08-03 16:23:27.276	2026-08-03 16:23:27.276	\N
f3522fb5-abe1-4643-b10c-97f82c9edd06	2026-04-01 00:00:00	VO	Ussel	{Ussel}	{"Ussel": 100}	rugby store — vetement ussel	75	Renault	{Renault}	\N	f	f	2026-08-03 16:23:22.176	2026-08-03 16:23:22.176	\N
a598c463-4409-4884-b667-bbd5ab556020	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	PORCU — cartes des différents servcies	215	Renault	{Renault}	\N	f	f	2026-08-03 16:23:28.225	2026-08-03 16:23:28.225	\N
7fd482be-e96e-4977-80a3-d38b0425c3f0	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LVMR — Housses matinée dynabuy Nissan	75.7	Nissan	{Nissan}	\N	f	f	2026-08-03 16:23:30.391	2026-08-03 16:23:30.391	\N
d24d0763-25e1-47cd-a8a0-d2344f895116	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LVMR — Housses déj nissan corporace	42.43	Nissan	{Nissan}	\N	f	f	2026-08-03 16:23:31.208	2026-08-03 16:23:31.208	\N
8815e84c-f0e5-49c8-abc2-e7ce5424b8ac	2026-04-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:23:32.208	2026-08-03 16:23:32.208	\N
1fd15830-97c7-44ea-8797-227f3ac4291e	2026-04-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:23:36.393	2026-08-03 16:23:36.393	\N
baa8a349-f08b-4e4e-8a18-11bb3ff4a715	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Les halles du brezet — Expo + soirée Nissan	500	Nissan	{Nissan}	\N	f	f	2026-08-03 16:23:37.092	2026-08-03 16:23:37.092	\N
a12339a3-4131-43bc-a996-1d690c427d77	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	les halles du Brezet — Places Festiv'halles	1250	Nissan	{Nissan}	\N	f	f	2026-08-03 16:23:37.727	2026-08-03 16:23:37.727	\N
36774658-375b-490c-81b9-57e628a2a15a	2026-04-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	DAMIEN DESS — Instructeur circuit	300	Renault	{Renault}	\N	f	f	2026-08-03 16:23:38.292	2026-08-03 16:23:38.292	\N
d88fc761-250c-4f18-994f-e79897eb21c1	2026-04-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	DANIEL GOLEBIEWSKI — Instructeur circuit	300	Renault	{Renault}	\N	f	f	2026-08-03 16:23:38.926	2026-08-03 16:23:38.926	\N
04720a22-1cd7-4c86-bc51-bb9a570cd8f9	2026-04-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	graphic — etiquette apv	166.8	Renault	{Renault}	\N	f	f	2026-08-03 16:23:39.458	2026-08-03 16:23:39.458	\N
6d18bec3-45ec-430b-b9fe-135640382909	2026-04-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:23:39.974	2026-08-03 16:23:39.974	\N
2b9318ff-d5e6-4164-a9c8-734de84e8c27	2026-04-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:23:40.231	2026-08-03 16:23:40.231	\N
909440b7-6c54-401f-967b-21de2a2dd3a6	2026-04-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	DIAGO — vichy	45	Alpine	{Alpine}	\N	f	f	2026-08-03 16:23:45.358	2026-08-03 16:23:45.358	\N
d4a940be-02fe-4b99-80e2-b6ce7df9558a	2026-04-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:23:50.292	2026-08-03 16:23:50.292	\N
970dd093-1de3-43a2-ad9f-155397ee95ff	2026-04-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:23:53.826	2026-08-03 16:23:53.826	\N
a517808d-9e0f-48ee-9880-338acbf21f7f	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	TOMMY MULTIMEDIA — SPOT RADIO PML	120	Nissan	{Nissan}	\N	f	f	2026-08-03 16:23:56.86	2026-08-03 16:23:56.86	\N
8daed2da-84d6-42c4-b68d-71bfbcd730e6	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — STICKERS BONY NISSAN ST ETIENNE	144.34	Nissan	{Nissan}	\N	f	f	2026-08-03 16:23:57.865	2026-08-03 16:23:57.865	\N
abbbe1ae-c87a-4bf5-8334-aaa59b93b7fa	2026-04-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	creation gourmande — plateaux rpas	189.97	Renault	{Renault}	\N	f	f	2026-08-03 16:23:58.799	2026-08-03 16:23:58.799	\N
edf55b8e-14d4-40d7-9662-b9256afef573	2026-04-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	PUB&DECO — POSE STICKER TWINGO	390	Renault	{Renault}	\N	f	f	2026-08-03 16:23:59.549	2026-08-03 16:23:59.549	\N
6524bc5a-6358-4b25-abb0-f736faf6a476	2026-04-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — phtoo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:24:00.265	2026-08-03 16:24:00.265	\N
05f1a603-7608-42a6-9705-c43816ec25cc	2026-04-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — phtoo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:00.959	2026-08-03 16:24:00.959	\N
8f6d1479-569a-47c1-acf4-3fdec42261c5	2026-05-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:04.717	2026-08-03 16:24:04.717	\N
d19072ab-3ecc-4af4-8241-85d90cea53f7	2026-05-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	200	Renault	{Renault}	\N	f	f	2026-08-03 16:24:19.644	2026-08-03 16:24:19.644	\N
7a89e2bc-5234-4722-826a-82ead9200378	2026-05-01 00:00:00	VO	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	200	Renault	{Renault}	\N	f	f	2026-08-03 16:24:23.183	2026-08-03 16:24:23.183	\N
d67e8412-80d8-4a00-9ff2-bb5eb1cb3fec	2026-05-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:24:02.078	2026-08-03 16:24:02.078	\N
b42645ef-ea7f-49f3-91b9-4902430b54b9	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:03.034	2026-08-03 16:24:03.034	\N
35de1ca8-9b8c-414c-8a58-3cc5eca72a2c	2026-05-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:24:03.923	2026-08-03 16:24:03.923	\N
4e897ead-1885-43bf-8186-421d78e123f8	2026-05-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:24:09.346	2026-08-03 16:24:09.346	\N
331e8dc8-e825-42a4-b251-491ff9f46f59	2026-05-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:10.124	2026-08-03 16:24:10.124	\N
c9649de8-0e8e-47d3-a6ec-ef0a4578a4d5	2026-05-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:24:13.895	2026-08-03 16:24:13.895	\N
b89e688e-4288-4784-abf1-0ff0c3c6e0a6	2026-05-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:17.495	2026-08-03 16:24:17.495	\N
79d1f8de-fdb5-4d41-a361-6bfe80bb6d61	2026-05-01 00:00:00	APV	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	200	Renault	{Renault}	\N	f	f	2026-08-03 16:24:24.612	2026-08-03 16:24:24.612	\N
ac301150-df0e-402e-a956-6f3c7c43ef20	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LLD BONY — véhicule rougerie	985	Renault	{Renault}	\N	f	f	2026-08-03 16:24:25.498	2026-08-03 16:24:25.498	\N
67f13bc8-e0b2-4fe7-9fde-583a27c38915	2026-05-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:24:27.635	2026-08-03 16:24:27.635	\N
dbbf51d8-bba8-4659-8b0e-db9ed1461f2c	2026-05-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:28.465	2026-08-03 16:24:28.465	\N
7a4daa4d-ab18-4bdc-8eb6-699481093787	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	CISCAR — SUPPORT AFFICHE VITRE	20	Alpine	{Alpine}	\N	f	f	2026-08-03 16:24:33.764	2026-08-03 16:24:33.764	\N
6d2c3cc2-571c-4066-90f4-ad33a5a7eede	2026-05-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	ONEVISION — PLV RENAULT PRO + SAINT GERMAIN	317	Renault	{Renault}	\N	f	f	2026-08-03 16:24:36.046	2026-08-03 16:24:36.046	\N
36c271e9-0f55-429b-8108-cb76fab88f14	2026-05-01 00:00:00	VN	Moulins	{Moulins}	{"Moulins": 100}	GRAPHIC — STICKERS BONY	625	Renault	{Renault}	\N	f	f	2026-08-03 16:24:42.07	2026-08-03 16:24:42.07	\N
e8d6ff27-b053-4921-858f-dd69f194bfe9	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	POINT MARQUAGE — kakémono pro+	74	Renault	{Renault}	\N	f	f	2026-08-03 16:24:55.614	2026-08-03 16:24:55.614	\N
db303e4a-a674-4486-87b3-cbd029145319	2026-05-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:24:05.544	2026-08-03 16:24:05.544	\N
ed3d7117-2aa4-4916-af7c-639f8f2ad6d7	2026-05-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:08.656	2026-08-03 16:24:08.656	\N
bcc3990f-11b6-4b97-b735-e5adc212a1ed	2026-05-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:24:12.381	2026-08-03 16:24:12.381	\N
a9b68ed5-3d6e-4167-bb8b-dd23ea22539d	2026-05-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:16.043	2026-08-03 16:24:16.043	\N
0e98b38e-040d-4ce6-bd87-e16803304f1f	2026-05-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:24:18.195	2026-08-03 16:24:18.195	\N
248a2740-3091-4ab2-a1ab-31a895a6c948	2026-05-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:18.933	2026-08-03 16:24:18.933	\N
123795ee-42aa-49fc-9496-e5048b344b4a	2026-05-01 00:00:00	VO	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	200	Renault	{Renault}	\N	f	f	2026-08-03 16:24:20.349	2026-08-03 16:24:20.349	\N
274c131c-bdec-493d-9d91-6eb7df49ca69	2026-05-01 00:00:00	PR	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	200	Renault	{Renault}	\N	f	f	2026-08-03 16:24:21.053	2026-08-03 16:24:21.053	\N
020edb3c-16c8-4b9c-a097-6623c1212af7	2026-05-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	200	Renault	{Renault}	\N	f	f	2026-08-03 16:24:21.778	2026-08-03 16:24:21.778	\N
7ee77c40-872d-40ea-b506-549065b4c82d	2026-05-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:24:31.578	2026-08-03 16:24:31.578	\N
27825bbc-3435-4523-9c79-40753d3880e6	2026-05-01 00:00:00	VN	Mende	{Mende}	{"Mende": 100}	ONEVISION — PACK DE 3 MATS	500	Renault	{Renault}	\N	f	f	2026-08-03 16:24:32.3	2026-08-03 16:24:32.3	\N
309ab85f-2253-41dd-b9d9-1f5212a1e3e8	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	CISCAR — SUPPORT AFFICHE VITRE	60	Renault	{Renault}	\N	f	f	2026-08-03 16:24:34.514	2026-08-03 16:24:34.514	\N
7e62e6d1-d1c5-446a-8ec7-30f1e6c3c6d3	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — STICKERS 888€/MOIS - ST ETIENNE	242.85	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:39.011	2026-08-03 16:24:39.011	\N
5f6e0614-62a4-4c48-9ad6-ad8256d15ed9	2026-06-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:25:08.051	2026-08-03 16:25:08.051	\N
04da03d2-c270-4876-a758-7232a061f922	2026-06-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:25:10.959	2026-08-03 16:25:10.959	\N
f21e211d-e760-4779-9e12-a95ef0f0e940	2026-06-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	Point marquage — drapeaux Alpine	362	Renault	{Renault}	\N	f	f	2026-08-03 16:25:49.032	2026-08-03 16:25:49.032	\N
796bed62-bdfc-4ef5-8969-db04d349df5f	2026-05-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:24:10.896	2026-08-03 16:24:10.896	\N
ec90181c-22ed-4cc9-b136-0f12c5ab34d5	2026-05-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:24:11.604	2026-08-03 16:24:11.604	\N
190a1043-3c97-4831-9e39-a2ec6f7d8ede	2026-05-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:24:13.047	2026-08-03 16:24:13.047	\N
fa2da4a3-1611-4e10-abbf-fe1b1bb1bea4	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:14.578	2026-08-03 16:24:14.578	\N
5acc2b71-2006-44d5-80a8-2e15e2a71310	2026-05-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:24:15.332	2026-08-03 16:24:15.332	\N
6fe27b98-eb51-4445-98e5-2a675c8c9a1c	2026-05-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:24:16.778	2026-08-03 16:24:16.778	\N
c140cf53-a72e-4505-b238-3131a075900b	2026-05-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	200	Renault	{Renault}	\N	f	f	2026-08-03 16:24:22.546	2026-08-03 16:24:22.546	\N
bb9d28b4-3f32-4443-ae9b-2c58c77dd0a9	2026-05-01 00:00:00	PR	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	200	Renault	{Renault}	\N	f	f	2026-08-03 16:24:23.998	2026-08-03 16:24:23.998	\N
4c2268dc-5c42-4187-84f9-a748dd67b1d4	2026-05-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	4759	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:26.982	2026-08-03 16:24:26.982	\N
231f2f18-bc7d-487f-abca-5395c1dbf6e3	2026-05-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:24:30.047	2026-08-03 16:24:30.047	\N
03318847-a4a3-4359-b52d-f4c346472663	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	POINT MARQUAGE — Stickers Twingo	131	Renault	{Renault}	\N	f	f	2026-08-03 16:24:37.514	2026-08-03 16:24:37.514	\N
ee5b3a1f-b0d6-40ec-94a5-a7ddaf6e5686	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	BISTROT MURMURE — 2 repas A290 BETA	91	Alpine	{Alpine}	\N	f	f	2026-08-03 16:24:50.127	2026-08-03 16:24:50.127	\N
c5b36d4b-b16a-4134-816f-ce1a2ac9cf19	2026-05-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	GRAPHIC — 50 Stickers €/mois	295	Renault	{Renault}	\N	f	f	2026-08-03 16:24:53.628	2026-08-03 16:24:53.628	\N
c708219a-d4a4-46da-a0ae-e328acb2a1e6	2026-06-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:25:01.88	2026-08-03 16:25:01.88	\N
10dc91ab-30ec-435e-9170-c3b1caf63a6a	2026-06-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:25:15.796	2026-08-03 16:25:15.796	\N
ae676f8b-22bb-4315-b545-5814b273f0e6	2026-06-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:25:17.945	2026-08-03 16:25:17.945	\N
b0bfdadc-c159-4f48-a1dc-d2aceb75bbda	2026-06-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:25:19.55	2026-08-03 16:25:19.55	\N
a119677f-85b1-4e13-be80-e19f539adfbb	2026-05-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.26666, "Mende": 2.906016, "Mozac": 4.360644, "Rodez": 7.26666, "Ussel": 2.906016, "Vichy": 7.26666, "Figeac": 2.906016, "Lavaur": 2.906016, "Millau": 2.906016, "Ricoux": 4.360644, "Carmaux": 2.034535, "Gaillac": 5.815272, "Issoire": 6.398419, "Moulins": 5.815272, "Aurillac": 7.26666, "Clermont": 15.991188, "Massagettes": 2.906016, "Villefranche": 2.906016, "Le Puy-en-Velay": 5.815272}	Le bon coin — boutique	30867	Renault	{Renault}	\N	f	f	2026-08-03 16:24:26.113	2026-08-03 16:24:26.113	\N
12e60cc3-50c8-4501-a345-2f86f170e1e4	2026-05-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — Bon achat 50€ clf	93	Renault	{Renault}	\N	f	f	2026-08-03 16:24:35.228	2026-08-03 16:24:35.228	\N
9ae23d9f-02d9-4480-b545-a10697f20d58	2026-05-01 00:00:00	VN	Ricoux	{Ricoux}	{"Ricoux": 100}	POINT MARQUAGE — STICKERS VU - THIERS	104	Renault	{Renault}	\N	f	f	2026-08-03 16:24:47.066	2026-08-03 16:24:47.066	\N
a14c2fc8-d8e2-42ff-9b99-3737442fdace	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	CISCAR — PORTE AFFICHE PRIX 20	204.88	Renault	{Renault}	\N	f	f	2026-08-03 16:24:52.127	2026-08-03 16:24:52.127	\N
6c1fd947-653d-4316-9be9-1d09d427e863	2026-05-01 00:00:00	VN	Mozac	{Mozac}	{"Mozac": 100}	graphic — stickers magnet vu	150.08	Renault	{Renault}	\N	f	f	2026-08-03 16:24:54.367	2026-08-03 16:24:54.367	\N
77751dc3-d875-4b4f-8270-373ae06c66bf	2026-05-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — phtoo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:57.197	2026-08-03 16:24:57.197	\N
3ef27bbe-6977-447e-a50d-f3b4747ed9d2	2026-06-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:25:10.254	2026-08-03 16:25:10.254	\N
339d90b6-f8f0-4de3-9869-041cba4519b8	2026-06-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:25:14.286	2026-08-03 16:25:14.286	\N
59bb767e-9ad8-40e7-bca5-4594e035f291	2026-05-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:24:29.197	2026-08-03 16:24:29.197	\N
f4602387-b6d2-4990-a94d-9f5238a2994c	2026-05-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:24:30.762	2026-08-03 16:24:30.762	\N
5abd2454-687f-46cd-bbcb-599555807e82	2026-05-01 00:00:00	VN	Albi, Aurillac, Rodez	{Albi,Aurillac,Rodez}	{"Albi": 32.926829, "Rodez": 34.146341, "Aurillac": 32.926829}	PRINT CONSEIL — ETIQUETTES AVIS GOOGLE NISSAN BSO	82	Renault	{Renault}	\N	f	f	2026-08-03 16:24:33.054	2026-08-03 16:24:33.054	\N
bf5b386f-d892-4165-940f-f5048e729aa9	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	VA — dacia camp	750	Renault	{Renault}	\N	f	f	2026-08-03 16:24:36.683	2026-08-03 16:24:36.683	\N
de1efa42-8076-4efe-aa0d-8e688fe59e9b	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LES HALLES DU BREZET — EXPO + AFTERWORK	500	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:38.213	2026-08-03 16:24:38.213	\N
e905710c-080a-4d5f-a6d4-7c541026ee6f	2026-05-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — STICKERS BONY - NISSAN BSO	795.63	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:40.394	2026-08-03 16:24:40.394	\N
49f2472a-8e3a-4e58-bf69-405e94f2ebb7	2026-05-01 00:00:00	VN	Albi	{Albi}	{"Albi": 100}	POINT MARQUAGE — TOTEM EVENT B2B	178	Renault	{Renault}	\N	f	f	2026-08-03 16:24:52.947	2026-08-03 16:24:52.947	\N
c9dd33bd-f952-462d-aea8-b01e3ce7f7f5	2026-05-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — phtoo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:24:56.365	2026-08-03 16:24:56.365	\N
c3cc8cf9-4c02-4dee-a14c-e0b7927cfc12	2026-06-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:24:57.867	2026-08-03 16:24:57.867	\N
4db135d7-4576-486c-bb56-2e2884157e58	2026-06-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:25:04.938	2026-08-03 16:25:04.938	\N
791d8239-be47-4c11-ae2d-58d3146e9660	2026-06-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:25:07.032	2026-08-03 16:25:07.032	\N
db76c096-b760-4362-b693-b59e51a7624a	2026-06-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:25:12.347	2026-08-03 16:25:12.347	\N
21cc5a03-273d-4e26-b99a-06185c3857b4	2026-06-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:25:15.111	2026-08-03 16:25:15.111	\N
cabf2d8a-2195-4b9d-8c76-6542fb7f3002	2026-06-01 00:00:00	APV	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:25.763	2026-08-03 16:25:25.763	\N
cbf0880b-6af6-426f-bf60-eae6c77d3ad3	2026-06-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:30.433	2026-08-03 16:25:30.433	\N
6ff168e7-f7d1-4eb1-829e-92f23fd500ed	2026-05-01 00:00:00	APV	Issoire	{Issoire}	{"Issoire": 100}	GRAPHIC — Films solaires Renault	1476	Renault	{Renault}	\N	f	f	2026-08-03 16:24:55.03	2026-08-03 16:24:55.03	\N
3b04f4ff-2a71-4db9-8127-10ef9e84f6b8	2026-06-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:25:11.647	2026-08-03 16:25:11.647	\N
60f2f80f-5618-476a-b5d4-749f1b57ccc0	2026-06-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:25:18.814	2026-08-03 16:25:18.814	\N
b8b9c739-f455-4814-8acc-cf7d80545173	2026-06-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:20.314	2026-08-03 16:25:20.314	\N
4e4e2c0b-03d4-491e-a23d-591737dfd3e3	2026-06-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:24:58.53	2026-08-03 16:24:58.53	\N
f4d3f584-9d78-490a-b4f7-66f0bac2c58d	2026-06-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:24:59.184	2026-08-03 16:24:59.184	\N
dadc62f8-13fd-456a-b77e-ca52678dfd4b	2026-06-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:25:08.765	2026-08-03 16:25:08.765	\N
ab576fe3-6f53-486b-b3ee-b7974364505e	2026-06-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:25:16.598	2026-08-03 16:25:16.598	\N
c70beca0-2cb2-48b5-afc9-581a148b98dd	2026-06-01 00:00:00	PR	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:21.879	2026-08-03 16:25:21.879	\N
8386f5c5-3a80-4f92-bbc2-e3a1565897fd	2026-06-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	4759	Nissan	{Nissan}	\N	f	f	2026-08-03 16:25:28.064	2026-08-03 16:25:28.064	\N
9c3a8a0a-5015-4330-a5e2-378d54967df9	2026-06-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:25:13.268	2026-08-03 16:25:13.268	\N
cf0437da-043a-4b62-b18a-83768f8bf1a9	2026-06-01 00:00:00	VO	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:21.017	2026-08-03 16:25:21.017	\N
2e279822-efcb-445c-91da-4a6cccdd2a71	2026-06-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:22.535	2026-08-03 16:25:22.535	\N
baf21cb8-4ac0-400e-b482-c18230ebc237	2026-06-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:23.633	2026-08-03 16:25:23.633	\N
c10752f5-7209-49a9-8376-723d1ff67cad	2026-06-01 00:00:00	VO	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:24.219	2026-08-03 16:25:24.219	\N
75618f09-58d0-4239-b687-929c37b37051	2026-06-01 00:00:00	PR	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:25.065	2026-08-03 16:25:25.065	\N
3d4dcccd-611e-4e01-8568-3069825aab4f	2026-06-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LLD BONY — véhicule rougerie	985	Renault	{Renault}	\N	f	f	2026-08-03 16:25:26.466	2026-08-03 16:25:26.466	\N
849f8803-3170-4b45-b9d7-5b213cb249b5	2026-06-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.26666, "Mende": 2.906016, "Mozac": 4.360644, "Rodez": 7.26666, "Ussel": 2.906016, "Vichy": 7.26666, "Figeac": 2.906016, "Lavaur": 2.906016, "Millau": 2.906016, "Ricoux": 4.360644, "Carmaux": 2.034535, "Gaillac": 5.815272, "Issoire": 6.398419, "Moulins": 5.815272, "Aurillac": 7.26666, "Clermont": 15.991188, "Massagettes": 2.906016, "Villefranche": 2.906016, "Le Puy-en-Velay": 5.815272}	Le bon coin — boutique	30867	Renault	{Renault}	\N	f	f	2026-08-03 16:25:27.37	2026-08-03 16:25:27.37	\N
f1113d51-c82d-4833-b2e1-4ec77280622a	2026-06-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:25:28.864	2026-08-03 16:25:28.864	\N
e4705663-b4ab-4ee6-a5cb-b4657780986f	2026-06-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:25:29.635	2026-08-03 16:25:29.635	\N
675b68bb-2e56-41cf-b977-77001c60e60b	2026-06-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:31.133	2026-08-03 16:25:31.133	\N
7982c06c-80bd-44be-8a91-4bbe40bc8b1a	2026-06-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:31.925	2026-08-03 16:25:31.925	\N
901aede1-2b68-4f79-a23e-ede12efc4cce	2026-06-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:25:32.606	2026-08-03 16:25:32.606	\N
d647d058-9271-44c3-8bb4-7c3c0c43129f	2026-06-01 00:00:00	VN	Issoire, Le Puy-en-Velay, Mende	{Issoire,"Le Puy-en-Velay",Mende}	{"Mende": 16.666667, "Issoire": 50, "Le Puy-en-Velay": 33.333333}	SEANCE PHONING — RESTAURANT LA HAUT	750	Renault	{Renault}	\N	f	f	2026-08-03 16:25:33.436	2026-08-03 16:25:33.436	\N
c871054c-4977-4094-af6d-985401e0441d	2026-06-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	200	Renault	{Renault}	\N	f	f	2026-08-03 16:25:34.147	2026-08-03 16:25:34.147	\N
a7b1d160-ce7d-4d2f-9105-a8caaf431f02	2026-06-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	200	Renault	{Renault}	\N	f	f	2026-08-03 16:25:35.031	2026-08-03 16:25:35.031	\N
73c0a904-9d61-43a4-bad0-fd3ce12cea2d	2026-06-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	200	Renault	{Renault}	\N	f	f	2026-08-03 16:25:35.649	2026-08-03 16:25:35.649	\N
2374d33c-5a58-4849-b955-596e1ef234ba	2026-06-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	200	Renault	{Renault}	\N	f	f	2026-08-03 16:25:36.506	2026-08-03 16:25:36.506	\N
fc3a6af6-a4ad-4dff-999d-c4b0334ee626	2026-06-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	XPERIENCE — Merch Alpine Pascal Taboulot	557	Renault	{Renault}	\N	f	f	2026-08-03 16:25:39.335	2026-08-03 16:25:39.335	\N
7ff643a9-c373-487f-8665-0d0492c83cbf	2026-06-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Print conseil — Cartes alpine	290	Alpine	{Alpine}	\N	f	f	2026-08-03 16:25:42.782	2026-08-03 16:25:42.782	\N
ba4f294c-f0a7-4fec-aa90-266f1fb41a6c	2026-06-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Point marquage — drapeaux Alpine	362	Renault	{Renault}	\N	f	f	2026-08-03 16:25:45.335	2026-08-03 16:25:45.335	\N
19b38a01-7057-4483-96a7-8972f935cc3a	2026-06-01 00:00:00	VO	Rodez	{Rodez}	{"Rodez": 100}	Drago Paris — Badges	23.07	Renault	{Renault}	\N	f	f	2026-08-03 16:26:17.269	2026-08-03 16:26:17.269	\N
9448ba83-2cc8-4b78-b75e-0ef665218a83	2026-06-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Damien Desse — Coach circuit MPR	300	Renault	{Renault}	\N	f	f	2026-08-03 16:25:57.581	2026-08-03 16:25:57.581	\N
be18ea43-79c0-42b4-8936-3556c6d8130d	2026-06-01 00:00:00	VN	Ricoux	{Ricoux}	{"Ricoux": 100}	Debrez — VOILES BONY	604	Renault	{Renault}	\N	f	f	2026-08-03 16:26:03.265	2026-08-03 16:26:03.265	\N
14f6f2d3-8012-45ce-b513-f8cbf7f13e9a	2026-06-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	Drago Paris — Badges	23.07	Renault	{Renault}	\N	f	f	2026-08-03 16:26:08.199	2026-08-03 16:26:08.199	\N
7591cd63-fff5-46a1-b57f-a79009417e3e	2026-06-01 00:00:00	PR	Rodez	{Rodez}	{"Rodez": 100}	Drago Paris — Badges	23.07	Renault	{Renault}	\N	f	f	2026-08-03 16:26:22.679	2026-08-03 16:26:22.679	\N
7fe1adc1-10e3-49cc-9bf4-12b5e5cee71f	2026-06-01 00:00:00	APV	Rodez	{Rodez}	{"Rodez": 100}	Drago Paris — Badges	23.07	Renault	{Renault}	\N	f	f	2026-08-03 16:26:27.328	2026-08-03 16:26:27.328	\N
c1a65ed3-dfa4-4de2-a070-06b7bcbf4052	2026-06-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Drago Paris — Badges	34.6	Nissan	{Nissan}	\N	f	f	2026-08-03 16:26:29.313	2026-08-03 16:26:29.313	\N
eaef4c93-6984-4bf9-a0af-739f9235a30c	2026-06-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Drago Paris — Badges	34.6	Nissan	{Nissan}	\N	f	f	2026-08-03 16:26:30.229	2026-08-03 16:26:30.229	\N
bbcdb55c-7f37-47d8-9df4-7967ac5c6fe2	2026-06-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Drago Paris — Badges	34.6	Nissan	{Nissan}	\N	f	f	2026-08-03 16:26:31.096	2026-08-03 16:26:31.096	\N
a5878446-39c1-4bc7-b3e9-19f6cef591c2	2026-06-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Graphic — KIT VP MOBILIZE + BONY PARE BRISE	252.5	Renault	{Renault}	\N	f	f	2026-08-03 16:26:32.329	2026-08-03 16:26:32.329	\N
57f7d8d7-2440-4155-a5cf-33f7647a1911	2026-06-01 00:00:00	VN	Ricoux	{Ricoux}	{"Ricoux": 100}	Canot — DEPOSE STICKERS CLIO	350	Renault	{Renault}	\N	f	f	2026-08-03 16:26:32.929	2026-08-03 16:26:32.929	\N
aab828e2-5dd3-4d98-8887-fd86a8dc400a	2026-06-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	goodicom — MAILLOT FOOT 5	191.95	Renault	{Renault}	\N	f	f	2026-08-03 16:26:38.568	2026-08-03 16:26:38.568	\N
612edacf-fadd-4bfa-988c-745f251a07fe	2026-06-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	GRAPHIC — Stickers Rent intérieur véhicule	139.99	Renault	{Renault}	\N	f	f	2026-08-03 16:26:39.197	2026-08-03 16:26:39.197	\N
bf13d7fb-dde4-483c-9697-bca3d93921e2	2026-06-01 00:00:00	APV	Issoire	{Issoire}	{"Issoire": 100}	GRAPHIC — Stickers Clio RMS	595	Renault	{Renault}	\N	f	f	2026-08-03 16:26:40.148	2026-08-03 16:26:40.148	\N
79edc371-1e7d-4aa6-ae68-a81a06a95da6	2026-06-01 00:00:00	VN	Clermont, Le Puy-en-Velay, Villefranche	{Clermont,"Le Puy-en-Velay",Villefranche}	{"Clermont": 54.824561, "Villefranche": 18.859649, "Le Puy-en-Velay": 26.315789}	PORCU — cartes de visite	228	Renault	{Renault}	\N	f	f	2026-08-03 16:26:42.396	2026-08-03 16:26:42.396	\N
b4d98263-8142-4388-bea7-77da9ae6a63c	2026-06-01 00:00:00	APV	Clermont, Le Puy-en-Velay, Moulins	{Clermont,"Le Puy-en-Velay",Moulins}	{"Moulins": 30.994152, "Clermont": 43.859649, "Le Puy-en-Velay": 25.146199}	PORCU — cartes de visite	171	Renault	{Renault}	\N	f	f	2026-08-03 16:26:44.397	2026-08-03 16:26:44.397	\N
bc1602a8-e107-4191-877c-d7eb84b0211c	2026-06-01 00:00:00	VO	Issoire	{Issoire}	{"Issoire": 100}	PORCU — cartes de visite	43	Renault	{Renault}	\N	f	f	2026-08-03 16:26:45.347	2026-08-03 16:26:45.347	\N
a07ae8b7-6b99-43f8-95d3-8ff3b7fea2ac	2026-06-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Le maroquinier — Porte carte Alpine	795	Alpine	{Alpine}	\N	f	f	2026-08-03 16:26:46.431	2026-08-03 16:26:46.431	\N
03f8efac-dd24-4e2f-a687-e5392b225d58	2026-06-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — Pochettes Alpine	440	Alpine	{Alpine}	\N	f	f	2026-08-03 16:26:49.612	2026-08-03 16:26:49.612	\N
fab8d7d3-e9cc-40e0-b753-62907f790d20	2026-06-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	PRINT CONSEIL — Pochettes Alpine	146	Renault	{Renault}	\N	f	f	2026-08-03 16:26:50.497	2026-08-03 16:26:50.497	\N
d9e1b03e-ae8c-4bab-8e3f-b50a0b03d64f	2026-06-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	PRINT CONSEIL — Pochettes Alpine	146	Renault	{Renault}	\N	f	f	2026-08-03 16:26:51.646	2026-08-03 16:26:51.646	\N
bb653b1b-d8c8-4999-9866-c0ca7b78d1be	2026-06-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	PRINT CONSEIL — Pochettes Alpine	146	Renault	{Renault}	\N	f	f	2026-08-03 16:26:53.698	2026-08-03 16:26:53.698	\N
dd8886c9-7a38-469b-a45d-29729b57d97e	2026-06-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — Kakemono Alpine	132	Alpine	{Alpine}	\N	f	f	2026-08-03 16:26:58.517	2026-08-03 16:26:58.517	\N
bcb0551d-09d8-4d5d-b977-65832430e789	2026-06-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	GRAPHIC — Bâche Juke occasion St-Etienne	196.51	Nissan	{Nissan}	\N	f	f	2026-08-03 16:26:59.425	2026-08-03 16:26:59.425	\N
fb7a997b-2773-4f8a-8b41-eabf770b4238	2026-06-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	2G PUBLICITE — Stickers Depanneuse	130	Renault	{Renault}	\N	f	f	2026-08-03 16:27:00.353	2026-08-03 16:27:00.353	\N
9d3087fa-5da7-40cb-8833-98c8f3a6480d	2026-06-01 00:00:00	VN	Albi	{Albi}	{"Albi": 100}	POINT MARQUAGE — TOTEM PRO+	193	Renault	{Renault}	\N	f	f	2026-08-03 16:27:01.211	2026-08-03 16:27:01.211	\N
d5269f15-4eda-42c5-8b24-b7acaee3e907	2026-06-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — phtoo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:27:03.087	2026-08-03 16:27:03.087	\N
a543d186-bc02-4bdd-a5ad-98541642772b	2026-07-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:27:05.184	2026-08-03 16:27:05.184	\N
72746dec-404c-4358-bfe0-c328a7df7c8a	2026-07-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:27:09.252	2026-08-03 16:27:09.252	\N
17c89b17-ebc9-41f4-8fa8-3eee33b01f85	2026-07-01 00:00:00	VO	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:24.386	2026-08-03 16:28:24.386	\N
e86a129c-62d3-4c76-a622-58d08ce62b2a	2026-06-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Drago Paris — Badges	34.6	Nissan	{Nissan}	\N	f	f	2026-08-03 16:26:31.729	2026-08-03 16:26:31.729	\N
07fd1ae6-c583-46a1-a338-b76fba8f6672	2026-06-01 00:00:00	VN	Clermont, Le Puy-en-Velay, Rodez, Vichy	{Clermont,"Le Puy-en-Velay",Rodez,Vichy}	{"Rodez": 25, "Vichy": 25, "Clermont": 25, "Le Puy-en-Velay": 25}	goodicom — porte clé mobilize	490	Renault	{Renault}	\N	f	f	2026-08-03 16:26:36.147	2026-08-03 16:26:36.147	\N
13b80a42-7ffd-4a00-a8bc-7f1ab65c6633	2026-06-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	CISCAR — PORTE AFFICHE	204.88	Renault	{Renault}	\N	f	f	2026-08-03 16:26:41.33	2026-08-03 16:26:41.33	\N
dfb63e67-8924-4076-8b28-70cf3253a949	2026-06-01 00:00:00	APV	Rodez	{Rodez}	{"Rodez": 100}	PRINT CONSEIL — Pochettes Alpine	146	Renault	{Renault}	\N	f	f	2026-08-03 16:26:54.894	2026-08-03 16:26:54.894	\N
d2efef2d-cc86-492b-b628-907fdad73999	2026-06-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	PRINT CONSEIL — Pochettes Alpine	146	Renault	{Renault}	\N	f	f	2026-08-03 16:26:57.459	2026-08-03 16:26:57.459	\N
40e4790a-3f0c-4b5f-b042-ae8ef7faff4b	2026-06-01 00:00:00	VN	Ricoux	{Ricoux}	{"Ricoux": 100}	Canot — POSE STICKER TWINGO	170	Renault	{Renault}	\N	f	f	2026-08-03 16:26:33.629	2026-08-03 16:26:33.629	\N
3b7f12ce-166e-4d23-bc9e-258cd156b41e	2026-06-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	Graphic — Marquage Kangoo Assistance	698	Renault	{Renault}	\N	f	f	2026-08-03 16:26:34.263	2026-08-03 16:26:34.263	\N
bcb560cf-790a-4b2d-b6ff-1cf2d82c18c4	2026-06-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	Point marquage — drapeaux Alpine	362	Renault	{Renault}	\N	f	f	2026-08-03 16:26:34.913	2026-08-03 16:26:34.913	\N
39715a01-cf98-44d0-b99b-e3e7482b78d3	2026-06-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	PORCU — cartes de visite	78	Nissan	{Nissan}	\N	f	f	2026-08-03 16:26:43.129	2026-08-03 16:26:43.129	\N
7b61b12e-2b66-42b3-945a-bbabb94b5f13	2026-06-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	PRINT CONSEIL — Pochettes Alpine	440	Alpine	{Alpine}	\N	f	f	2026-08-03 16:26:48.131	2026-08-03 16:26:48.131	\N
39ffaab0-3ee9-46ea-ae2f-8e2b650f8c0e	2026-06-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	PRINT CONSEIL — Pochettes Alpine	146	Renault	{Renault}	\N	f	f	2026-08-03 16:26:56.281	2026-08-03 16:26:56.281	\N
a41a1101-995e-4b12-9b83-5fbbded52796	2026-06-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — phtoo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:27:02.278	2026-08-03 16:27:02.278	\N
1597d2ec-67ed-4c73-927e-8d4efbc0711d	2026-07-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:27:07.184	2026-08-03 16:27:07.184	\N
e3f035a2-48f6-4b0b-90fc-ea1ba4d0d917	2026-07-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:27:32.815	2026-08-03 16:27:32.815	\N
0eaee6e2-ceb9-40bc-ad68-9e23cfe3166a	2026-07-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:27:47.361	2026-08-03 16:27:47.361	\N
842c9d93-d554-46b0-97d3-e2c529b570b7	2026-07-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:27:50.382	2026-08-03 16:27:50.382	\N
bdab1085-ebd8-4d91-bda5-31a1c580604b	2026-07-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:28:02.95	2026-08-03 16:28:02.95	\N
1cee4881-ee36-4193-9683-1898dbd075e2	2026-07-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:28:07.273	2026-08-03 16:28:07.273	\N
7f55a957-1b1a-4884-bfcf-0bbf6edcc977	2026-07-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:28:13.683	2026-08-03 16:28:13.683	\N
c8ef567e-378a-46f8-a89d-6c1409f3a120	2026-07-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:17.782	2026-08-03 16:28:17.782	\N
5469d29e-6a05-486d-a6a1-61e01a8bb4ed	2026-07-01 00:00:00	APV	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:37.119	2026-08-03 16:28:37.119	\N
fad52ebf-2726-4551-bd02-a5ce87f7f102	2026-07-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — phtoo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:28:59.834	2026-08-03 16:28:59.834	\N
87c9e230-5949-42e2-9e63-11fa1b72416c	2026-07-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:27:04.169	2026-08-03 16:27:04.169	\N
22fc0e0d-fe71-4b9d-b4f8-e19c61a46e7c	2026-07-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:27:13.449	2026-08-03 16:27:13.449	\N
f199fdb2-8627-4d7b-a5d6-7cdf03771074	2026-07-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:27:28.305	2026-08-03 16:27:28.305	\N
f015879f-8aaf-48bb-bc94-ba516890bb23	2026-07-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:27:57.681	2026-08-03 16:27:57.681	\N
23eb41b9-679e-4c87-b2ab-55d808c1aa43	2026-07-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:28:47.12	2026-08-03 16:28:47.12	\N
cd1d331f-2e97-4495-b599-e3c7e0add31d	2026-07-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:28:48.785	2026-08-03 16:28:48.785	\N
147d929e-5922-441c-929f-a748ca72f737	2026-07-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LE QG — Repas VN	297	Alpine	{Alpine}	\N	f	f	2026-08-03 16:28:58.935	2026-08-03 16:28:58.935	\N
1c887d66-3830-4f0d-9bab-50e0124b703f	2026-07-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	GRAPHIC — STICKER MOBILIZE TRAFIC 9PL	237.79	Renault	{Renault}	\N	f	f	2026-08-03 16:29:02.048	2026-08-03 16:29:02.048	\N
a28bb673-6694-4475-9443-1da1f2cabef3	2026-07-01 00:00:00	VN	Albi	{Albi}	{"Albi": 100}	DREAMCOM — Commande cartes de visite	143.78	Renault	{Renault}	\N	f	f	2026-08-03 16:29:07.432	2026-08-03 16:29:07.432	\N
ce836e78-38f2-490f-9f3e-7fa5d9927cc3	2026-08-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:12.688	2026-08-03 16:29:12.688	\N
2c2717f1-8ac2-4eaf-bc50-bb1bbbd9eca6	2026-08-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:29:16.378	2026-08-03 16:29:16.378	\N
7ebdd7b7-58a9-473d-82dc-2f741806ff7a	2026-08-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:29:18.118	2026-08-03 16:29:18.118	\N
fbc62f31-53f7-4bed-a4fc-5c109abd417b	2026-07-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:27:06.136	2026-08-03 16:27:06.136	\N
2486cca6-0870-4679-9461-e5e06f2e8910	2026-07-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:27:17.424	2026-08-03 16:27:17.424	\N
1ddb9a66-c295-4afc-a9a4-bba3b43f7e6b	2026-07-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:27:21.584	2026-08-03 16:27:21.584	\N
b9be70a8-b786-470a-bd3c-85df8abb0546	2026-07-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:27:42.498	2026-08-03 16:27:42.498	\N
a00de3c8-d265-4326-b93a-4e34ffabc920	2026-07-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:27:59.447	2026-08-03 16:27:59.447	\N
ad4a8de2-0b4b-403e-bc50-fa25e1e34f01	2026-07-01 00:00:00	VO	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:34.189	2026-08-03 16:28:34.189	\N
905dd438-4650-4dfd-aab0-99064b6b7410	2026-07-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	4759	Nissan	{Nissan}	\N	f	f	2026-08-03 16:28:39.385	2026-08-03 16:28:39.385	\N
bacb515a-bc65-4d1a-b2ed-955a25202e70	2026-07-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:42.325	2026-08-03 16:28:42.325	\N
35025d28-dabd-4383-9f6b-9f4c1aee48a0	2026-07-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:46.262	2026-08-03 16:28:46.262	\N
f1dbbfd2-8221-4ff0-b81a-5fffdd643114	2026-07-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Bistrot Murmure — 2 repas offert A290	91	Alpine	{Alpine}	\N	f	f	2026-08-03 16:28:50.961	2026-08-03 16:28:50.961	\N
ab79cceb-4638-486d-84e5-85614fa85e72	2026-07-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	GRAPHIC — STICKER PARTENARIAT TRAFIC	299	Renault	{Renault}	\N	f	f	2026-08-03 16:28:52.654	2026-08-03 16:28:52.654	\N
ef7253bc-8f44-4eaa-b361-5f072b7b932c	2026-07-01 00:00:00	VN	Ricoux	{Ricoux}	{"Ricoux": 100}	CISCAR — POCHETTE CLIENTS RENAULT	240	Renault	{Renault}	\N	f	f	2026-08-03 16:28:53.313	2026-08-03 16:28:53.313	\N
aecb546d-7a5b-4bba-a9e5-e1d75b35f98a	2026-07-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.610169, "Mende": 2.730697, "Mozac": 5.047081, "Rodez": 9.435028, "Ussel": 2.52354, "Vichy": 7.608286, "Figeac": 2.787194, "Lavaur": 0.696798, "Millau": 2.429379, "Ricoux": 4.350282, "Carmaux": 1.73258, "Gaillac": 3.822976, "Issoire": 5.442561, "Moulins": 5.442561, "Aurillac": 6.610169, "Clermont": 22.372881, "Massagettes": 1.581921, "Villefranche": 1.73258, "Le Puy-en-Velay": 7.043315}	SARBACANE — ABONNEMENT ANNUEL	5310	Renault	{Renault}	\N	f	f	2026-08-03 16:28:54.789	2026-08-03 16:28:54.789	\N
86935437-dc1b-4068-b12a-acef7c5c441e	2026-07-01 00:00:00	VO	Clermont, Mozac	{Clermont,Mozac}	{"Mozac": 19.94655, "Clermont": 80.05345}	DEBREZ — VOILES + PIEDS + MATS	1029	Renault	{Renault}	\N	f	f	2026-08-03 16:29:03.57	2026-08-03 16:29:03.57	\N
d5e23a58-fb8e-491b-84d2-cb8de1f161d9	2026-08-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:17.254	2026-08-03 16:29:17.254	\N
8d37200c-2372-4d8a-85cb-c40057b5de99	2026-07-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:27:08.069	2026-08-03 16:27:08.069	\N
46c2bc75-f39a-4ab8-b9a0-30d7f9c28683	2026-07-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:27:55.966	2026-08-03 16:27:55.966	\N
1b561f12-5f33-4147-9592-f6f241b59b11	2026-07-01 00:00:00	PR	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:28.459	2026-08-03 16:28:28.459	\N
a6295eb5-8482-406f-ad23-18b1eda809bf	2026-07-01 00:00:00	PR	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:36.266	2026-08-03 16:28:36.266	\N
5909115d-34f5-4437-8faf-9f41c74328ac	2026-07-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LLD BONY — véhicule rougerie	985	Renault	{Renault}	\N	f	f	2026-08-03 16:28:37.75	2026-08-03 16:28:37.75	\N
0cbd4606-a139-4a47-bc44-82cc6da371b3	2026-07-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:28:40.134	2026-08-03 16:28:40.134	\N
ce825a3c-7760-4125-a170-532a48dd9125	2026-07-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:41.703	2026-08-03 16:28:41.703	\N
aede7616-db22-49e7-be62-845c0fc342fe	2026-07-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:43.113	2026-08-03 16:28:43.113	\N
4ac0b353-9127-4977-be6f-81b551aa7823	2026-07-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Bistrot Murmure — 2 repas offert A290	91	Alpine	{Alpine}	\N	f	f	2026-08-03 16:28:50.293	2026-08-03 16:28:50.293	\N
b6fac4ba-3a4a-4a3f-a16b-1f2d4333b42e	2026-07-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	CISCAR — POCHETTE CLIENTS RENAULT + DACIA	1460.76	Renault	{Renault}	\N	f	f	2026-08-03 16:28:56.153	2026-08-03 16:28:56.153	\N
578479d1-01b6-49f7-8aef-e697ef46a274	2026-07-01 00:00:00	VO	Albi	{Albi}	{"Albi": 100}	DREAMCOM — Commande cartes de visite	143.78	Renault	{Renault}	\N	f	f	2026-08-03 16:29:08.181	2026-08-03 16:29:08.181	\N
28363ffc-da28-480b-bf8c-96e7f026cb24	2026-07-01 00:00:00	APV	Albi	{Albi}	{"Albi": 100}	DREAMCOM — Commande cartes de visite	143.78	Renault	{Renault}	\N	f	f	2026-08-03 16:29:09.648	2026-08-03 16:29:09.648	\N
9fb3ce2e-1e36-47cd-84cf-c9886cdbb2b0	2026-07-01 00:00:00	PR	Rodez	{Rodez}	{"Rodez": 100}	DREAMCOM — Commande cartes de visite	60.54	Renault	{Renault}	\N	f	f	2026-08-03 16:29:10.371	2026-08-03 16:29:10.371	\N
6c2f167e-fa23-4350-b3f0-dc984343bac5	2026-08-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:29:13.387	2026-08-03 16:29:13.387	\N
4c04f152-3520-40b1-bd67-51336d135e75	2026-08-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:29:14.837	2026-08-03 16:29:14.837	\N
c26d1dda-624f-4ee3-81d0-4d2369565f39	2026-08-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:29:19.419	2026-08-03 16:29:19.419	\N
a7e00709-c62c-4978-9589-59eefe611afc	2026-08-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:29:20.642	2026-08-03 16:29:20.642	\N
969835ea-1364-45cc-bec0-e5a7bcc9093c	2026-07-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:30.87	2026-08-03 16:28:30.87	\N
50e2351f-4fe1-447a-b237-70771f9ad1ef	2026-07-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:28:33.266	2026-08-03 16:28:33.266	\N
cbbebbb0-fa33-4322-bf3e-658c85fa94f2	2026-07-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:28:40.95	2026-08-03 16:28:40.95	\N
50112654-f5a0-4e97-a43c-37eedbe9072c	2026-07-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:28:47.913	2026-08-03 16:28:47.913	\N
a0f3fd8e-7aa7-478e-8adb-ca46a66fd212	2026-07-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	padle albi — alpine rodez	1000	Renault	{Renault}	\N	f	f	2026-08-03 16:28:51.804	2026-08-03 16:28:51.804	\N
dd41dfc8-ee2c-487e-8a3f-fc8cd287f2ba	2026-07-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	GRAPHIC — STICKER 88%	117.63	Renault	{Renault}	\N	f	f	2026-08-03 16:28:54.073	2026-08-03 16:28:54.073	\N
00597be7-ed1c-4109-b56f-1585a407337a	2026-07-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	SARBACANE — ABONNEMENT ANNUEL	462	Nissan	{Nissan}	\N	f	f	2026-08-03 16:28:55.497	2026-08-03 16:28:55.497	\N
061d3572-8a71-47c1-9c56-f88a1759b8a7	2026-07-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	Triathlon Vichy	731	Renault	{Renault}	\N	f	f	2026-08-03 16:28:57.042	2026-08-03 16:28:57.042	\N
d25362bc-54d7-408b-9ef1-f6adefd42801	2026-07-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — phtoo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:00.493	2026-08-03 16:29:00.493	\N
31edb7f5-3027-413b-81f9-5861b79ccbc8	2026-07-01 00:00:00	VN	Clermont, Mozac	{Clermont,Mozac}	{"Mozac": 19.94655, "Clermont": 80.05345}	DEBREZ — VOILES + PIEDS + MATS	1029	Renault	{Renault}	\N	f	f	2026-08-03 16:29:02.822	2026-08-03 16:29:02.822	\N
65f252c9-172f-47db-b286-fdb2b1188094	2026-07-01 00:00:00	VN	Issoire, Le Puy-en-Velay, Mende	{Issoire,"Le Puy-en-Velay",Mende}	{"Mende": 17.177586, "Issoire": 57.750038, "Le Puy-en-Velay": 25.072376}	DEBREZ — VOILES + PIEDS + MATS	1495.67	Renault	{Renault}	\N	f	f	2026-08-03 16:29:04.303	2026-08-03 16:29:04.303	\N
95b9a531-2f65-4064-85f8-ffe021648715	2026-07-01 00:00:00	VO	Issoire, Le Puy-en-Velay, Mende	{Issoire,"Le Puy-en-Velay",Mende}	{"Mende": 17.177586, "Issoire": 57.750038, "Le Puy-en-Velay": 25.072376}	DEBREZ — VOILES + PIEDS + MATS	1495.67	Renault	{Renault}	\N	f	f	2026-08-03 16:29:05.169	2026-08-03 16:29:05.169	\N
e7244e78-9f59-4371-8ab8-4ebcd23b81de	2026-08-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:24.719	2026-08-03 16:29:24.719	\N
c4ef3e62-129e-4ede-8944-e03af679e312	2026-08-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:29:26.853	2026-08-03 16:29:26.853	\N
0b68be3f-5a9c-4b47-a291-c84e8b45b361	2026-07-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.26666, "Mende": 2.906016, "Mozac": 4.360644, "Rodez": 7.26666, "Ussel": 2.906016, "Vichy": 7.26666, "Figeac": 2.906016, "Lavaur": 2.906016, "Millau": 2.906016, "Ricoux": 4.360644, "Carmaux": 2.034535, "Gaillac": 5.815272, "Issoire": 6.398419, "Moulins": 5.815272, "Aurillac": 7.26666, "Clermont": 15.991188, "Massagettes": 2.906016, "Villefranche": 2.906016, "Le Puy-en-Velay": 5.815272}	Le bon coin — boutique	30867	Renault	{Renault}	\N	f	f	2026-08-03 16:28:38.511	2026-08-03 16:28:38.511	\N
ce017637-183b-4bee-baf9-b28bc9737dd9	2026-07-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:28:49.453	2026-08-03 16:28:49.453	\N
3113befe-7097-42c0-b531-b916eb264d65	2026-07-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Print Conseil — Affiche Alpine Rond Point	84	Alpine	{Alpine}	\N	f	f	2026-08-03 16:28:57.885	2026-08-03 16:28:57.885	\N
ba622d67-13d3-4519-9d19-998cc0ad3173	2026-07-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	GRAPHIC — STICKER MOBILIZE VL	190	Renault	{Renault}	\N	f	f	2026-08-03 16:29:01.353	2026-08-03 16:29:01.353	\N
bb4117ac-ee20-4929-a822-1cfdb6b0356b	2026-07-01 00:00:00	VO	Albi, Aurillac, Figeac, Gaillac, Lavaur, Millau, Rodez, Villefranche	{Albi,Aurillac,Figeac,Gaillac,Lavaur,Millau,Rodez,Villefranche}	{"Albi": 20.939261, "Rodez": 14.806494, "Figeac": 5.672122, "Lavaur": 4.335119, "Millau": 4.476453, "Gaillac": 5.610616, "Aurillac": 31.753067, "Villefranche": 12.406868}	DEBREZ — VOILES + PIEDS + MATS	2292.44	Renault	{Renault}	\N	f	f	2026-08-03 16:29:06.669	2026-08-03 16:29:06.669	\N
d883af32-df86-4f69-b345-30387eb75bfa	2026-07-01 00:00:00	PR	Albi	{Albi}	{"Albi": 100}	DREAMCOM — Commande cartes de visite	143.78	Renault	{Renault}	\N	f	f	2026-08-03 16:29:08.935	2026-08-03 16:29:08.935	\N
167c6ac0-742f-4df9-80f5-3a5c0fb6191c	2026-07-01 00:00:00	VO	Albi	{Albi}	{"Albi": 100}	RVO — Stickers prêt à partir	32.4	Renault	{Renault}	\N	f	f	2026-08-03 16:29:11.132	2026-08-03 16:29:11.132	\N
534ff9e3-9d1b-4550-9939-67c31d59ec64	2026-08-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:29:11.854	2026-08-03 16:29:11.854	\N
95666e52-dec1-4ce0-afe7-fe173e75c9f4	2026-08-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:14.174	2026-08-03 16:29:14.174	\N
2a7c84a5-3cfc-4ee0-9c54-e7c037b6487f	2026-08-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:15.721	2026-08-03 16:29:15.721	\N
0edbd337-86a2-4cd5-b33f-ce27b91f0194	2026-08-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:29:23.171	2026-08-03 16:29:23.171	\N
9b1b765f-d4a6-490b-a626-5db161abff58	2026-07-01 00:00:00	VN	Albi, Aurillac, Figeac, Gaillac, Lavaur, Millau, Rodez, Villefranche	{Albi,Aurillac,Figeac,Gaillac,Lavaur,Millau,Rodez,Villefranche}	{"Albi": 20.939261, "Rodez": 14.806494, "Figeac": 5.672122, "Lavaur": 4.335119, "Millau": 4.476453, "Gaillac": 5.610616, "Aurillac": 31.753067, "Villefranche": 12.406868}	DEBREZ — VOILES + PIEDS + MATS	2292.44	Renault	{Renault}	\N	f	f	2026-08-03 16:29:05.868	2026-08-03 16:29:05.868	\N
7e58e45b-7d9b-48a0-9dd9-e0271282cae2	2026-08-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:30.478	2026-08-03 16:29:30.478	\N
098f1dfe-f9dd-46ce-ad7b-7adaca4fcc34	2026-08-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:29:21.937	2026-08-03 16:29:21.937	\N
98696b03-c3df-4d40-906c-7bde8b73879e	2026-08-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:29:32.085	2026-08-03 16:29:32.085	\N
75dbe8c8-2d13-4f99-9fae-5d93e2f31274	2026-08-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:32.737	2026-08-03 16:29:32.737	\N
79674e26-8741-4d00-bd68-4884c2eebb49	2026-08-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:29:33.635	2026-08-03 16:29:33.635	\N
4e6d43e3-0a2b-4129-8d97-de51e95389b3	2026-08-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:34.259	2026-08-03 16:29:34.259	\N
fb5056f6-2954-471c-8832-c170b75719b2	2026-08-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:34.902	2026-08-03 16:29:34.902	\N
8d3ed586-8bd6-4781-84e8-1d8170256537	2026-08-01 00:00:00	VO	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:35.771	2026-08-03 16:29:35.771	\N
a32f25c9-8f43-4afc-a99d-4b7a425dd3ea	2026-08-01 00:00:00	PR	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:36.404	2026-08-03 16:29:36.404	\N
69764d8a-74d5-4353-b6a6-a4c757520cd3	2026-08-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:37.105	2026-08-03 16:29:37.105	\N
b9b43311-dad1-4b84-8a9a-d4a76538951a	2026-08-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:40.022	2026-08-03 16:29:40.022	\N
41075173-d009-4c34-a39c-59152379ab95	2026-08-01 00:00:00	VO	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:41.164	2026-08-03 16:29:41.164	\N
24805630-1e52-4427-8c62-f7e31c7dfb02	2026-08-01 00:00:00	PR	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:41.849	2026-08-03 16:29:41.849	\N
40e7de6a-4d8d-4035-a182-688566104a85	2026-08-01 00:00:00	APV	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:42.591	2026-08-03 16:29:42.591	\N
7ec8c55c-9199-465b-88f7-fbcba7bc4eed	2026-08-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LLD BONY — véhicule rougerie	985	Renault	{Renault}	\N	f	f	2026-08-03 16:29:43.405	2026-08-03 16:29:43.405	\N
612306f3-3df0-4e4f-afe9-201b90e5cd3c	2026-08-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.26666, "Mende": 2.906016, "Mozac": 4.360644, "Rodez": 7.26666, "Ussel": 2.906016, "Vichy": 7.26666, "Figeac": 2.906016, "Lavaur": 2.906016, "Millau": 2.906016, "Ricoux": 4.360644, "Carmaux": 2.034535, "Gaillac": 5.815272, "Issoire": 6.398419, "Moulins": 5.815272, "Aurillac": 7.26666, "Clermont": 15.991188, "Massagettes": 2.906016, "Villefranche": 2.906016, "Le Puy-en-Velay": 5.815272}	Le bon coin — boutique	30867	Renault	{Renault}	\N	f	f	2026-08-03 16:29:44.12	2026-08-03 16:29:44.12	\N
562ec5d1-456d-4cdc-b9cb-1bd8a58859ea	2026-08-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	4759	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:44.869	2026-08-03 16:29:44.869	\N
d1a73868-a5f1-431c-879f-d1f6153ea3eb	2026-08-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:47.219	2026-08-03 16:29:47.219	\N
cdd7e4e6-f515-4c06-a5ee-485f5d47df2a	2026-08-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:48.038	2026-08-03 16:29:48.038	\N
5964b9d6-51fc-4499-95df-08b5d98b1356	2026-08-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:48.805	2026-08-03 16:29:48.805	\N
bb2f7dec-1aa0-438d-852b-9b7b49691903	2026-08-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:29:45.636	2026-08-03 16:29:45.636	\N
511dce36-f56c-4972-953c-43b8a9767dd8	2026-08-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:46.442	2026-08-03 16:29:46.442	\N
cadd0118-37d5-4fb1-9fdf-e915ebf087dd	2026-09-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:29:59.512	2026-08-03 16:29:59.512	\N
a278549d-dbea-45a5-9f77-c375a010ed59	2026-09-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:30:00.989	2026-08-03 16:30:00.989	\N
1f95ff86-ccbc-41c2-966d-e552f0db87f6	2026-09-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:30:02.546	2026-08-03 16:30:02.546	\N
5bb1e551-7672-43b9-9eec-361bc64dfab1	2026-09-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:30:04.863	2026-08-03 16:30:04.863	\N
17c421f0-3678-41db-9db3-11440111a85b	2026-09-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:30:06.423	2026-08-03 16:30:06.423	\N
82ea6b47-37f3-4b48-a8f7-f8aed31e0ad5	2026-09-01 00:00:00	VO	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:30:14.931	2026-08-03 16:30:14.931	\N
fe71c2f4-acba-467f-9d2e-9cca8d7f9b3c	2026-09-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:30:29.42	2026-08-03 16:30:29.42	\N
ad53fb92-0dfd-47e3-a72b-34460da47df3	2026-09-01 00:00:00	APV	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:30:41.639	2026-08-03 16:30:41.639	\N
e2346364-ab06-4505-8f0e-afc91821846b	2026-09-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LLD BONY — véhicule rougerie	985	Renault	{Renault}	\N	f	f	2026-08-03 16:30:43.754	2026-08-03 16:30:43.754	\N
47172d22-c59d-4232-96c2-0ee005d9005f	2026-09-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:30:57.916	2026-08-03 16:30:57.916	\N
8859a95a-6cce-4d45-9213-6606136a5095	2026-09-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:00.491	2026-08-03 16:31:00.491	\N
0949aaba-36a6-432e-998f-d2f10482a9e2	2026-09-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:31:09.536	2026-08-03 16:31:09.536	\N
c2c49568-4744-4316-8ec4-d68a995d7d78	2026-09-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:31:10.363	2026-08-03 16:31:10.363	\N
30e20440-1077-404b-a302-8fa475e46ee7	2026-10-01 00:00:00	PR	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:28.423	2026-08-03 16:31:28.423	\N
0f09f647-a306-4f01-b73f-68fd32602b2c	2026-08-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:29:49.568	2026-08-03 16:29:49.568	\N
6564c046-7383-4eb5-be92-76add7ec034d	2026-08-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:29:51.721	2026-08-03 16:29:51.721	\N
52d4542e-18de-45e6-9349-6da16ed3d24f	2026-08-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — phtoo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:29:53.28	2026-08-03 16:29:53.28	\N
8c774f6a-9e5e-40e2-8b0d-a2ea163403db	2026-09-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:30:07.208	2026-08-03 16:30:07.208	\N
2f7396a4-01ea-4d1b-9785-d9794b43198d	2026-09-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:30:25.556	2026-08-03 16:30:25.556	\N
d6c70c4f-8ed2-406f-b65d-8bee12a4f5ed	2026-09-01 00:00:00	VO	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:30:35.686	2026-08-03 16:30:35.686	\N
62bee2cf-a470-4b82-b9e1-d8cb7d2e7004	2026-09-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:30:59.103	2026-08-03 16:30:59.103	\N
e1a668ff-dd7c-4b16-9843-1f78e4fe6dc5	2026-10-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:35.903	2026-08-03 16:31:35.903	\N
752235fa-4770-43c3-b119-6c91dc7d945c	2026-10-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:31:39.707	2026-08-03 16:31:39.707	\N
7ec70508-2d9f-4f17-93b3-2c869c14f9a9	2026-10-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — phtoo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:45.958	2026-08-03 16:31:45.958	\N
074fcbe3-5741-4956-af13-4e58c9e46388	2026-11-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:31:46.751	2026-08-03 16:31:46.751	\N
cac7c7b0-48e9-4849-b64e-bfe8adb51c00	2026-11-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:47.441	2026-08-03 16:31:47.441	\N
198f35a0-b5d5-46c5-a961-f6133ac5efc6	2026-11-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:48.965	2026-08-03 16:31:48.965	\N
dd6692ed-035b-4ee6-8096-fdd8a9df0f43	2026-11-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:31:51.322	2026-08-03 16:31:51.322	\N
03316702-df83-4b33-9a7c-f0edb2bfebea	2026-11-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:52.071	2026-08-03 16:31:52.071	\N
621c8c42-f3d3-41fd-af20-c8a0c9de15ad	2026-11-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:31:52.839	2026-08-03 16:31:52.839	\N
8b049473-c33f-48ea-a57d-b9b9801fc3e0	2026-08-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:29:50.288	2026-08-03 16:29:50.288	\N
04078768-807c-41f6-921a-7c124c458af2	2026-08-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:29:51.075	2026-08-03 16:29:51.075	\N
e43a95f1-6e9f-4ca1-b6d3-906e1c0e01e0	2026-08-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — phtoo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:54.081	2026-08-03 16:29:54.081	\N
8b3e13d6-ed74-4405-9165-01da2d1cf6ed	2026-09-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:55.586	2026-08-03 16:29:55.586	\N
d5975be0-6ac6-4eaa-9dc6-bf2808a40e3e	2026-09-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:30:00.119	2026-08-03 16:30:00.119	\N
dbdc3c4f-2a02-4215-8ef4-a6d23c3fa967	2026-09-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:30:01.653	2026-08-03 16:30:01.653	\N
02e9b69d-694c-491f-b878-edf33fc52247	2026-09-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:30:04.062	2026-08-03 16:30:04.062	\N
ea24c127-3cec-40cc-a2a8-8436ebc8ebe7	2026-09-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:30:05.625	2026-08-03 16:30:05.625	\N
8e92d2fb-15f2-4d46-a26c-364067f727b7	2026-09-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:30:08.737	2026-08-03 16:30:08.737	\N
e5270fbd-976c-4e6a-a6f6-92effd2f508b	2026-10-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:31:13.931	2026-08-03 16:31:13.931	\N
98e4ad69-85dc-4804-92e6-8b5838a4c679	2026-10-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:31:15.467	2026-08-03 16:31:15.467	\N
c7d3ef3d-3889-4f0c-a610-e1ba4e75902c	2026-10-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:16.169	2026-08-03 16:31:16.169	\N
24d7be4c-78b3-4f11-84a2-e1c344c83a0f	2026-10-01 00:00:00	VO	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:30.519	2026-08-03 16:31:30.519	\N
fe8f0d23-a105-493e-89aa-cad881f235f4	2026-08-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:29:52.553	2026-08-03 16:29:52.553	\N
42beb2c5-f2ea-4bf9-9f91-6cb23a0f936c	2026-09-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:29:54.836	2026-08-03 16:29:54.836	\N
727e6edc-e0c0-4557-98ae-aa8cd2242d0f	2026-09-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:29:56.355	2026-08-03 16:29:56.355	\N
140f4874-4478-4593-ae9e-57e4472978f8	2026-09-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:30:10.355	2026-08-03 16:30:10.355	\N
05818b26-cdea-4a57-9117-411a09b4b022	2026-09-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:31:07.937	2026-08-03 16:31:07.937	\N
5ee74730-97af-4216-a2d4-bc7106c661c1	2026-09-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — phtoo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:31:11.004	2026-08-03 16:31:11.004	\N
29de5786-aecb-4f3f-8910-d1b3b7e9204a	2026-09-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — phtoo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:11.809	2026-08-03 16:31:11.809	\N
d57af4f9-11d0-485a-8001-683fb78cb8c4	2026-10-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:31:12.488	2026-08-03 16:31:12.488	\N
61aa9f8a-fd3c-423b-af4c-4b522d8eafef	2026-10-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:31:19.884	2026-08-03 16:31:19.884	\N
cffd766f-c1de-4172-96a1-8f35b0d4bfdc	2026-10-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:31:22.772	2026-08-03 16:31:22.772	\N
c3e08691-8dcb-4cda-9712-f97731ef8b96	2026-10-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:24.918	2026-08-03 16:31:24.918	\N
96c65c32-9399-43e0-8218-e6a97c0f49ee	2026-10-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:27.041	2026-08-03 16:31:27.041	\N
85bd0002-31cb-4bd3-8b16-5beae0b8123e	2026-09-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:57.085	2026-08-03 16:29:57.085	\N
18cd8763-d28b-4c8a-b1e3-b12a55881867	2026-09-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:29:57.909	2026-08-03 16:29:57.909	\N
ff09c945-7d67-4aeb-b7e0-096f3157dc4b	2026-09-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:29:58.643	2026-08-03 16:29:58.643	\N
4a7ec672-ad0d-4912-adb4-109e2201a627	2026-09-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:30:03.259	2026-08-03 16:30:03.259	\N
1e67215f-5cd6-4408-9460-e8937d4ca169	2026-09-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:30:07.953	2026-08-03 16:30:07.953	\N
67fe40e6-dd7b-42ba-b92a-6a8585443646	2026-09-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:30:09.523	2026-08-03 16:30:09.523	\N
3134542e-a0f4-4043-925e-61a377504aff	2026-09-01 00:00:00	PR	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:30:23.07	2026-08-03 16:30:23.07	\N
e425c655-4ffe-4151-8832-32c94fe22e9c	2026-09-01 00:00:00	PR	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:30:39.905	2026-08-03 16:30:39.905	\N
33efc22b-587b-4539-a9fe-0948e16e10ff	2026-09-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.26666, "Mende": 2.906016, "Mozac": 4.360644, "Rodez": 7.26666, "Ussel": 2.906016, "Vichy": 7.26666, "Figeac": 2.906016, "Lavaur": 2.906016, "Millau": 2.906016, "Ricoux": 4.360644, "Carmaux": 2.034535, "Gaillac": 5.815272, "Issoire": 6.398419, "Moulins": 5.815272, "Aurillac": 7.26666, "Clermont": 15.991188, "Massagettes": 2.906016, "Villefranche": 2.906016, "Le Puy-en-Velay": 5.815272}	Le bon coin — boutique	30867	Renault	{Renault}	\N	f	f	2026-08-03 16:30:48.654	2026-08-03 16:30:48.654	\N
e1b27697-77d5-4e08-b698-cfbfd3637d5e	2026-09-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	4759	Nissan	{Nissan}	\N	f	f	2026-08-03 16:30:52.805	2026-08-03 16:30:52.805	\N
d924dd5e-3237-4531-aad7-06acff6f45e3	2026-09-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:02.261	2026-08-03 16:31:02.261	\N
fa44ce36-7b48-4cbe-9ed1-0d59a1b5c423	2026-09-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:06.173	2026-08-03 16:31:06.173	\N
661dd994-24e4-47b9-8443-c25d51d4b3d3	2026-09-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:06.99	2026-08-03 16:31:06.99	\N
420bea5b-93b6-4fc3-8f37-4b61c834c29c	2026-09-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:31:08.822	2026-08-03 16:31:08.822	\N
47354c3c-3e1e-43c8-a3d8-da6dc17c97c2	2026-10-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:13.268	2026-08-03 16:31:13.268	\N
15742f91-05f1-4b12-a634-6d6a5de53af4	2026-10-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:14.734	2026-08-03 16:31:14.734	\N
87e81923-b455-45f5-84d1-1f1c3d1c2611	2026-10-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:17.654	2026-08-03 16:31:17.654	\N
6a12683d-53db-4520-9235-7363e19d66e8	2026-10-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:31:18.369	2026-08-03 16:31:18.369	\N
636fe5a5-f231-40b4-9bca-24dfd467dc5d	2026-10-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:31:16.899	2026-08-03 16:31:16.899	\N
de0e8e8f-a083-4225-9033-46de46660db5	2026-10-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:21.981	2026-08-03 16:31:21.981	\N
73ea8fc7-31b4-4079-97c3-5cd0bab467f5	2026-10-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:23.421	2026-08-03 16:31:23.421	\N
4d2ccc9e-f7d3-4a77-b151-ab43e86733c8	2026-10-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:31:24.31	2026-08-03 16:31:24.31	\N
e1de8841-1c1a-4f9f-b6dd-37bf04dc54a4	2026-10-01 00:00:00	VO	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:27.805	2026-08-03 16:31:27.805	\N
7fc43e24-6d0c-43e4-99c7-bbf4a6da744f	2026-10-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:31:19.105	2026-08-03 16:31:19.105	\N
8bbb02f6-8ba6-4ba2-858a-9bdcbe740ae3	2026-10-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:31:20.491	2026-08-03 16:31:20.491	\N
d9df15d2-85cc-437a-923f-4cfb582d821d	2026-10-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:29.797	2026-08-03 16:31:29.797	\N
65f4f720-5096-4dac-9dbc-c6dcb7ea8b83	2026-10-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.26666, "Mende": 2.906016, "Mozac": 4.360644, "Rodez": 7.26666, "Ussel": 2.906016, "Vichy": 7.26666, "Figeac": 2.906016, "Lavaur": 2.906016, "Millau": 2.906016, "Ricoux": 4.360644, "Carmaux": 2.034535, "Gaillac": 5.815272, "Issoire": 6.398419, "Moulins": 5.815272, "Aurillac": 7.26666, "Clermont": 15.991188, "Massagettes": 2.906016, "Villefranche": 2.906016, "Le Puy-en-Velay": 5.815272}	Le bon coin — boutique	30867	Renault	{Renault}	\N	f	f	2026-08-03 16:31:33.655	2026-08-03 16:31:33.655	\N
411c5ce0-86e8-4fd0-8c9f-0727687fc8f5	2026-10-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:31:35.164	2026-08-03 16:31:35.164	\N
7d03f188-74ba-464e-aebc-f73a3fc85d13	2026-10-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:31:44.33	2026-08-03 16:31:44.33	\N
b708fd76-64db-4048-a3fc-633a8457d931	2026-11-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:31:54.35	2026-08-03 16:31:54.35	\N
a3a43382-c53a-425a-b387-5726a2f3b36d	2026-11-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:31:55.89	2026-08-03 16:31:55.89	\N
d6bee1e8-45fa-4629-aa79-85a69ea4ecf2	2026-11-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:56.689	2026-08-03 16:31:56.689	\N
081719c1-63ec-400a-b5d5-994e548c2e1f	2026-11-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:05.172	2026-08-03 16:32:05.172	\N
4a3deefd-15cb-498f-8621-05b8159a80f2	2026-11-01 00:00:00	VO	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:05.817	2026-08-03 16:32:05.817	\N
d7710b91-2024-40e9-b766-46a9a9f423d7	2026-12-01 00:00:00	VO	Rodez	{Rodez}	{"Rodez": 100}	Graphic — pose logo rodez	936	Renault	{Renault}	\N	f	f	2026-08-03 16:32:48.203	2026-08-03 16:32:48.203	\N
816bc537-cc0c-4e97-a522-95f2db9e13bf	2026-12-01 00:00:00	APV	Rodez	{Rodez}	{"Rodez": 100}	Graphic — pose logo rodez	936	Renault	{Renault}	\N	f	f	2026-08-03 16:32:49.626	2026-08-03 16:32:49.626	\N
7d0e28c5-8a1d-4565-9604-ef7fe8f22875	2026-10-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:31:21.319	2026-08-03 16:31:21.319	\N
be078d57-5a1b-458b-bf60-18311649192b	2026-10-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:31:25.753	2026-08-03 16:31:25.753	\N
2e0c52c2-7f37-46fc-90c7-cdff4a2b8d0a	2026-10-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:26.411	2026-08-03 16:31:26.411	\N
487dc21a-caca-4938-ae63-0203ef946aaf	2026-10-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:29.009	2026-08-03 16:31:29.009	\N
3ebf933c-c3cb-4857-8898-f943ad3faf7b	2026-10-01 00:00:00	PR	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:31.457	2026-08-03 16:31:31.457	\N
344d4905-ff29-4f15-a58a-a6c766363337	2026-10-01 00:00:00	APV	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:32.201	2026-08-03 16:31:32.201	\N
b8242f28-81ce-4f63-9196-981356976b5e	2026-10-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LLD BONY — véhicule rougerie	985	Renault	{Renault}	\N	f	f	2026-08-03 16:31:32.987	2026-08-03 16:31:32.987	\N
c6e8ef66-c45f-4934-8a73-58c02863adf1	2026-10-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	4759	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:34.437	2026-08-03 16:31:34.437	\N
f8a6d1c6-4b46-468d-a403-7669b7b63528	2026-12-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:32:28.344	2026-08-03 16:32:28.344	\N
d2176506-450f-4196-b289-15cbc0e2e601	2026-10-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:36.603	2026-08-03 16:31:36.603	\N
17702e79-0356-4276-a5ac-518086dd7631	2026-10-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:37.356	2026-08-03 16:31:37.356	\N
34eaff9f-6ad2-4aaf-828d-43e7f8186892	2026-10-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:38.073	2026-08-03 16:31:38.073	\N
ff9d2165-5a5f-424b-983a-749bbf86476a	2026-10-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:31:38.905	2026-08-03 16:31:38.905	\N
95e02d01-eea7-43ad-92f4-7820d93b3310	2026-10-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:31:40.905	2026-08-03 16:31:40.905	\N
63c08ec1-a324-4ca1-ac2a-ca1652a31e78	2026-10-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:31:42.31	2026-08-03 16:31:42.31	\N
089bc322-7a77-4602-8536-d48daa471d3a	2026-10-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — phtoo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:31:45.168	2026-08-03 16:31:45.168	\N
ca7a1af7-c3a3-4330-a604-6eebed6e54ce	2026-11-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:31:48.325	2026-08-03 16:31:48.325	\N
e26262b1-7ee7-4cc4-a8b3-dd474c1fcddb	2026-11-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:31:49.778	2026-08-03 16:31:49.778	\N
24225fc1-bfed-40b0-9b29-4a1ae17fe13c	2026-11-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:50.428	2026-08-03 16:31:50.428	\N
47bcd08a-40fa-4c2b-9af3-c6f15c187d2e	2026-11-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:31:55.133	2026-08-03 16:31:55.133	\N
44753fc1-5578-4a50-ac9b-985112b35163	2026-11-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:31:57.375	2026-08-03 16:31:57.375	\N
ecd92001-d678-43de-820a-d0d96e45c9f4	2026-11-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:58.178	2026-08-03 16:31:58.178	\N
02ee5f85-551d-4cc4-85c7-f5c2178562f2	2026-11-01 00:00:00	VO	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:02.608	2026-08-03 16:32:02.608	\N
26be2214-2c4f-4ca7-9492-dee46d1bb47b	2026-11-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:04.293	2026-08-03 16:32:04.293	\N
5cc1956b-f53a-4634-be0b-5662af1616be	2026-11-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:32:16.445	2026-08-03 16:32:16.445	\N
2189af01-c0da-453b-afe3-c7c7728def4f	2026-11-01 00:00:00	VO	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 6.459948, "Mende": 4.823428, "Mozac": 6.459948, "Rodez": 8.096469, "Ussel": 4.823428, "Vichy": 8.096469, "Figeac": 4.823428, "Millau": 4.823428, "Ricoux": 4.823428, "Gaillac": 6.459948, "Issoire": 4.823428, "Moulins": 4.823428, "Aurillac": 6.459948, "Clermont": 11.283376, "Massagettes": 4.823428, "Le Puy-en-Velay": 8.096469}	plan de com	1161	Renault	{Renault}	\N	f	f	2026-08-03 16:31:53.625	2026-08-03 16:31:53.625	\N
dd2ae011-f625-4808-aff8-705e988d07ed	2026-11-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:31:59.606	2026-08-03 16:31:59.606	\N
13aa111c-6dac-41b3-860f-ece169b10892	2026-11-01 00:00:00	PR	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:03.574	2026-08-03 16:32:03.574	\N
df27b861-a8a9-4652-839f-f3569fb4692a	2026-11-01 00:00:00	PR	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:06.723	2026-08-03 16:32:06.723	\N
3e9b5be9-8982-4500-aa17-7acaecf01f95	2026-11-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LLD BONY — véhicule rougerie	985	Renault	{Renault}	\N	f	f	2026-08-03 16:32:08.166	2026-08-03 16:32:08.166	\N
5f3d35b8-4221-4b2b-a270-c59090434153	2026-11-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	4759	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:09.649	2026-08-03 16:32:09.649	\N
dfc402b9-5cb3-44bf-af87-d8afdb64c76e	2026-11-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:32:14.885	2026-08-03 16:32:14.885	\N
ce32b936-53bf-4922-83e8-33e99ab19b6b	2026-12-01 00:00:00	PR	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:32:22.457	2026-08-03 16:32:22.457	\N
427b2bad-4607-45e0-aaf0-1d4d45e1b06f	2026-12-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:26.685	2026-08-03 16:32:26.685	\N
7e14ffda-0d5f-4fb1-8c5c-2c8c8a8799c8	2026-11-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:31:58.835	2026-08-03 16:31:58.835	\N
94007295-5133-4d04-8884-e393e39f8b7e	2026-11-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:01.118	2026-08-03 16:32:01.118	\N
ca80a7b6-9157-4fb9-864f-0ddfe4e2602c	2026-11-01 00:00:00	APV	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:07.383	2026-08-03 16:32:07.383	\N
e055b0d0-8b91-4124-ac89-a5f4528d5a67	2026-11-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:32:15.641	2026-08-03 16:32:15.641	\N
ba3ae63d-24e9-4388-84ba-03fbf1617011	2026-11-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:32:17.288	2026-08-03 16:32:17.288	\N
a4de13f8-3efd-4fc5-833c-9d259c18ff98	2026-12-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:21.699	2026-08-03 16:32:21.699	\N
3f8b8b2e-2feb-4bc5-820e-1c093d5e25c6	2026-12-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:23.45	2026-08-03 16:32:23.45	\N
dbea2a65-ddc2-445e-8cdb-30b4a8de5a0d	2026-12-01 00:00:00	VN	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.417266, "Mende": 4.693461, "Mozac": 4.782184, "Rodez": 10.238666, "Ussel": 3.779611, "Vichy": 7.869754, "Figeac": 3.779611, "Millau": 3.779611, "Ricoux": 6.201757, "Gaillac": 3.788484, "Issoire": 6.352586, "Moulins": 5.917842, "Aurillac": 7.576967, "Clermont": 13.796469, "Massagettes": 1.916423, "Le Puy-en-Velay": 8.109307}	plan de com	11271	Renault	{Renault}	\N	f	f	2026-08-03 16:32:27.373	2026-08-03 16:32:27.373	\N
fe8bcc5a-c75c-47e8-a481-9addea36d930	2026-12-01 00:00:00	VN	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:32:30.424	2026-08-03 16:32:30.424	\N
abb10138-7d23-4cdf-87ab-137ab2ac98ac	2026-11-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:32:00.345	2026-08-03 16:32:00.345	\N
efbbedbf-7db0-4090-b002-1f81d461ab64	2026-11-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:01.989	2026-08-03 16:32:01.989	\N
8cf55aee-db5d-43cd-95f6-b30130165de1	2026-11-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:32:10.42	2026-08-03 16:32:10.42	\N
91ca62c1-f2cf-4e09-b026-abd5a412ccb2	2026-11-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:13.375	2026-08-03 16:32:13.375	\N
0f0219cd-46d5-40fc-9171-551ebf6a1d38	2026-11-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:14.076	2026-08-03 16:32:14.076	\N
b69748ba-1f99-49ae-8673-b0eb1c4e453d	2026-11-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — photo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:32:17.874	2026-08-03 16:32:17.874	\N
ff844b25-c098-455d-9f8a-df2c3104bec9	2026-12-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:32:20.957	2026-08-03 16:32:20.957	\N
38df7641-41df-4c7f-a8dd-6b925ae26a52	2026-12-01 00:00:00	APV	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:32:25.393	2026-08-03 16:32:25.393	\N
c640ecd9-507e-4833-ad54-224f04ef67c8	2026-12-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.786116, "Mende": 3.939962, "Mozac": 3.939962, "Rodez": 11.350844, "Ussel": 3.939962, "Vichy": 7.035647, "Figeac": 3.939962, "Millau": 3.939962, "Ricoux": 3.939962, "Gaillac": 5.440901, "Issoire": 5.159475, "Moulins": 4.690432, "Aurillac": 7.786116, "Clermont": 16.228893, "Massagettes": 3.095685, "Le Puy-en-Velay": 7.786116}	plan de com	1066	Renault	{Renault}	\N	f	f	2026-08-03 16:32:28.962	2026-08-03 16:32:28.962	\N
616d413d-8796-4022-834d-398b52564268	2026-11-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.26666, "Mende": 2.906016, "Mozac": 4.360644, "Rodez": 7.26666, "Ussel": 2.906016, "Vichy": 7.26666, "Figeac": 2.906016, "Lavaur": 2.906016, "Millau": 2.906016, "Ricoux": 4.360644, "Carmaux": 2.034535, "Gaillac": 5.815272, "Issoire": 6.398419, "Moulins": 5.815272, "Aurillac": 7.26666, "Clermont": 15.991188, "Massagettes": 2.906016, "Villefranche": 2.906016, "Le Puy-en-Velay": 5.815272}	Le bon coin — boutique	30867	Renault	{Renault}	\N	f	f	2026-08-03 16:32:08.906	2026-08-03 16:32:08.906	\N
acfdc134-d38b-485e-9d2b-120365a8961c	2026-11-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:11.176	2026-08-03 16:32:11.176	\N
c56a9466-47a1-4284-8cca-25c9e5ecb170	2026-11-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:11.924	2026-08-03 16:32:11.924	\N
a67f554b-8add-484b-9b7a-5f407095b073	2026-11-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:12.627	2026-08-03 16:32:12.627	\N
625941b1-da44-45b6-9a79-4608e0d5adaf	2026-11-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — photo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:18.791	2026-08-03 16:32:18.791	\N
6a8e949a-1853-4198-bcbf-acbfdd4a96cc	2026-12-01 00:00:00	VN	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.693021, "Mende": 2.770911, "Mozac": 5.012646, "Rodez": 8.458839, "Ussel": 2.534804, "Vichy": 7.696689, "Figeac": 2.819613, "Lavaur": 0.712024, "Millau": 2.449361, "Ricoux": 4.398027, "Carmaux": 1.765818, "Gaillac": 3.873408, "Issoire": 5.496822, "Moulins": 5.496822, "Aurillac": 6.693021, "Clermont": 22.642348, "Massagettes": 1.594933, "Villefranche": 1.765818, "Le Puy-en-Velay": 7.125077}	Toubkalpes — RS	3511.12	Renault	{Renault}	\N	f	f	2026-08-03 16:32:19.437	2026-08-03 16:32:19.437	\N
6d6cbdda-e161-471c-b78d-087bbb803076	2026-12-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Toubkalpes — RS	347	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:20.27	2026-08-03 16:32:20.27	\N
92a8f739-3eec-4864-a331-c6007591207f	2026-12-01 00:00:00	APV	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 5.220257, "Mende": 4.179674, "Mozac": 5.116198, "Rodez": 4.682622, "Ussel": 4.006243, "Vichy": 7.388137, "Figeac": 4.734651, "Lavaur": 3.381894, "Millau": 4.04093, "Ricoux": 6.6077, "Gaillac": 4.665279, "Issoire": 9.538675, "Moulins": 5.306972, "Aurillac": 5.2376, "Clermont": 9.885536, "Massagettes": 3.936871, "Villefranche": 2.306625, "Le Puy-en-Velay": 9.764135}	PMR — com natio apv	5766	Renault	{Renault}	\N	f	f	2026-08-03 16:32:29.791	2026-08-03 16:32:29.791	\N
882f62c4-1058-4bd9-a7f9-0b01dfde2853	2026-12-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:31.389	2026-08-03 16:32:31.389	\N
6533096e-f23d-429d-bdad-d53ecde9490d	2026-12-01 00:00:00	VO	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:32:32.147	2026-08-03 16:32:32.147	\N
aa1ede83-8b4c-4194-8e75-e5a016f6a9d2	2026-12-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:33.105	2026-08-03 16:32:33.105	\N
540bda21-fe88-4987-afb6-9282df1b028a	2026-12-01 00:00:00	PR	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:32:34.188	2026-08-03 16:32:34.188	\N
cc1ef238-cd58-4d79-8448-a7ed9a72f8ea	2026-12-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:34.89	2026-08-03 16:32:34.89	\N
8c0daf48-e865-4733-81bd-3c4c534f326a	2026-12-01 00:00:00	APV	Albi, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 2.173913, "Mende": 0.695652, "Mozac": 10.347826, "Rodez": 11.478261, "Ussel": 1.478261, "Vichy": 3.913043, "Figeac": 0.782609, "Ricoux": 2.782609, "Gaillac": 2.608696, "Issoire": 6.608696, "Moulins": 5.391304, "Clermont": 47.217391, "Massagettes": 1.391304, "Villefranche": 1.73913, "Le Puy-en-Velay": 1.391304}	Rugby store — vetements	1150	Renault	{Renault}	\N	f	f	2026-08-03 16:32:35.623	2026-08-03 16:32:35.623	\N
bd98fa40-3d62-4ff3-8294-48b2830dce80	2026-12-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Rugby store — vetements	193	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:36.446	2026-08-03 16:32:36.446	\N
053d451e-da77-4964-9ef4-28d3e3082f0d	2026-12-01 00:00:00	VN	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:37.275	2026-08-03 16:32:37.275	\N
a69f461e-2040-4445-906c-c6e0b8403b92	2026-12-01 00:00:00	VO	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:38.093	2026-08-03 16:32:38.093	\N
89a67082-3466-4531-8f69-cbc8f5784580	2026-12-01 00:00:00	PR	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:38.894	2026-08-03 16:32:38.894	\N
cfe5300b-2c64-4430-8a5f-2ca2573369cc	2026-12-01 00:00:00	APV	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	Diago — le puy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:39.775	2026-08-03 16:32:39.775	\N
03f77e84-a020-4be6-99c1-1b07efd0c792	2026-12-01 00:00:00	VN	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:40.542	2026-08-03 16:32:40.542	\N
6022ed49-41dd-4f14-aa25-b91f5edcb8d8	2026-12-01 00:00:00	VO	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:41.26	2026-08-03 16:32:41.26	\N
28c277c8-3e96-44e8-b047-383019980b05	2026-12-01 00:00:00	PR	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:42.088	2026-08-03 16:32:42.088	\N
861f8645-aee9-4cbb-a2b4-cb923c10ec2f	2026-12-01 00:00:00	APV	Issoire	{Issoire}	{"Issoire": 100}	Diago — Issoire	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:42.773	2026-08-03 16:32:42.773	\N
46510824-899b-4437-881b-fb0a2bbedfcc	2026-12-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	LLD BONY — véhicule rougerie	985	Renault	{Renault}	\N	f	f	2026-08-03 16:32:43.559	2026-08-03 16:32:43.559	\N
1a1fb4dc-fba3-45cb-9375-393eae7b8c99	2026-12-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Le bon coin — boutique	4759	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:45.147	2026-08-03 16:32:45.147	\N
259c9b63-bdbe-41f8-8abf-310f5eb0e0fd	2026-12-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Nextlane — detourage photo	526	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:46.676	2026-08-03 16:32:46.676	\N
4f5a7d58-fd28-45de-bc77-1602e391c6cd	2026-12-01 00:00:00	VO	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.26666, "Mende": 2.906016, "Mozac": 4.360644, "Rodez": 7.26666, "Ussel": 2.906016, "Vichy": 7.26666, "Figeac": 2.906016, "Lavaur": 2.906016, "Millau": 2.906016, "Ricoux": 4.360644, "Carmaux": 2.034535, "Gaillac": 5.815272, "Issoire": 6.398419, "Moulins": 5.815272, "Aurillac": 7.26666, "Clermont": 15.991188, "Massagettes": 2.906016, "Villefranche": 2.906016, "Le Puy-en-Velay": 5.815272}	Le bon coin — boutique	30867	Renault	{Renault}	\N	f	f	2026-08-03 16:32:44.293	2026-08-03 16:32:44.293	\N
31271680-f6ea-4b10-8200-67199d56a3cb	2026-12-01 00:00:00	APV	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:32:55.715	2026-08-03 16:32:55.715	\N
58e4e507-eb95-403d-8460-c9370938fbd0	2026-12-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.5803, "Mende": 3.554604, "Mozac": 9.464668, "Rodez": 11.563169, "Ussel": 5.310493, "Vichy": 11.220557, "Figeac": 3.940043, "Lavaur": 1.841542, "Millau": 3.940043, "Ricoux": 7.408994, "Carmaux": 4.8394, "Gaillac": 7.5803, "Issoire": 6.466809, "Aurillac": 6.680942, "Massagettes": 5.610278, "Villefranche": 2.997859}	Nextlane — detourage photo	2335	Renault	{Renault}	\N	f	f	2026-08-03 16:32:45.801	2026-08-03 16:32:45.801	\N
62034904-fdf7-4228-a83d-77f041fe09af	2026-12-01 00:00:00	VN	Rodez	{Rodez}	{"Rodez": 100}	Graphic — pose logo rodez	936	Renault	{Renault}	\N	f	f	2026-08-03 16:32:47.369	2026-08-03 16:32:47.369	\N
61272e89-34ee-4f30-b1f2-4f93b5a47133	2026-12-01 00:00:00	PR	Rodez	{Rodez}	{"Rodez": 100}	Graphic — pose logo rodez	936	Renault	{Renault}	\N	f	f	2026-08-03 16:32:48.859	2026-08-03 16:32:48.859	\N
7c93ab26-b2c5-43d8-ad80-737bb29b2fcf	2026-12-01 00:00:00	PR	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:51.791	2026-08-03 16:32:51.791	\N
d74fa85f-ab54-4695-a83c-5b7a8304de7e	2026-12-01 00:00:00	PR	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:32:54.861	2026-08-03 16:32:54.861	\N
4b08c7d8-a8dc-4931-8111-593427332480	2026-12-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	stampit nextlane — phtoo vo	522	Nissan	{Nissan}	\N	f	f	2026-08-03 16:32:57.38	2026-08-03 16:32:57.38	\N
f8e76bde-120e-46b7-9418-918cd612c567	2026-12-01 00:00:00	VN	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:50.367	2026-08-03 16:32:50.367	\N
4856ea12-11e3-4395-af5c-ae4d3e92060c	2026-12-01 00:00:00	VN	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:32:53.32	2026-08-03 16:32:53.32	\N
ccd08828-c7bd-4b82-b128-616ea8703c2a	2026-12-01 00:00:00	VO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Issoire, Lavaur, Massagettes, Mende, Millau, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Issoire,Lavaur,Massagettes,Mende,Millau,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 7.593308, "Mende": 3.517804, "Mozac": 9.438009, "Rodez": 11.540112, "Ussel": 5.319605, "Vichy": 11.239811, "Figeac": 3.946804, "Lavaur": 1.844702, "Millau": 3.946804, "Ricoux": 7.378807, "Carmaux": 4.847705, "Gaillac": 7.593308, "Issoire": 6.477906, "Aurillac": 6.692407, "Massagettes": 5.619906, "Villefranche": 3.003003}	stampit nextlane — phtoo vo	2331	Renault	{Renault}	\N	f	f	2026-08-03 16:32:56.58	2026-08-03 16:32:56.58	\N
f96a2dbf-e0ae-4918-b315-2c4f6ebdf380	2026-12-01 00:00:00	VO	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:51.151	2026-08-03 16:32:51.151	\N
8154f273-03ee-4e99-b54e-0d670aa54faa	2026-12-01 00:00:00	APV	Vichy	{Vichy}	{"Vichy": 100}	DIAGO — vichy	125	Renault	{Renault}	\N	f	f	2026-08-03 16:32:52.564	2026-08-03 16:32:52.564	\N
60f48d56-68af-47ee-8a5b-ce4c37498029	2026-12-01 00:00:00	VO	Clermont	{Clermont}	{"Clermont": 100}	Diago — Clermont	225	Renault	{Renault}	\N	f	f	2026-08-03 16:32:54.175	2026-08-03 16:32:54.175	\N
\.


--
-- Data for Name: GameChallenge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."GameChallenge" (id, "fromUserId", "toUserId", game, status, "sessionId", "createdAt", "updatedAt") FROM stdin;
9dfedd72-3285-4950-8dac-1592c55cba3a	3939fc4c-1695-43de-887a-f36aa87363fb	af47c934-5e71-4adf-9a0a-92f966af2fdc	morpion	accepted	48cb2037-9562-4c2c-9ca0-602d63cccd5f	2026-08-05 14:28:13.239	2026-08-05 14:29:52.236
5270fc3a-eab5-4b97-8990-ca6988105b7c	3939fc4c-1695-43de-887a-f36aa87363fb	15025839-a51c-4bf2-8cff-703d5e7be91c	connect4	pending	\N	2026-08-05 17:39:56.985	2026-08-05 17:39:56.985
699c27de-47ef-4d59-8352-2096c2ed51c8	3939fc4c-1695-43de-887a-f36aa87363fb	744a1e04-b73b-4d48-b2b3-bc290a14ec80	battleship	accepted	e392cd8f-1059-4c1d-acb7-84cd24544efd	2026-08-05 17:39:51.727	2026-08-06 07:12:23.519
8918969c-bbeb-4a31-8372-44f4a26591ac	3939fc4c-1695-43de-887a-f36aa87363fb	744a1e04-b73b-4d48-b2b3-bc290a14ec80	morpion	accepted	21bdbea0-5165-415e-84ec-747d15e08969	2026-08-06 07:40:19.286	2026-08-06 07:40:21.47
f0c76833-1846-48e9-8306-c66ebe549298	3939fc4c-1695-43de-887a-f36aa87363fb	744a1e04-b73b-4d48-b2b3-bc290a14ec80	connect4	accepted	f7af8bd6-21b4-4ef4-a41f-ed4fd37f7220	2026-08-06 07:41:10.471	2026-08-06 07:41:13.424
bc422f89-66d5-4d80-bfa5-226d37fbbc45	3939fc4c-1695-43de-887a-f36aa87363fb	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	battleship	accepted	20755a32-38b0-4254-8238-dff234e1be4c	2026-08-05 17:39:45.94	2026-08-06 14:06:34.453
a447ae39-425a-419c-a491-3a51ad4ffd51	3939fc4c-1695-43de-887a-f36aa87363fb	f777e039-859f-4632-aaba-92ea63a64eb8	battleship	accepted	a49f88f0-ce70-4fcd-9399-68f990ef5be3	2026-08-05 17:39:49.907	2026-08-06 14:24:43.242
d66c81ab-b48a-4dc8-b3c2-7dabbbc24b25	3939fc4c-1695-43de-887a-f36aa87363fb	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	connect4	accepted	3a2a9592-a038-46b4-872b-6fcbf687f3c8	2026-08-06 14:35:17.139	2026-08-06 14:43:16.603
ff713614-7e93-4e93-982e-faa912edecca	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	3939fc4c-1695-43de-887a-f36aa87363fb	morpion	accepted	755e9481-5cb5-4bea-9849-956d0913abae	2026-08-06 14:46:30.077	2026-08-06 14:46:33.835
b664fe91-dd7e-4123-8072-053c150ea36e	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	3939fc4c-1695-43de-887a-f36aa87363fb	battleship	accepted	8034a326-3c5f-44e2-bba0-b4a28177b92e	2026-08-06 14:47:49.313	2026-08-06 14:47:59.435
c211305d-8b26-4c5c-80ed-8cec0cc8c21d	3939fc4c-1695-43de-887a-f36aa87363fb	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	battleship	accepted	bef5e457-e799-4315-9f24-6a96699f7e88	2026-08-06 14:51:13.243	2026-08-06 14:52:25.994
77975b7a-f8ef-4a00-aa4a-4125e3174e87	3939fc4c-1695-43de-887a-f36aa87363fb	f777e039-859f-4632-aaba-92ea63a64eb8	connect4	accepted	780b646c-d802-4ad4-a93b-c4b8eee8d242	2026-08-06 14:33:52.214	2026-08-06 14:54:47.116
ee170296-7b1f-40ba-9bac-15c47bced3f4	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	f777e039-859f-4632-aaba-92ea63a64eb8	morpion	accepted	aa7f443b-fc3f-48a8-8acc-9cca05c3aa76	2026-08-06 15:07:19.304	2026-08-06 15:08:30.689
10005307-4094-4b01-833c-5db33f182214	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	f777e039-859f-4632-aaba-92ea63a64eb8	connect4	accepted	25dd9fa5-9f25-46db-8f52-500c017a2f22	2026-08-06 15:10:39.199	2026-08-06 15:10:45.643
e924eb7c-42b4-4e41-a1e5-7ce7e70f2638	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	f777e039-859f-4632-aaba-92ea63a64eb8	connect4	accepted	60940cc6-30b0-49ad-85d1-435235910ad2	2026-08-06 15:13:35.524	2026-08-06 15:15:00.443
\.


--
-- Data for Name: GameSession; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."GameSession" (id, game, "player1Id", "player2Id", "currentTurn", board, status, "winnerId", "createdAt", "updatedAt") FROM stdin;
48cb2037-9562-4c2c-9ca0-602d63cccd5f	morpion	3939fc4c-1695-43de-887a-f36aa87363fb	af47c934-5e71-4adf-9a0a-92f966af2fdc	3939fc4c-1695-43de-887a-f36aa87363fb	{"cells": ["p1", "p2", null, "p1", "p2", null, "p1", null, null], "winningLine": [0, 3, 6]}	finished	3939fc4c-1695-43de-887a-f36aa87363fb	2026-08-05 14:29:51.997	2026-08-05 14:31:19.623
f7af8bd6-21b4-4ef4-a41f-ed4fd37f7220	connect4	3939fc4c-1695-43de-887a-f36aa87363fb	744a1e04-b73b-4d48-b2b3-bc290a14ec80	3939fc4c-1695-43de-887a-f36aa87363fb	{"cells": [[null, null, null, null, null, null, null], [null, null, null, null, null, null, null], [null, null, null, null, "p1", null, null], [null, null, null, "p1", "p2", null, null], [null, null, "p1", "p2", "p2", null, null], [null, "p1", "p2", "p1", "p2", "p1", null]], "lastMove": [3, 3], "winningLine": [[2, 4], [3, 3], [4, 2], [5, 1]]}	finished	3939fc4c-1695-43de-887a-f36aa87363fb	2026-08-06 07:41:13.382	2026-08-06 07:42:51.71
e392cd8f-1059-4c1d-acb7-84cd24544efd	battleship	3939fc4c-1695-43de-887a-f36aa87363fb	744a1e04-b73b-4d48-b2b3-bc290a14ec80	3939fc4c-1695-43de-887a-f36aa87363fb	{"p1": {"ready": true, "ships": [{"hits": 5, "name": "Porte-avions", "size": 5, "cells": [[9, 0], [9, 1], [9, 2], [9, 3], [9, 4]]}, {"hits": 4, "name": "Croiseur", "size": 4, "cells": [[4, 8], [5, 8], [6, 8], [7, 8]]}, {"hits": 3, "name": "Destroyer", "size": 3, "cells": [[5, 3], [5, 4], [5, 5]]}, {"hits": 3, "name": "Sous-marin", "size": 3, "cells": [[1, 7], [1, 8], [1, 9]]}, {"hits": 0, "name": "Torpilleur", "size": 2, "cells": [[1, 1], [2, 1]]}], "shots": {"0,1": "miss", "0,4": "miss", "0,6": "miss", "0,7": "miss", "0,8": "miss", "0,9": "miss", "1,0": "miss", "1,2": "miss", "1,3": "miss", "1,5": "miss", "1,6": "miss", "1,7": "hit", "1,8": "hit", "1,9": "hit", "2,2": "miss", "2,4": "miss", "2,6": "miss", "2,7": "miss", "2,8": "miss", "2,9": "miss", "3,0": "miss", "3,1": "miss", "3,5": "miss", "3,7": "miss", "3,8": "miss", "3,9": "miss", "4,2": "miss", "4,3": "miss", "4,4": "miss", "4,5": "miss", "4,6": "miss", "4,7": "miss", "4,8": "hit", "4,9": "miss", "5,0": "miss", "5,2": "miss", "5,3": "hit", "5,4": "hit", "5,5": "hit", "5,6": "miss", "5,7": "miss", "5,8": "hit", "5,9": "miss", "6,1": "miss", "6,2": "miss", "6,3": "miss", "6,4": "miss", "6,5": "miss", "6,6": "miss", "6,7": "miss", "6,8": "hit", "6,9": "miss", "7,3": "miss", "7,7": "miss", "7,8": "hit", "7,9": "miss", "8,0": "miss", "8,1": "miss", "8,2": "miss", "8,3": "miss", "8,4": "miss", "8,5": "miss", "8,6": "miss", "8,7": "miss", "8,8": "miss", "8,9": "miss", "9,0": "hit", "9,1": "hit", "9,2": "hit", "9,3": "hit", "9,4": "hit", "9,5": "miss", "9,8": "miss"}}, "p2": {"ready": true, "ships": [{"hits": 5, "name": "Porte-avions", "size": 5, "cells": [[6, 3], [6, 4], [6, 5], [6, 6], [6, 7]]}, {"hits": 4, "name": "Croiseur", "size": 4, "cells": [[4, 1], [5, 1], [6, 1], [7, 1]]}, {"hits": 3, "name": "Destroyer", "size": 3, "cells": [[2, 4], [2, 5], [2, 6]]}, {"hits": 3, "name": "Sous-marin", "size": 3, "cells": [[8, 4], [8, 5], [8, 6]]}, {"hits": 2, "name": "Torpilleur", "size": 2, "cells": [[3, 9], [4, 9]]}], "shots": {"0,0": "miss", "0,3": "miss", "0,6": "miss", "0,9": "miss", "1,1": "miss", "1,3": "miss", "1,4": "miss", "1,5": "miss", "1,6": "miss", "1,7": "miss", "1,8": "miss", "2,2": "miss", "2,3": "miss", "2,4": "hit", "2,5": "hit", "2,6": "hit", "2,7": "miss", "2,8": "miss", "2,9": "miss", "3,0": "miss", "3,1": "miss", "3,2": "miss", "3,3": "miss", "3,4": "miss", "3,5": "miss", "3,6": "miss", "3,7": "miss", "3,8": "miss", "3,9": "hit", "4,0": "miss", "4,1": "hit", "4,2": "miss", "4,5": "miss", "4,8": "miss", "4,9": "hit", "5,0": "miss", "5,1": "hit", "5,2": "miss", "5,3": "miss", "5,4": "miss", "5,5": "miss", "5,6": "miss", "5,7": "miss", "5,8": "miss", "5,9": "miss", "6,0": "miss", "6,1": "hit", "6,2": "miss", "6,3": "hit", "6,4": "hit", "6,5": "hit", "6,6": "hit", "6,7": "hit", "6,8": "miss", "7,0": "miss", "7,1": "hit", "7,2": "miss", "7,3": "miss", "7,4": "miss", "7,5": "miss", "7,6": "miss", "7,7": "miss", "7,8": "miss", "7,9": "miss", "8,0": "miss", "8,1": "miss", "8,2": "miss", "8,3": "miss", "8,4": "hit", "8,5": "hit", "8,6": "hit", "8,7": "miss", "8,8": "miss", "9,0": "miss", "9,1": "miss", "9,3": "miss", "9,4": "miss", "9,5": "miss", "9,6": "miss", "9,7": "miss", "9,9": "miss"}}}	finished	3939fc4c-1695-43de-887a-f36aa87363fb	2026-08-06 07:12:23.476	2026-08-06 07:38:18.383
21bdbea0-5165-415e-84ec-747d15e08969	morpion	3939fc4c-1695-43de-887a-f36aa87363fb	744a1e04-b73b-4d48-b2b3-bc290a14ec80	3939fc4c-1695-43de-887a-f36aa87363fb	{"cells": ["p1", "p2", "p1", "p2", "p1", null, "p1", null, "p2"], "winningLine": [2, 4, 6]}	finished	3939fc4c-1695-43de-887a-f36aa87363fb	2026-08-06 07:40:21.427	2026-08-06 07:41:01.618
20755a32-38b0-4254-8238-dff234e1be4c	battleship	3939fc4c-1695-43de-887a-f36aa87363fb	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	3939fc4c-1695-43de-887a-f36aa87363fb	{"p1": {"ready": true, "ships": [{"hits": 5, "name": "Porte-avions", "size": 5, "cells": [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7]]}, {"hits": 4, "name": "Croiseur", "size": 4, "cells": [[3, 0], [3, 1], [3, 2], [3, 3]]}, {"hits": 3, "name": "Destroyer", "size": 3, "cells": [[9, 1], [9, 2], [9, 3]]}, {"hits": 1, "name": "Sous-marin", "size": 3, "cells": [[9, 5], [9, 6], [9, 7]]}, {"hits": 2, "name": "Torpilleur", "size": 2, "cells": [[1, 4], [1, 5]]}], "shots": {"0,1": "miss", "0,3": "miss", "0,4": "miss", "0,5": "miss", "0,6": "miss", "0,7": "miss", "0,8": "miss", "1,2": "miss", "1,3": "miss", "1,4": "hit", "1,5": "hit", "1,6": "miss", "1,7": "hit", "1,8": "miss", "2,0": "miss", "2,1": "miss", "2,2": "miss", "2,3": "miss", "2,4": "miss", "2,5": "miss", "2,6": "miss", "2,7": "hit", "2,8": "miss", "2,9": "miss", "3,0": "hit", "3,1": "hit", "3,2": "hit", "3,3": "hit", "3,4": "miss", "3,5": "miss", "3,6": "miss", "3,7": "hit", "3,8": "miss", "4,0": "miss", "4,1": "miss", "4,2": "miss", "4,3": "miss", "4,4": "miss", "4,6": "miss", "4,7": "hit", "4,8": "miss", "4,9": "miss", "5,2": "miss", "5,4": "miss", "5,6": "miss", "5,7": "hit", "5,8": "miss", "6,1": "miss", "6,5": "miss", "6,6": "miss", "6,7": "miss", "6,8": "miss", "7,2": "miss", "7,4": "miss", "7,6": "miss", "7,9": "miss", "8,0": "miss", "8,1": "miss", "8,2": "miss", "8,3": "miss", "8,4": "miss", "8,7": "miss", "9,0": "miss", "9,1": "hit", "9,2": "hit", "9,3": "hit", "9,4": "miss", "9,5": "hit", "9,8": "miss", "9,9": "miss"}}, "p2": {"ready": true, "ships": [{"hits": 5, "name": "Porte-avions", "size": 5, "cells": [[1, 2], [2, 2], [3, 2], [4, 2], [5, 2]]}, {"hits": 4, "name": "Croiseur", "size": 4, "cells": [[0, 4], [0, 5], [0, 6], [0, 7]]}, {"hits": 3, "name": "Destroyer", "size": 3, "cells": [[2, 4], [2, 5], [2, 6]]}, {"hits": 3, "name": "Sous-marin", "size": 3, "cells": [[4, 4], [4, 5], [4, 6]]}, {"hits": 2, "name": "Torpilleur", "size": 2, "cells": [[0, 9], [1, 9]]}], "shots": {"0,0": "miss", "0,1": "miss", "0,2": "miss", "0,3": "miss", "0,4": "hit", "0,5": "hit", "0,6": "hit", "0,7": "hit", "0,8": "miss", "0,9": "hit", "1,1": "miss", "1,2": "hit", "1,3": "miss", "1,4": "miss", "1,5": "miss", "1,6": "miss", "1,7": "miss", "1,8": "miss", "1,9": "hit", "2,1": "miss", "2,2": "hit", "2,3": "miss", "2,4": "hit", "2,5": "hit", "2,6": "hit", "2,7": "miss", "2,8": "miss", "2,9": "miss", "3,0": "miss", "3,1": "miss", "3,2": "hit", "3,3": "miss", "3,4": "miss", "3,5": "miss", "3,6": "miss", "3,7": "miss", "3,9": "miss", "4,1": "miss", "4,2": "hit", "4,3": "miss", "4,4": "hit", "4,5": "hit", "4,6": "hit", "4,7": "miss", "4,8": "miss", "5,1": "miss", "5,2": "hit", "5,3": "miss", "5,4": "miss", "5,5": "miss", "5,6": "miss", "5,7": "miss", "6,0": "miss", "6,1": "miss", "6,2": "miss", "6,3": "miss", "6,6": "miss", "6,9": "miss", "7,2": "miss", "7,5": "miss", "7,7": "miss", "8,1": "miss", "8,4": "miss", "8,8": "miss", "9,0": "miss", "9,3": "miss", "9,6": "miss", "9,9": "miss"}}}	finished	3939fc4c-1695-43de-887a-f36aa87363fb	2026-08-06 14:06:34.408	2026-08-06 14:20:20.092
a49f88f0-ce70-4fcd-9399-68f990ef5be3	battleship	3939fc4c-1695-43de-887a-f36aa87363fb	f777e039-859f-4632-aaba-92ea63a64eb8	f777e039-859f-4632-aaba-92ea63a64eb8	{"p1": {"ready": true, "ships": [{"hits": 5, "name": "Porte-avions", "size": 5, "cells": [[0, 2], [0, 3], [0, 4], [0, 5], [0, 6]]}, {"hits": 4, "name": "Croiseur", "size": 4, "cells": [[4, 5], [4, 6], [4, 7], [4, 8]]}, {"hits": 3, "name": "Destroyer", "size": 3, "cells": [[2, 1], [3, 1], [4, 1]]}, {"hits": 3, "name": "Sous-marin", "size": 3, "cells": [[6, 8], [7, 8], [8, 8]]}, {"hits": 2, "name": "Torpilleur", "size": 2, "cells": [[8, 5], [8, 6]]}], "shots": {"0,1": "miss", "0,2": "hit", "0,3": "hit", "0,4": "hit", "0,5": "hit", "0,6": "hit", "0,7": "miss", "0,9": "miss", "1,0": "miss", "1,1": "miss", "1,2": "miss", "1,3": "miss", "1,4": "miss", "1,5": "miss", "1,6": "miss", "1,7": "miss", "1,8": "miss", "2,0": "miss", "2,1": "hit", "2,2": "miss", "2,3": "miss", "2,6": "miss", "3,0": "miss", "3,1": "hit", "3,2": "miss", "3,4": "miss", "3,5": "miss", "3,6": "miss", "3,7": "miss", "3,8": "miss", "3,9": "miss", "4,0": "miss", "4,1": "hit", "4,2": "miss", "4,4": "miss", "4,5": "hit", "4,6": "hit", "4,7": "hit", "4,8": "hit", "4,9": "miss", "5,0": "miss", "5,1": "miss", "5,2": "miss", "5,4": "miss", "5,5": "miss", "5,6": "miss", "5,7": "miss", "5,8": "miss", "5,9": "miss", "6,7": "miss", "6,8": "hit", "6,9": "miss", "7,4": "miss", "7,5": "miss", "7,6": "miss", "7,7": "miss", "7,8": "hit", "7,9": "miss", "8,2": "miss", "8,4": "miss", "8,5": "hit", "8,6": "hit", "8,7": "miss", "8,8": "hit", "8,9": "miss", "9,4": "miss", "9,5": "miss", "9,6": "miss", "9,7": "miss", "9,8": "miss", "9,9": "miss"}}, "p2": {"ready": true, "ships": [{"hits": 5, "name": "Porte-avions", "size": 5, "cells": [[9, 5], [9, 6], [9, 7], [9, 8], [9, 9]]}, {"hits": 1, "name": "Croiseur", "size": 4, "cells": [[2, 1], [2, 2], [2, 3], [2, 4]]}, {"hits": 0, "name": "Destroyer", "size": 3, "cells": [[9, 1], [9, 2], [9, 3]]}, {"hits": 0, "name": "Sous-marin", "size": 3, "cells": [[4, 7], [5, 7], [6, 7]]}, {"hits": 0, "name": "Torpilleur", "size": 2, "cells": [[5, 4], [6, 4]]}], "shots": {"0,0": "miss", "0,6": "miss", "0,9": "miss", "1,1": "miss", "1,2": "miss", "1,3": "miss", "1,8": "miss", "2,2": "hit", "2,7": "miss", "3,1": "miss", "3,3": "miss", "4,4": "miss", "5,0": "miss", "5,9": "miss", "7,2": "miss", "7,7": "miss", "8,1": "miss", "8,4": "miss", "8,5": "miss", "8,6": "miss", "8,7": "miss", "8,8": "miss", "8,9": "miss", "9,4": "miss", "9,5": "hit", "9,6": "hit", "9,7": "hit", "9,8": "hit", "9,9": "hit"}}}	finished	f777e039-859f-4632-aaba-92ea63a64eb8	2026-08-06 14:24:43.199	2026-08-06 15:04:02.807
755e9481-5cb5-4bea-9849-956d0913abae	morpion	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	3939fc4c-1695-43de-887a-f36aa87363fb	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	{"cells": ["p2", "p1", "p2", "p2", "p1", "p1", "p1", "p2", "p1"]}	finished	draw	2026-08-06 14:46:33.795	2026-08-06 14:47:06.691
3a2a9592-a038-46b4-872b-6fcbf687f3c8	connect4	3939fc4c-1695-43de-887a-f36aa87363fb	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	3939fc4c-1695-43de-887a-f36aa87363fb	{"cells": [[null, null, null, null, null, null, null], [null, null, null, null, null, null, null], [null, null, "p2", null, "p1", null, null], [null, null, "p1", "p1", "p2", null, null], [null, null, "p1", "p2", "p1", null, null], [null, "p1", "p2", "p2", "p2", "p1", null]], "lastMove": [2, 4], "winningLine": [[2, 4], [3, 3], [4, 2], [5, 1]]}	finished	3939fc4c-1695-43de-887a-f36aa87363fb	2026-08-06 14:43:16.55	2026-08-06 14:46:12.18
8034a326-3c5f-44e2-bba0-b4a28177b92e	battleship	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	3939fc4c-1695-43de-887a-f36aa87363fb	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	{"p1": {"ready": true, "ships": [{"hits": 5, "name": "Porte-avions", "size": 5, "cells": [[0, 1], [1, 1], [2, 1], [3, 1], [4, 1]]}, {"hits": 4, "name": "Croiseur", "size": 4, "cells": [[6, 1], [6, 2], [6, 3], [6, 4]]}, {"hits": 0, "name": "Destroyer", "size": 3, "cells": [[7, 9], [8, 9], [9, 9]]}, {"hits": 0, "name": "Sous-marin", "size": 3, "cells": [[3, 9], [4, 9], [5, 9]]}, {"hits": 2, "name": "Torpilleur", "size": 2, "cells": [[0, 9], [1, 9]]}], "shots": {"0,0": "miss", "0,1": "hit", "0,2": "miss", "0,4": "miss", "0,6": "miss", "0,8": "miss", "0,9": "hit", "1,0": "miss", "1,1": "hit", "1,2": "miss", "1,4": "miss", "1,8": "miss", "1,9": "hit", "2,0": "miss", "2,1": "hit", "2,2": "miss", "2,7": "miss", "2,8": "miss", "2,9": "miss", "3,0": "miss", "3,1": "hit", "3,2": "miss", "3,3": "miss", "3,6": "miss", "4,0": "miss", "4,1": "hit", "4,2": "miss", "4,8": "miss", "5,0": "miss", "5,1": "miss", "5,2": "miss", "5,3": "miss", "5,4": "miss", "5,5": "miss", "5,7": "miss", "6,0": "miss", "6,1": "hit", "6,2": "hit", "6,3": "hit", "6,4": "hit", "6,5": "miss", "6,6": "miss", "7,0": "miss", "7,1": "miss", "7,2": "miss", "7,3": "miss", "7,4": "miss", "7,5": "miss", "7,7": "miss", "8,1": "miss", "8,8": "miss", "9,3": "miss", "9,5": "miss"}}, "p2": {"ready": true, "ships": [{"hits": 5, "name": "Porte-avions", "size": 5, "cells": [[4, 6], [5, 6], [6, 6], [7, 6], [8, 6]]}, {"hits": 4, "name": "Croiseur", "size": 4, "cells": [[1, 5], [1, 6], [1, 7], [1, 8]]}, {"hits": 3, "name": "Destroyer", "size": 3, "cells": [[3, 0], [3, 1], [3, 2]]}, {"hits": 3, "name": "Sous-marin", "size": 3, "cells": [[7, 3], [8, 3], [9, 3]]}, {"hits": 2, "name": "Torpilleur", "size": 2, "cells": [[5, 1], [6, 1]]}], "shots": {"0,0": "miss", "0,2": "miss", "0,4": "miss", "0,5": "miss", "0,6": "miss", "0,7": "miss", "0,8": "miss", "0,9": "miss", "1,1": "miss", "1,3": "miss", "1,4": "miss", "1,5": "hit", "1,6": "hit", "1,7": "hit", "1,8": "hit", "1,9": "miss", "2,0": "miss", "2,1": "miss", "2,2": "miss", "2,3": "miss", "2,4": "miss", "2,5": "miss", "2,6": "miss", "2,7": "miss", "2,8": "miss", "2,9": "miss", "3,0": "hit", "3,1": "hit", "3,2": "hit", "3,3": "miss", "3,5": "miss", "3,6": "miss", "3,7": "miss", "3,8": "miss", "4,0": "miss", "4,1": "miss", "4,2": "miss", "4,3": "miss", "4,4": "miss", "4,5": "miss", "4,6": "hit", "4,7": "miss", "5,0": "miss", "5,1": "hit", "5,2": "miss", "5,5": "miss", "5,6": "hit", "5,7": "miss", "5,8": "miss", "6,0": "miss", "6,1": "hit", "6,2": "miss", "6,3": "miss", "6,4": "miss", "6,5": "miss", "6,6": "hit", "6,7": "miss", "6,9": "miss", "7,0": "miss", "7,1": "miss", "7,2": "miss", "7,3": "hit", "7,4": "miss", "7,5": "miss", "7,6": "hit", "7,7": "miss", "8,1": "miss", "8,2": "miss", "8,3": "hit", "8,4": "miss", "8,5": "miss", "8,6": "hit", "8,7": "miss", "8,8": "miss", "9,2": "miss", "9,3": "hit", "9,4": "miss", "9,5": "miss", "9,6": "miss", "9,7": "miss"}}}	finished	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	2026-08-06 14:47:59.399	2026-08-06 14:50:52.386
bef5e457-e799-4315-9f24-6a96699f7e88	battleship	3939fc4c-1695-43de-887a-f36aa87363fb	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	3939fc4c-1695-43de-887a-f36aa87363fb	{"p1": {"ready": true, "ships": [{"hits": 5, "name": "Porte-avions", "size": 5, "cells": [[0, 0], [0, 1], [0, 2], [0, 3], [0, 4]]}, {"hits": 4, "name": "Croiseur", "size": 4, "cells": [[1, 8], [2, 8], [3, 8], [4, 8]]}, {"hits": 0, "name": "Destroyer", "size": 3, "cells": [[7, 3], [7, 4], [7, 5]]}, {"hits": 0, "name": "Sous-marin", "size": 3, "cells": [[9, 7], [9, 8], [9, 9]]}, {"hits": 0, "name": "Torpilleur", "size": 2, "cells": [[4, 3], [5, 3]]}], "shots": {"0,0": "hit", "0,1": "hit", "0,2": "hit", "0,3": "hit", "0,4": "hit", "0,5": "miss", "0,7": "miss", "0,8": "miss", "0,9": "miss", "1,0": "miss", "1,1": "miss", "1,2": "miss", "1,3": "miss", "1,4": "miss", "1,5": "miss", "1,7": "miss", "1,8": "hit", "1,9": "miss", "2,2": "miss", "2,7": "miss", "2,8": "hit", "2,9": "miss", "3,1": "miss", "3,3": "miss", "3,6": "miss", "3,7": "miss", "3,8": "hit", "3,9": "miss", "4,1": "miss", "4,4": "miss", "4,5": "miss", "4,7": "miss", "4,8": "hit", "4,9": "miss", "5,2": "miss", "5,4": "miss", "5,5": "miss", "5,7": "miss", "5,8": "miss", "5,9": "miss", "6,1": "miss", "6,3": "miss", "6,6": "miss", "7,2": "miss", "7,7": "miss", "7,9": "miss", "8,1": "miss", "8,4": "miss", "8,6": "miss", "8,8": "miss", "9,0": "miss", "9,3": "miss"}}, "p2": {"ready": true, "ships": [{"hits": 5, "name": "Porte-avions", "size": 5, "cells": [[0, 5], [0, 6], [0, 7], [0, 8], [0, 9]]}, {"hits": 4, "name": "Croiseur", "size": 4, "cells": [[9, 6], [9, 7], [9, 8], [9, 9]]}, {"hits": 3, "name": "Destroyer", "size": 3, "cells": [[2, 9], [3, 9], [4, 9]]}, {"hits": 3, "name": "Sous-marin", "size": 3, "cells": [[5, 7], [6, 7], [7, 7]]}, {"hits": 2, "name": "Torpilleur", "size": 2, "cells": [[9, 0], [9, 1]]}], "shots": {"0,0": "miss", "0,4": "miss", "0,5": "hit", "0,6": "hit", "0,7": "hit", "0,8": "hit", "0,9": "hit", "1,2": "miss", "1,4": "miss", "1,5": "miss", "1,6": "miss", "1,7": "miss", "1,8": "miss", "1,9": "miss", "2,0": "miss", "2,1": "miss", "2,4": "miss", "2,7": "miss", "2,8": "miss", "2,9": "hit", "3,0": "miss", "3,6": "miss", "3,8": "miss", "3,9": "hit", "4,3": "miss", "4,6": "miss", "4,7": "miss", "4,8": "miss", "4,9": "hit", "5,0": "miss", "5,5": "miss", "5,6": "miss", "5,7": "hit", "5,8": "miss", "5,9": "miss", "6,0": "miss", "6,2": "miss", "6,6": "miss", "6,7": "hit", "6,8": "miss", "6,9": "miss", "7,5": "miss", "7,6": "miss", "7,7": "hit", "7,8": "miss", "8,0": "miss", "8,1": "miss", "8,2": "miss", "8,4": "miss", "8,5": "miss", "8,6": "miss", "8,7": "miss", "8,8": "miss", "8,9": "miss", "9,0": "hit", "9,1": "hit", "9,2": "miss", "9,3": "miss", "9,5": "miss", "9,6": "hit", "9,7": "hit", "9,8": "hit", "9,9": "hit"}}}	finished	3939fc4c-1695-43de-887a-f36aa87363fb	2026-08-06 14:52:25.956	2026-08-06 14:56:46.728
aa7f443b-fc3f-48a8-8acc-9cca05c3aa76	morpion	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	f777e039-859f-4632-aaba-92ea63a64eb8	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	{"cells": ["p1", "p1", "p2", "p2", "p1", "p1", "p2", "p1", "p2"], "winningLine": [1, 4, 7]}	finished	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	2026-08-06 15:08:30.654	2026-08-06 15:10:12.827
60940cc6-30b0-49ad-85d1-435235910ad2	connect4	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	f777e039-859f-4632-aaba-92ea63a64eb8	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	{"cells": [[null, null, null, null, null, null, null], [null, null, null, null, null, null, null], [null, null, null, "p2", null, null, null], [null, null, "p2", "p1", "p2", null, null], ["p1", null, "p1", "p1", "p1", "p1", null], ["p2", null, "p1", "p1", "p2", "p2", "p2"]], "lastMove": [4, 5], "winningLine": [[4, 2], [4, 3], [4, 4], [4, 5]]}	finished	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	2026-08-06 15:15:00.403	2026-08-06 15:16:32.939
780b646c-d802-4ad4-a93b-c4b8eee8d242	connect4	3939fc4c-1695-43de-887a-f36aa87363fb	f777e039-859f-4632-aaba-92ea63a64eb8	3939fc4c-1695-43de-887a-f36aa87363fb	{"cells": [[null, null, null, null, null, null, null], [null, null, null, null, null, null, null], ["p1", "p2", null, "p1", null, null, null], ["p2", "p1", null, "p1", "p2", null, null], ["p2", "p1", "p1", "p2", "p1", "p2", "p2"], ["p2", "p1", "p1", "p1", "p2", "p1", "p2"]], "lastMove": [4, 2], "winningLine": [[2, 0], [3, 1], [4, 2], [5, 3]]}	finished	3939fc4c-1695-43de-887a-f36aa87363fb	2026-08-06 14:54:47.073	2026-08-06 15:14:44.58
25dd9fa5-9f25-46db-8f52-500c017a2f22	connect4	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	f777e039-859f-4632-aaba-92ea63a64eb8	f777e039-859f-4632-aaba-92ea63a64eb8	{"cells": [[null, null, null, null, null, null, null], [null, null, null, null, null, null, null], [null, null, null, "p2", null, null, null], [null, "p1", "p1", "p1", "p2", null, null], [null, "p1", "p2", "p2", "p1", "p2", null], [null, "p2", "p1", "p1", "p1", "p2", "p2"]], "lastMove": [4, 5], "winningLine": [[2, 3], [3, 4], [4, 5], [5, 6]]}	finished	f777e039-859f-4632-aaba-92ea63a64eb8	2026-08-06 15:10:45.609	2026-08-06 15:13:12.221
\.


--
-- Data for Name: OneOffExpense; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."OneOffExpense" (id, date, service, site, comment, amount, "proPlus", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Project" (id, name, site, sites, "budgetDistribution", service, brands, "projectType", status, "startDate", "endDate", "budgetPlanned", "budgetActual", description, progress, "assignedUsers", "alpineShare", "proPlus", "createdAt", "updatedAt", "nissanShare") FROM stdin;
pxt0m6c2c	DACIA STRIKER - LE PUY		{}	{}	{VN}	{Renault}	OP Clients	Active	2026-11-23 00:00:00	2026-11-24 00:00:00	0	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-07 07:53:17.167	2026-08-07 07:53:17.167	\N
h6k4gojow	VA LE PUY	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	{APV}	{Renault}	OP Clients	Active	2026-10-15 00:00:00	2026-10-15 00:00:00	1600	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-06 08:15:06.337	2026-08-06 08:15:06.337	\N
6inl5fk7a	VA VICHY	Vichy	{Vichy}	{"Vichy": 100}	{APV}	{Renault,Dacia}	OP Clients	Active	2026-11-05 00:00:00	2026-11-05 00:00:00	1600	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-06 15:22:24.899	2026-08-06 15:22:24.899	\N
993e1573-5d4a-41e7-a167-591111051248	VA Massagettes	Massagettes	{Massagettes}	{"Massagettes": 100}	{APV}	{Renault,Dacia}	OP Clients	Done	2026-05-06 00:00:00	2026-05-06 00:00:00	1200	1101.19	Repris du suivi budgétaire 2026 (MAI)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:34:28.419	2026-08-03 16:34:28.419	\N
chkbg2n0z	Afterwork Urban Padel	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	Expo/Salon	Done	2026-04-09 00:00:00	2026-04-09 00:00:00	0	0		0	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-04 14:24:32.962	2026-08-04 14:24:32.962	\N
j00la0b7t	DACIA STRIKER - VICHY	Vichy	{Vichy}	{"Vichy": 100}	{VN}	{Dacia}	OP Clients	Active	2026-11-23 00:00:00	2026-11-24 00:00:00	0	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-07 07:54:00.324	2026-08-07 07:54:00.324	\N
f0e2640b-83b5-4ba7-a958-03ff109a148d	partenariat Stade Aurillacois	Aurillac	{Aurillac}	{"Aurillac": 100}	{APV,PR,VN,VO}	{Renault,Dacia}	Partenariat	Done	2026-07-01 00:00:00	2027-06-30 00:00:00	22600	22600	Repris du suivi budgétaire 2026 (JUILLET)	100	{de9c517b-0c41-4b81-9c34-87fde2f4f4d8,b91965d9-5dfe-4b54-8306-7a3ca846c53d,46dcf78a-a158-4a4a-a064-52a843ddb935,f777e039-859f-4632-aaba-92ea63a64eb8}	\N	f	2026-08-03 16:33:01.195	2026-08-03 16:33:01.195	\N
b17abf10-2b43-4361-ba9d-04c6d1de8aba	Projet : convention agent groupe	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.073803, "Mende": 2.640886, "Mozac": 5.103618, "Rodez": 10.254395, "Ussel": 2.551809, "Vichy": 7.749745, "Figeac": 3.180591, "Millau": 2.478451, "Ricoux": 4.65823, "Gaillac": 4.951662, "Issoire": 5.784799, "Moulins": 5.098379, "Aurillac": 7.424873, "Clermont": 22.65451, "Massagettes": 1.598155, "Le Puy-en-Velay": 6.796091}	{PR,VN}	{Renault}	Collaborateurs	Done	2026-03-01 00:00:00	2026-03-01 00:00:00	19084.5	19084.5	Repris du suivi budgétaire 2026 (MARS)	100	{}	\N	f	2026-08-03 16:33:02.122	2026-08-03 16:33:02.122	\N
17c89861-c6a1-4a8e-b8c5-aaba0d171de3	Projet : lancement Twingo Clermont	Clermont, Massagettes	{Clermont,Massagettes}	{"Clermont": 97.910555, "Massagettes": 2.089445}	{VN}	{Renault}	OP Clients	Done	2026-03-01 00:00:00	2026-04-01 00:00:00	16139.69	16139.69	Repris du suivi budgétaire 2026 (MARS, AVRIL)	100	{}	\N	f	2026-08-03 16:33:03.11	2026-08-03 16:33:03.11	\N
33681685-a4d2-419e-96a0-23752309e68b	partenariat RAF	Rodez	{Rodez}	{"Rodez": 100}	{APV,PR,VN,VO}	{Renault,Dacia}	Partenariat	Done	2026-07-01 00:00:00	2026-07-01 00:00:00	14400	14400	Repris du suivi budgétaire 2026 (JUILLET)	100	{de9c517b-0c41-4b81-9c34-87fde2f4f4d8,b91965d9-5dfe-4b54-8306-7a3ca846c53d,46dcf78a-a158-4a4a-a064-52a843ddb935,f777e039-859f-4632-aaba-92ea63a64eb8}	\N	f	2026-08-03 16:33:10.159	2026-08-03 16:33:10.159	\N
2f8ebecd-5485-44ec-9707-38fb2e3a6cc8	projet : Renew Days clermont	Clermont	{Clermont}	{"Clermont": 100}	{VO}	{Renault}	OP Clients	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	6884.99	6884.99	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:33:16.369	2026-08-03 16:33:16.369	\N
1a20b26c-1a9a-45bf-8d76-57bea4fc0bc3	partenariat GT4 Servol	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	Partenariat	Done	2026-01-01 00:00:00	2026-01-01 00:00:00	8000	8000	Repris du suivi budgétaire 2026 (JUIN)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:33:12.338	2026-08-03 16:33:12.338	\N
33f8898b-5476-4fa2-9fce-1ef80c113cf5	portrait collaborateur	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.285714, "Mende": 2.285714, "Mozac": 4.571429, "Rodez": 7.428572, "Ussel": 2.285714, "Vichy": 6.857143, "Figeac": 2.285714, "Lavaur": 0.571429, "Millau": 2.285714, "Ricoux": 4, "Carmaux": 1.714285, "Gaillac": 3.428572, "Issoire": 5.142857, "Moulins": 5.142857, "Aurillac": 6.285714, "Clermont": 29.714285, "Massagettes": 1.714285, "Villefranche": 1.714285, "Le Puy-en-Velay": 6.285714}	{APV,PR,VN,VO}	{Nissan,Renault}	Collaborateurs	Done	2026-03-01 00:00:00	2026-03-01 00:00:00	700	700	Repris du suivi budgétaire 2026 (MARS)	100	{}	\N	f	2026-08-03 16:34:09.263	2026-08-03 16:34:09.263	\N
f208024e-4153-4b0b-8a2e-6a1bcc9e2434	partenariat GT4 AURIACOMBE	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	Partenariat	Done	2026-01-01 00:00:00	2026-01-01 00:00:00	15000	15000	Repris du suivi budgétaire 2026 (MARS)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:33:08.035	2026-08-03 16:33:08.035	\N
50ad50ad-9bb4-4c8b-99cc-3501bf19e2eb	projet : renew days rodez	Rodez	{Rodez}	{"Rodez": 100}	{VO}	{Renault}	OP Clients	Done	2026-07-01 00:00:00	2026-07-01 00:00:00	5331.88	5331.88	Repris du suivi budgétaire 2026 (JUILLET)	100	{}	\N	f	2026-08-03 16:33:22.491	2026-08-03 16:33:22.491	\N
prqp8174t	GT4 MANCHE NOGARO	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-04-05 00:00:00	2026-04-06 00:00:00	0	0		0	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-04 14:36:41.406	2026-08-04 14:36:41.406	\N
0b2a369e-7cc6-46f1-bca2-a6a1d19ea06d	CCDMD 2026	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Active	2026-08-07 00:00:00	2026-08-09 00:00:00	2500	5308	Repris du suivi budgétaire 2026 (FEVRIER, AOUT)	67	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:33:20.41	2026-08-03 16:33:20.41	\N
19a3a414-b49e-4eeb-ac75-56693cdb9a75	Visite Dieppe 2026	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-04-21 00:00:00	2026-04-22 00:00:00	6000	5626	Repris du suivi budgétaire 2026 (FEVRIER, MARS, AVRIL, MAI)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:33:15.344	2026-08-03 16:33:15.344	\N
5e3a27e8-4a25-44eb-a842-dd493561f5ac	Projet : lancement twingo mozac	Mozac	{Mozac}	{"Mozac": 100}	{VN}	{Renault}	OP Clients	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	3923.63	3923.63	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:33:27.33	2026-08-03 16:33:27.33	\N
70cdcf76-2539-4c09-83cc-fb770adabb12	projet : relance tel opo juin EAA	Clermont, Massagettes, Mozac, Ussel	{Clermont,Massagettes,Mozac,Ussel}	{"Mozac": 19.800835, "Ussel": 11.923861, "Clermont": 60.470595, "Massagettes": 7.804709}	{VN}	{Renault}	OP Clients	Done	2026-06-01 00:00:00	2026-06-01 00:00:00	1383.78	1383.78	Repris du suivi budgétaire 2026 (JUIN)	100	{}	\N	f	2026-08-03 16:33:48.51	2026-08-03 16:33:48.51	\N
8a461f9a-baa6-4f84-8c14-c4a780bf3ab6	projet : lancement twingo issoire	Issoire	{Issoire}	{"Issoire": 100}	{VN}	{Renault}	OP Clients	Done	2026-03-01 00:00:00	2026-04-01 00:00:00	6480	6480	Repris du suivi budgétaire 2026 (MARS, AVRIL)	100	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-03 16:33:17.323	2026-08-03 16:33:17.323	\N
d57b7e67-f17f-48bf-9031-a4d4f73a6df7	lancement Clio Thiers	Ricoux	{Ricoux}	{"Ricoux": 100}	{VN}	{Renault}	OP Clients	Done	2026-01-14 00:00:00	2026-01-14 00:00:00	1801.52	1801.52	Repris du suivi budgétaire 2026 (JANVIER)	100	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-03 16:33:41.757	2026-08-03 16:33:41.757	\N
b4f54a23-b9fa-4970-9f86-362161061bb5	lancement clio mende	Mende	{Mende}	{"Mende": 100}	{VN}	{Renault}	OP Clients	Done	2026-01-14 00:00:00	2026-01-14 00:00:00	1500	1327.08	Repris du suivi budgétaire 2026 (JANVIER)	100	{}	\N	f	2026-08-03 16:33:49.457	2026-08-03 16:33:49.457	\N
b21b4f77-e45c-4d68-9dc9-cde53ddcb770	lancement clio issoire	Issoire	{Issoire}	{"Issoire": 100}	{VN}	{Renault}	OP Clients	Done	2026-01-14 00:00:00	2026-01-14 00:00:00	3500	3645.45	Repris du suivi budgétaire 2026 (JANVIER)	100	{}	\N	f	2026-08-03 16:33:29.307	2026-08-03 16:33:29.307	\N
de126b35-0186-4948-9237-e0fcda3049ed	VA Mozac	Mozac	{Mozac}	{"Mozac": 100}	{APV}	{Renault,Dacia}	OP Clients	Done	2026-03-19 00:00:00	2026-03-19 00:00:00	1500	2159.47	Repris du suivi budgétaire 2026 (MARS)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:33:24.489	2026-08-03 16:33:24.489	\N
17ea8c77-9f87-405f-80b3-7c6833f46b63	Track Day Mornay	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-04-10 00:00:00	2026-04-10 00:00:00	8000	1036	Repris du suivi budgétaire 2026 (FEVRIER, MARS, AVRIL)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:33:14.356	2026-08-03 16:33:14.356	\N
4bc22e4c-ee7a-4348-b29b-764695a8f6ca	partenariat Trail NBZ	Massagettes	{Massagettes}	{"Massagettes": 100}	{VN}	{Renault}	Partenariat	Done	2026-02-01 00:00:00	2026-02-01 00:00:00	800	800	Repris du suivi budgétaire 2026 (FEVRIER)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:33:51.355	2026-08-03 16:33:51.355	\N
5acbf744-5bed-470c-95e9-94404c98ab7b	Ventes Privées Clermont Juillet	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault,Dacia}	Animation Co	Done	2026-07-01 00:00:00	2026-07-01 00:00:00	500	297	Repris du suivi budgétaire 2026 (JUILLET)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:34:31.462	2026-08-03 16:34:31.462	\N
cp06bw9xn	VP MOULINS	Moulins	{Moulins}	{"Moulins": 100}	{VN,VO}	{Renault}	Animation Co	Active	2026-11-04 00:00:00	2026-11-06 00:00:00	0	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-06 15:26:10.51	2026-08-06 15:26:10.51	\N
aae8f445-bd7b-4de5-9851-6c12de1c5b6c	projet : lancement twingo le puy	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	{VN}	{Renault}	OP Clients	Done	2026-03-01 00:00:00	2026-04-01 00:00:00	3941	3941	Repris du suivi budgétaire 2026 (MARS, AVRIL)	100	{}	\N	f	2026-08-03 16:33:26.411	2026-08-03 16:33:26.411	\N
cca1228b-7c4c-436b-8f8c-af4215da5386	Projet : Video Twingo Groupe	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.039911, "Mende": 2.660754, "Mozac": 5.099778, "Rodez": 10.254989, "Ussel": 2.549889, "Vichy": 7.760532, "Figeac": 3.27051, "Millau": 2.494457, "Ricoux": 4.656319, "Gaillac": 4.933481, "Issoire": 5.764967, "Moulins": 5.099778, "Aurillac": 7.427938, "Clermont": 22.616408, "Massagettes": 1.607539, "Le Puy-en-Velay": 6.762749}	{VN}	{Renault}	Contenu	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	1804	1804	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:33:40.781	2026-08-03 16:33:40.781	\N
3a836748-4feb-4366-9c5b-65116623f238	relance téléphonique Bony Historique	Clermont, Issoire, Le Puy-en-Velay, Massagettes, Mende, Moulins, Mozac, Ricoux, Ussel, Vichy	{Clermont,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Moulins,Mozac,Ricoux,Ussel,Vichy}	{"Mende": 3.998988, "Mozac": 7.846115, "Ussel": 3.923058, "Vichy": 11.996963, "Ricoux": 7.010884, "Issoire": 8.985067, "Moulins": 7.997975, "Clermont": 34.801316, "Massagettes": 2.429765, "Le Puy-en-Velay": 11.009871}	{VN}	{Renault,Dacia}	Animation Co	Done	2026-03-10 00:00:00	2026-03-10 00:00:00	4500	3951	Repris du suivi budgétaire 2026 (FEVRIER, MARS)	100	{}	\N	f	2026-08-03 16:33:25.472	2026-08-03 16:33:25.472	\N
03d5f0ec-7777-495d-ad56-0b390e086ccf	RMC 2026	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-03-20 00:00:00	2026-03-20 00:00:00	2500	-2102	Repris du suivi budgétaire 2026 (FEVRIER, MARS)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:33:34.988	2026-08-03 16:33:34.988	\N
13f4bfee-730b-4e61-92be-3b1371c3c2c1	projet : lancement twingo vichy	Vichy	{Vichy}	{"Vichy": 100}	{VN}	{Renault}	OP Clients	Done	2026-03-01 00:00:00	2026-03-01 00:00:00	4947	4947	Repris du suivi budgétaire 2026 (MARS)	100	{}	\N	f	2026-08-03 16:33:23.462	2026-08-03 16:33:23.462	\N
127e0ad8-55fd-43b6-b864-a3fafa0e6e74	blue expérience x l'en but	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Active	2026-09-14 00:00:00	2026-10-14 00:00:00	3888	3888	Repris du suivi budgétaire 2026 (JUIN, JUILLET, AOUT)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:33:28.326	2026-08-03 16:33:28.326	\N
8acedb50-b681-4060-9ddb-4ee498af7d92	projet : salon auto de vichy	Clermont, Vichy	{Clermont,Vichy}	{"Vichy": 50, "Clermont": 50}	{VN}	{Nissan,Renault}	Expo/Salon	Active	2026-11-01 00:00:00	2026-11-01 00:00:00	2700	2700	Repris du suivi budgétaire 2026 (NOVEMBRE)	100	{}	\N	f	2026-08-03 16:33:37.984	2026-08-04 11:42:42.634	\N
9a6bbb91-a492-4d61-99aa-d66d00113991	VA Clermont Septembre	Clermont	{Clermont}	{"Clermont": 100}	{APV}	{Renault,Dacia}	OP Clients	Active	2026-09-03 00:00:00	2026-09-03 00:00:00	1724	1724	Repris du suivi budgétaire 2026 (SEPTEMBRE)	13	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:33:43.682	2026-08-03 16:33:43.682	\N
51598212-99f9-426c-9f5b-e889bf4c894f	relance VN Avril Twingo	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault}	Animation Co	Done	2026-04-07 00:00:00	2026-04-07 00:00:00	500	419.6	Repris du suivi budgétaire 2026 (AVRIL)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:34:20.674	2026-08-03 16:34:20.674	\N
84811883-f115-4dad-923f-18de211f57c4	expo alpine handigolf	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	Partenariat	Done	2026-06-06 00:00:00	2026-06-06 00:00:00	800	800	Repris du suivi budgétaire 2026 (JUIN)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:34:02.387	2026-08-03 16:34:02.387	\N
yv84rs9gz	VP VICHY	Vichy	{Vichy}	{"Vichy": 100}	{VN,VO}	{Renault,Dacia}	Animation Co	Active	2026-11-23 00:00:00	2026-11-25 00:00:00	0	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-06 15:26:48.787	2026-08-06 15:26:48.787	\N
abd31f5f-d89e-4c23-8b55-4df4cad76793	partenariat dome sancy foot	Massagettes	{Massagettes}	{"Massagettes": 100}	{VN}	{Renault,Dacia}	Partenariat	Active	2026-01-01 00:00:00	2026-01-01 00:00:00	2500	2500	Repris du suivi budgétaire 2026 (JANVIER)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:33:38.911	2026-08-03 16:33:38.911	\N
456be7ec-934b-4a01-8b57-4cf6632578e2	projet : pro+ circuit albi	Albi	{Albi}	{"Albi": 100}	{VN}	{Renault}	OP Clients	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	2752.5	2752.5	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:33:37.045	2026-08-03 16:33:37.045	\N
1849dd57-122a-487e-bab2-e432276a347c	Projet : lancement twingo massagettes	Clermont, Massagettes	{Clermont,Massagettes}	{"Clermont": 43.245558, "Massagettes": 56.754442}	{VN}	{Renault}	OP Clients	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	1622.71	1622.71	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:33:44.644	2026-08-03 16:33:44.644	\N
d0ccde38-7359-46c6-a2e6-5a7b8671e17f	projet : lancement twingo thiers	Ricoux	{Ricoux}	{"Ricoux": 100}	{VN}	{Renault}	OP Clients	Done	2026-04-08 00:00:00	2026-04-08 00:00:00	3522	3522	Repris du suivi budgétaire 2026 (MARS)	100	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-03 16:33:34.061	2026-08-03 16:33:34.061	\N
b52de86d-d662-4422-9aef-8d90c371666c	projet : soirée découverte brioude	Issoire	{Issoire}	{"Issoire": 100}	{VN}	{Renault,Dacia}	OP Clients	Done	2026-07-02 00:00:00	2026-07-02 00:00:00	1500	1500	Repris du suivi budgétaire 2026 (JUIN)	100	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-03 16:33:46.545	2026-08-03 16:33:46.545	\N
3d3f614d-4f8d-4749-a6d6-b4d50681de1c	galette clermont	Clermont	{Clermont}	{"Clermont": 100}	{"Tous Services"}	{Renault,Dacia}	Collaborateurs	Done	2026-01-22 00:00:00	2026-01-22 00:00:00	3000	3627.99	Repris du suivi budgétaire 2026 (JANVIER)	100	{3939fc4c-1695-43de-887a-f36aa87363fb,15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:33:30.278	2026-08-03 16:33:30.278	\N
2du8uofbb	BLUE TOUR RODEZ	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-06-19 00:00:00	2026-06-20 00:00:00	0	0		0	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-04 15:26:30.173	2026-08-04 15:26:30.173	\N
g7el0wb3r	Rallye BONY X CMV	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault}	OP Clients	Active	2026-09-27 00:00:00	2026-09-27 00:00:00	0	0		19	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-06 12:50:08.63	2026-08-06 12:50:08.63	\N
e085c0ap2	VP THIERS	Thiers	{Thiers}	{"Thiers": 100}	{VN,VO}	{Renault,Dacia}	OP Clients	Active	2026-12-07 00:00:00	2026-12-09 00:00:00	0	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-06 15:27:21.768	2026-08-06 15:27:21.768	\N
b16banc0f	VP LE PUY	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault}	OP Clients	Draft	2026-08-06 00:00:00	2026-08-06 00:00:00	0	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-06 15:27:52.585	2026-08-06 15:27:52.585	\N
c7a17964-5761-4d4d-b97a-454b0e2f9d3c	Projet : Partenariat F'estivada	Rodez	{Rodez}	{"Rodez": 100}	{VN}	{Renault}	Partenariat	Done	2026-05-01 00:00:00	2026-05-01 00:00:00	1900	1900	Repris du suivi budgétaire 2026 (MAI)	100	{}	\N	f	2026-08-03 16:33:39.805	2026-08-03 16:33:39.805	\N
dd6d8693-ee68-4600-8bae-b469620de10e	Projet : relance téléphonique BSO	Albi, Aurillac, Carmaux, Figeac, Gaillac, Lavaur, Millau, Rodez, Villefranche	{Albi,Aurillac,Carmaux,Figeac,Gaillac,Lavaur,Millau,Rodez,Villefranche}	{"Albi": 18.982768, "Rodez": 23.985548, "Figeac": 8.004447, "Lavaur": 2.001112, "Millau": 7.003891, "Carmaux": 5.030572, "Gaillac": 11.006115, "Aurillac": 18.982768, "Villefranche": 5.002779}	{VN}	{Renault,Dacia}	OP Clients	Done	2026-03-10 00:00:00	2026-03-10 00:00:00	3598	1800	Repris du suivi budgétaire 2026 (FEVRIER)	100	{}	\N	f	2026-08-03 16:33:32.132	2026-08-03 16:33:32.132	\N
3a5ab6d2-44b1-47fe-8fd6-0f4c922d11a8	projet : visite ateliers Moulins	Moulins	{Moulins}	{"Moulins": 100}	{APV}	{Renault}	OP Clients	Done	2026-06-11 00:00:00	2026-06-11 00:00:00	417	417	Repris du suivi budgétaire 2026 (JUIN)	100	{}	\N	f	2026-08-03 16:34:21.561	2026-08-03 16:34:21.561	\N
66648793-1458-43fe-a40d-e552e974048d	lancement clio clermont	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault}	OP Clients	Done	2026-01-14 00:00:00	2026-01-14 00:00:00	20000	24319.48	Repris du suivi budgétaire 2026 (JANVIER)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:33:00.232	2026-08-03 16:33:00.232	\N
a1532a06-1dec-4fb4-ba9c-03e73f5fc3ee	lancement clio vichy	Vichy	{Vichy}	{"Vichy": 100}	{VN}	{Renault}	OP Clients	Done	2026-01-15 00:00:00	2026-01-15 00:00:00	4000	3595.29	Repris du suivi budgétaire 2026 (JANVIER)	100	{}	\N	f	2026-08-03 16:33:33.162	2026-08-03 16:33:33.162	\N
c88b2d33-b0b7-4ff8-abea-9f816d6c52a2	La Foulée des 2 Roches	Massagettes	{Massagettes}	{"Massagettes": 100}	{VN}	{Renault}	Partenariat	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	800	800	Repris du suivi budgétaire 2026 (AVRIL)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:34:01.311	2026-08-03 16:34:01.311	\N
du1hkirq6	VP LE PUY	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	{VN,VO}	{Renault,Dacia}	Animation Co	Active	2026-12-14 00:00:00	2026-12-16 00:00:00	0	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-06 15:29:52.586	2026-08-06 15:29:52.586	\N
9e484187-b435-4cd3-b621-b1615a45c6e9	projet : partenariat Course des filles le Puy	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	{VN}	{Renault}	Expo/Salon	Active	2026-09-01 00:00:00	2026-09-01 00:00:00	800	800	Repris du suivi budgétaire 2026 (SEPTEMBRE)	75	{}	\N	f	2026-08-03 16:34:05.402	2026-08-03 16:34:05.402	\N
e2d844eb-2aaa-4909-bdfc-56aac09e4768	Projet : Minute de l'auto Juillet	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.081081, "Mende": 2.477477, "Mozac": 4.72973, "Rodez": 7.657658, "Ussel": 2.252253, "Vichy": 6.981982, "Figeac": 2.477477, "Lavaur": 0.675675, "Millau": 2.252253, "Ricoux": 4.054054, "Carmaux": 1.576576, "Gaillac": 3.603604, "Issoire": 4.954955, "Moulins": 4.954955, "Aurillac": 6.081081, "Clermont": 29.72973, "Massagettes": 1.351352, "Villefranche": 1.576576, "Le Puy-en-Velay": 6.531532}	{APV,PR,VN,VO}	{Nissan,Renault}	OP Clients	Done	2026-07-01 00:00:00	2026-07-01 00:00:00	1776	1776	Repris du suivi budgétaire 2026 (JUILLET)	100	{}	\N	f	2026-08-03 16:33:42.676	2026-08-03 16:33:42.676	\N
43ed55e2-d0b1-42c3-939b-556542169f40	vidéo Clio groupe	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.066667, "Mende": 2.666667, "Mozac": 5.133333, "Rodez": 10.266667, "Ussel": 2.533333, "Vichy": 7.733333, "Figeac": 3.2, "Millau": 2.466667, "Ricoux": 4.666667, "Gaillac": 4.933333, "Issoire": 5.8, "Moulins": 5.066667, "Aurillac": 7.4, "Clermont": 22.666667, "Massagettes": 1.6, "Le Puy-en-Velay": 6.8}	{VN}	{Renault}	Contenu	Done	2026-01-06 00:00:00	2026-01-07 00:00:00	1500	1500	Repris du suivi budgétaire 2026 (JANVIER)	100	{}	\N	f	2026-08-03 16:33:45.585	2026-08-03 16:33:45.585	\N
037552b9-cfeb-4600-927c-9dba9a939059	lancement Clio BSO	Albi, Aurillac, Figeac, Gaillac, Millau, Rodez, Villefranche	{Albi,Aurillac,Figeac,Gaillac,Millau,Rodez,Villefranche}	{"Albi": 16.299064, "Rodez": 16.465936, "Figeac": 10.882971, "Millau": 2.931147, "Gaillac": 12.076471, "Aurillac": 38.616411, "Villefranche": 2.727998}	{VN}	{Renault}	OP Clients	Done	2026-01-14 00:00:00	2026-01-15 00:00:00	25000	27566	Repris du suivi budgétaire 2026 (JANVIER)	100	{de9c517b-0c41-4b81-9c34-87fde2f4f4d8}	\N	f	2026-08-03 16:32:59.269	2026-08-03 16:32:59.269	\N
or83seebd	CAMPAGNE SMS CT 39€ ISSOIRE	Issoire	{Issoire}	{"Issoire": 100}	{APV}	{Renault,Dacia}	Animation Co	Active	2026-05-01 00:00:00	2026-12-31 00:00:00	50	18.315	Le code de facturation : CT39-ISS\n\n[OFFRE] Profitez du controle technique à 39€* chez Bony auto-mobile Issoire ! *Conditions et RDV sur https://bs.ms/KJjE \n	57	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-07 08:31:48.977	2026-08-07 08:31:48.977	\N
c946ade5-8cdb-4b4e-9a1d-3886e7b076fb	soirée CMV	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault,Dacia}	OP Clients	Done	2026-02-26 00:00:00	2026-02-26 00:00:00	1000	1075	Repris du suivi budgétaire 2026 (FEVRIER)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c,3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:33:53.08	2026-08-03 16:33:53.08	\N
f450695f-3597-499b-b143-29076955115f	projet : corporace 2026	Clermont, Le Puy-en-Velay	{Clermont,"Le Puy-en-Velay"}	{"Clermont": 62.616822, "Le Puy-en-Velay": 37.383178}	{APV,PR,VN,VO}	{Nissan,Renault}	OP Clients	Done	2026-04-01 00:00:00	2026-05-01 00:00:00	1070	1070	Repris du suivi budgétaire 2026 (AVRIL, MAI)	100	{}	\N	f	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275	\N
67f8970c-d0f0-463e-8f27-758d35596a65	Projet : Comité Novotel	Albi, Aurillac, Clermont, Figeac, Gaillac, Issoire, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy	{Albi,Aurillac,Clermont,Figeac,Gaillac,Issoire,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy}	{"Albi": 7.079646, "Mende": 2.654867, "Mozac": 5.309735, "Rodez": 10.176991, "Ussel": 2.212389, "Vichy": 7.964602, "Figeac": 3.097345, "Millau": 2.212389, "Ricoux": 5.309735, "Gaillac": 5.309735, "Issoire": 5.752212, "Moulins": 5.309735, "Aurillac": 7.079646, "Clermont": 22.566372, "Massagettes": 1.327434, "Le Puy-en-Velay": 6.637168}	{APV,PR,VN,VO}	{Renault}	OP Clients	Done	2026-03-01 00:00:00	2026-03-01 00:00:00	904	904	Repris du suivi budgétaire 2026 (MARS)	100	{}	\N	f	2026-08-03 16:33:57.499	2026-08-03 16:33:57.499	\N
fe178409-a2bc-407c-86d5-a6f0a79eb398	projet : salon/expo VUVP figeac	Figeac	{Figeac}	{"Figeac": 100}	{VN}	{Renault}	Expo/Salon	Done	2026-06-01 00:00:00	2026-06-01 00:00:00	800	800	Repris du suivi budgétaire 2026 (JUIN)	100	{}	\N	f	2026-08-03 16:34:04.473	2026-08-03 16:34:04.473	\N
3cdec894-492a-403c-bf4b-464feaad11d7	Projet : Portrait collaborateurs avril	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.179775, "Mende": 2.247191, "Mozac": 4.494382, "Rodez": 7.30337, "Ussel": 2.247191, "Vichy": 6.741573, "Figeac": 2.247191, "Lavaur": 0.561798, "Millau": 2.247191, "Ricoux": 3.932585, "Carmaux": 3.370787, "Gaillac": 3.370787, "Issoire": 5.05618, "Moulins": 5.05618, "Aurillac": 6.179775, "Clermont": 29.213483, "Massagettes": 1.685393, "Villefranche": 1.685393, "Le Puy-en-Velay": 6.179775}	{APV,PR,VN,VO}	{Nissan,Renault}	Collaborateurs	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	712	712	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:34:08.281	2026-08-03 16:34:08.281	\N
4509847b-abd8-4cd3-93d1-652108997894	EXPO ALPINE 15km du Puy	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	{VN}	{Renault,Alpine}	Partenariat	Done	2026-05-03 00:00:00	2026-05-03 00:00:00	750	750	Repris du suivi budgétaire 2026 (MARS)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	50	f	2026-08-03 16:34:06.376	2026-08-03 16:34:06.376	\N
022baac0-9fa5-40cc-afa5-abeb83d56bfe	projet : portrait collaborateurs	Albi, Aurillac, Carmaux, Clermont, Figeac, Gaillac, Issoire, Lavaur, Le Puy-en-Velay, Massagettes, Mende, Millau, Moulins, Mozac, Ricoux, Rodez, Ussel, Vichy, Villefranche	{Albi,Aurillac,Carmaux,Clermont,Figeac,Gaillac,Issoire,Lavaur,"Le Puy-en-Velay",Massagettes,Mende,Millau,Moulins,Mozac,Ricoux,Rodez,Ussel,Vichy,Villefranche}	{"Albi": 6.285714, "Mende": 2.285714, "Mozac": 4.571429, "Rodez": 7.428572, "Ussel": 2.285714, "Vichy": 6.857143, "Figeac": 2.285714, "Lavaur": 0.571429, "Millau": 2.285714, "Ricoux": 4, "Carmaux": 1.714285, "Gaillac": 3.428572, "Issoire": 5.142857, "Moulins": 5.142857, "Aurillac": 6.285714, "Clermont": 29.714285, "Massagettes": 1.714285, "Villefranche": 1.714285, "Le Puy-en-Velay": 6.285714}	{APV,PR,VN,VO}	{Nissan,Renault}	Collaborateurs	Done	2026-07-01 00:00:00	2026-07-01 00:00:00	700	700	Repris du suivi budgétaire 2026 (JUILLET)	100	{}	\N	f	2026-08-03 16:34:10.211	2026-08-03 16:34:10.211	\N
b604db18-b2ee-4fd2-a0fd-85ae7b8c8d0c	Projet : partenariat : RAF	Rodez	{Rodez}	{"Rodez": 100}	{VN}	{Renault}	Partenariat	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	375.36	375.36	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:34:22.461	2026-08-03 16:34:22.461	\N
1732ebbb-ac65-4620-8e30-4b53bdecc4b4	BLUE NIGHT alpine a390	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-01-15 00:00:00	2026-01-15 00:00:00	35000	36106	Repris du suivi budgétaire 2026 (JANVIER)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:32:58.291	2026-08-03 16:32:58.291	\N
8a4eabb6-fbb1-4982-b8aa-bd85e0f3635f	projet : partenariat ferrarissimo issoire	Issoire	{Issoire}	{"Issoire": 100}	{VN}	{Renault}	Partenariat	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	600	600	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:34:14.037	2026-08-03 16:34:14.037	\N
df6d498c-d612-4082-abcf-71a8ad0ccbfd	projet : partenariat JAV vichy	Vichy	{Vichy}	{"Vichy": 100}	{VN}	{Renault}	Partenariat	Done	2026-09-01 00:00:00	2029-06-30 00:00:00	18488	18488	Repris du suivi budgétaire 2026 (JUIN)\nPartenariat sur 3 ans du 01/09/2026 au 30/06/2026 \n\nDétails : \n4 places avec accès parking partenaires + siège nominatif en tribune A + accès salon avant match - mi temp	100	{}	\N	f	2026-08-03 16:33:18.291	2026-08-03 16:33:18.291	\N
93766725-f403-4440-bd29-f8557993d11b	journée phoning Clermont février	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault,Dacia}	Animation Co	Done	2026-02-05 00:00:00	2026-02-05 00:00:00	500	610.52	Repris du suivi budgétaire 2026 (FEVRIER)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c,3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:34:13.113	2026-08-03 16:34:13.113	\N
7cae9a99-13dd-4677-909c-bc00abb07a9c	corporace 2026	Clermont	{Clermont}	{"Clermont": 100}	{"Tous Services"}	{Renault,Nissan}	OP Clients	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	1500	1304	Repris du suivi budgétaire 2026 (AVRIL)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c,3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:34:24.454	2026-08-03 16:34:24.454	\N
a9580e52-43d2-4982-84d4-e498d4ea5908	track day mas du clos	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Active	2026-09-25 00:00:00	2026-09-25 00:00:00	6000	1050	Repris du suivi budgétaire 2026 (MAI)	86	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:33:19.288	2026-08-03 16:33:19.288	\N
6a49bba9-b85e-418d-b266-df0104c8b92b	soirée alpine depailler	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-05-28 00:00:00	2026-05-28 00:00:00	668	668	Repris du suivi budgétaire 2026 (MAI)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:34:11.227	2026-08-03 16:34:11.227	\N
947e5aad-42e3-4e1f-acc9-66c8f2221d9d	projet : expo vn ceyrat	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault}	Expo/Salon	Done	2026-05-01 00:00:00	2026-05-01 00:00:00	500	500	Repris du suivi budgétaire 2026 (MAI)	100	{}	\N	f	2026-08-03 16:34:15.893	2026-08-03 16:34:15.893	\N
72844ee8-9259-499a-aa04-889f8de82bc4	Assemblée Réflexe Brézet	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-03-23 00:00:00	2026-03-23 00:00:00	150	133	Repris du suivi budgétaire 2026 (FEVRIER)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:34:54.694	2026-08-03 16:34:54.694	\N
qz1og9akw	SPORT & COLLECTION MDC	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Active	2026-09-05 00:00:00	2026-09-05 00:00:00	0	0		50	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-06 07:12:31.716	2026-08-06 07:12:31.716	\N
e992194c-3502-4f01-ad35-6ab05bc3c05e	Salon Aveyr'auto	Villefranche	{Villefranche}	{"Villefranche": 100}	{VN}	{Renault,Dacia}	Expo/Salon	Active	2026-09-26 00:00:00	2026-09-27 00:00:00	900	900	Repris du suivi budgétaire 2026 (SEPTEMBRE)	100	{de9c517b-0c41-4b81-9c34-87fde2f4f4d8}	\N	f	2026-08-03 16:33:59.301	2026-08-03 16:33:59.301	\N
a9c8a863-0fe5-4f7d-abad-58124a8c7aa7	relance tel clio - Clf	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault}	Animation Co	Done	2026-01-13 00:00:00	2026-01-13 00:00:00	615.6	615.6	Repris du suivi budgétaire 2026 (JANVIER)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:34:12.143	2026-08-03 16:34:12.143	\N
a4655aea-4793-4946-ba6a-5aa266bbbad5	expo ALPINE Malintrat	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	Expo/Salon	Active	2026-10-18 00:00:00	2026-11-18 00:00:00	500	500	Repris du suivi budgétaire 2026 (JUILLET)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:34:16.825	2026-08-03 16:34:16.825	\N
4axlcln2x	SOIREE ASM EN MELEE	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault}	OP Clients	Active	2026-08-06 00:00:00	2026-08-06 00:00:00	0	0		0	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-06 07:13:45.626	2026-08-06 07:13:45.626	\N
l2t8lq4w0	SOIREE ASM EN MELEE	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Active	2026-10-15 00:00:00	2026-10-15 00:00:00	0	0		25	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-06 07:14:53.512	2026-08-06 07:14:53.512	\N
1d5c5797-5bca-4161-9231-a0c99b59cbe9	A290 Road Trip	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-04-04 00:00:00	2026-04-04 00:00:00	3000	492	Repris du suivi budgétaire 2026 (FEVRIER, MARS, AVRIL)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:33:35.974	2026-08-03 16:33:35.974	\N
tlquwi84i	VP ISSOIRE	Issoire	{Issoire}	{"Issoire": 100}	{VN,VO}	{Renault,Dacia}	Animation Co	Active	2026-10-26 00:00:00	2026-10-28 00:00:00	0	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-06 15:20:49.459	2026-08-06 15:20:49.459	\N
a4f70142-e786-4bb7-ad03-8f2c413bdc4e	BLUE DAYS JANVIER	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	Animation Co	Done	2026-01-08 00:00:00	2026-01-12 00:00:00	361	361	Repris du suivi budgétaire 2026 (JANVIER)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:34:23.55	2026-08-03 16:34:23.55	\N
5119bd87-8d3a-493e-992d-74ab4ca208ba	Plancement clio le puy	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	{VN}	{Renault}	OP Clients	Done	2026-01-15 00:00:00	2026-01-15 00:00:00	483.33	483.33	Repris du suivi budgétaire 2026 (JANVIER)	100	{}	\N	f	2026-08-03 16:34:17.776	2026-08-03 16:34:17.776	\N
4aly4336l	VA THIERS	Thiers	{Thiers}	{"Thiers": 100}	{APV}	{Renault}	OP Clients	Active	2026-11-19 00:00:00	2026-11-19 00:00:00	1200	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-06 13:08:38.746	2026-08-06 13:08:38.746	\N
f97ce65e-d511-4327-b5ab-5752c16189b0	Projet : partenariat Rugby 13	Albi	{Albi}	{"Albi": 100}	{VN}	{Renault}	Partenariat	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	300	300	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:34:29.328	2026-08-03 16:34:29.328	\N
h24ch3wwa	VP MOULINS	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault}	OP Clients	Draft	2026-08-06 00:00:00	2026-08-06 00:00:00	0	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-06 15:21:34.768	2026-08-06 15:21:34.768	\N
7e0efa80-60b4-46cb-949b-805bb87f53ea	Alpine Bony cars & coffee	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-06-27 00:00:00	2026-06-27 00:00:00	1000	916	Repris du suivi budgétaire 2026 (JUILLET)	50	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:35:00.677	2026-08-03 16:35:00.677	\N
d60e4834-f7bf-4026-bc37-ba2d0d6133e2	Salon Canoe Kayak	Vichy	{Vichy}	{"Vichy": 100}	{VN}	{Renault}	Expo/Salon	Done	2026-03-01 00:00:00	2026-03-01 00:00:00	263	263	Repris du suivi budgétaire 2026 (MARS)	100	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-03 16:34:35.699	2026-08-03 16:34:35.699	\N
5e8ca85d-a97e-4f95-a85a-3f8802abc1d7	projet : corporace 2027	Clermont	{Clermont}	{"Clermont": 100}	{VO}	{Nissan}	OP Clients	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	130	130	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:34:55.597	2026-08-03 16:34:55.597	\N
43f874c4-c93e-42d6-a689-47c7baa97044	projet : corporace 2028	Clermont	{Clermont}	{"Clermont": 100}	{PR}	{Nissan}	OP Clients	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	130	130	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:34:56.546	2026-08-03 16:34:56.546	\N
00cda21f-bcda-4491-80a8-be0bdc051dd3	projet : corporace 2029	Clermont	{Clermont}	{"Clermont": 100}	{APV}	{Nissan}	OP Clients	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	130	130	Repris du suivi budgétaire 2026 (AVRIL)	100	{}	\N	f	2026-08-03 16:34:57.662	2026-08-03 16:34:57.662	\N
46cf7cf7-de51-477a-88d8-3c64bbbd0dfd	opération edf	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine,Renault}	Expo/Salon	Done	2026-05-01 00:00:00	2026-05-01 00:00:00	90	90	Repris du suivi budgétaire 2026 (MAI)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	50	f	2026-08-03 16:34:59.701	2026-08-03 16:34:59.701	\N
5ada4024-dcde-45d8-be13-e8b5d5bd9b29	partenariat restaurant golf le puy	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	{VN}	{Renault}	Partenariat	Done	2026-03-01 00:00:00	2026-03-01 00:00:00	250	250	Repris du suivi budgétaire 2026 (MARS)	100	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-03 16:34:43.879	2026-08-03 16:34:43.879	\N
8dc191cc-49c7-407e-affe-797f272453b4	projet : stickers partenariat issoire	Issoire	{Issoire}	{"Issoire": 100}	{VN}	{Renault}	Partenariat	Done	2026-06-01 00:00:00	2026-06-01 00:00:00	298.98	298.98	Repris du suivi budgétaire 2026 (JUIN)	100	{}	\N	f	2026-08-03 16:34:30.433	2026-08-03 16:34:30.433	\N
d03c14f8-091b-4f53-9dee-9b817aa635bd	soirée fiscalité clermont	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault}	OP Clients	Done	2026-03-05 00:00:00	2026-03-05 00:00:00	500	290	Repris du suivi budgétaire 2026 (MARS)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	t	2026-08-03 16:34:32.444	2026-08-03 16:34:32.444	\N
d65c124f-494a-4409-9315-e476368af858	accueil balade rotary	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-05-30 00:00:00	2026-05-30 00:00:00	282	282	Repris du suivi budgétaire 2026 (MAI)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:34:33.553	2026-08-03 16:34:33.553	\N
4dcbf15b-9291-468b-a62f-869de6657298	blue days mars	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	Animation Co	Done	2026-03-12 00:00:00	2026-03-16 00:00:00	500	434	Repris du suivi budgétaire 2026 (MARS)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:34:19.708	2026-08-03 16:34:19.708	\N
8bd77070-00e1-4447-90a5-995919163d9c	projet : lancement twingo mende	Mende	{Mende}	{"Mende": 100}	{VN}	{Renault}	OP Clients	Done	2026-04-01 00:00:00	2026-04-01 00:00:00	48	48	Repris du suivi budgétaire 2026 (AVRIL)	100	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-03 16:35:02.764	2026-08-03 16:35:02.764	\N
96c084a0-5e75-4774-84ff-4420437bd6c4	Soirée BPCE	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Renault}	OP Clients	Done	2026-05-01 00:00:00	2026-05-01 00:00:00	92.84	92.84	Repris du suivi budgétaire 2026 (MAI)	100	{3939fc4c-1695-43de-887a-f36aa87363fb,15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:34:58.582	2026-08-03 16:34:58.582	\N
6cbe7065-1256-4c9e-adf1-b1c23fab23c4	conf de presse CCDMD	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	Contenu	Done	2026-07-09 00:00:00	2026-07-09 00:00:00	800	775	Repris du suivi budgétaire 2026 (JUILLET)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:35:01.795	2026-08-03 16:35:01.795	\N
a8354671-7497-4fb4-9cbd-3a617318e643	cars & coffee UNAPL	Clermont	{Clermont}	{"Clermont": 100}	{VN}	{Alpine}	OP Clients	Done	2026-06-01 00:00:00	2026-06-01 00:00:00	152	152	Repris du suivi budgétaire 2026 (JUIN)	100	{15025839-a51c-4bf2-8cff-703d5e7be91c}	\N	f	2026-08-03 16:34:53.585	2026-08-03 16:34:53.585	\N
nxo8lv1u7	OPO SEPTEMBRE 2026 ALLIER	Vichy, Moulins, Thiers	{Vichy,Moulins,Thiers}	{"Vichy": 33.33333333333334, "Thiers": 33.33333333333334, "Moulins": 33.33333333333334}	{VN,VO}	{Renault,Dacia}	Animation Co	Active	2026-09-08 00:00:00	2026-09-08 00:00:00	0	183		67	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-06 08:02:02.951	2026-08-06 08:02:02.951	\N
67483310-de1f-4608-aece-88c0ca8a3c09	lancement clio massagettes	Massagettes	{Massagettes}	{"Massagettes": 100}	{VN}	{Renault}	OP Clients	Done	2026-01-15 00:00:00	2026-01-15 00:00:00	2500	1209.19	Repris du suivi budgétaire 2026 (JANVIER)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:33:50.369	2026-08-03 16:33:50.369	\N
772d4c84-fd5d-4e0e-a813-65161b520f69	projet : inauguration renault pro+ le puy	Le Puy-en-Velay	{"Le Puy-en-Velay"}	{"Le Puy-en-Velay": 100}	{VN}	{Renault}	OP Clients	Done	2026-06-01 00:00:00	2026-06-01 00:00:00	3600.17	4617	Repris du suivi budgétaire 2026 (JUIN)	100	{744a1e04-b73b-4d48-b2b3-bc290a14ec80,46dcf78a-a158-4a4a-a064-52a843ddb935}	\N	t	2026-08-03 16:33:31.241	2026-08-03 16:33:31.241	\N
6ff34956-2bbc-4654-a285-e27f2c90e83e	lancement clio mozac	Mozac	{Mozac}	{"Mozac": 100}	{VN}	{Renault}	OP Clients	Done	2026-01-14 00:00:00	2026-01-14 00:00:00	4000	4343.63	Repris du suivi budgétaire 2026 (JANVIER)	100	{3939fc4c-1695-43de-887a-f36aa87363fb}	\N	f	2026-08-03 16:33:47.536	2026-08-03 16:33:47.536	\N
vpbv5diry	vA Issoire	Issoire	{Issoire}	{"Issoire": 100}	{APV}	{Renault}	OP Clients	Active	2026-09-24 00:00:00	2026-09-24 00:00:00	1600	0		0	{744a1e04-b73b-4d48-b2b3-bc290a14ec80}	\N	f	2026-08-04 12:24:31.356	2026-08-04 12:24:31.356	\N
\.


--
-- Data for Name: PushSubscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PushSubscription" (id, "userId", endpoint, p256dh, auth, "userAgent", "createdAt") FROM stdin;
c3afd9b6-73d6-46e4-bbd8-21cc264929a8	15025839-a51c-4bf2-8cff-703d5e7be91c	https://web.push.apple.com/QD6oe8CTjVnxel8ap50OTnJPeRIBh54Me3tVI1vcBGk32kv5mm4OQw38QcAMOgJ1KLRkUNmUY7jwsGtiu6SUONr0yCqNIIg7qypX3tZlXeKUb_-SDRrEG3QcNyvFxi0rj4MPBEhE4kAUyhm-KJUeYlh6FDica1l04qxjw_8bpxk	BBJ0fGzIdDvcS7AwmdW4Yt_WmOhT6r61aMuZ6_HspMhejgGst0aXtIzE9XbOEbhUZCR1U1iMP6EyqoP_lJqdVnY	Rb_LKeJEXku3qzgun_wWPw	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5.2 Mobile/15E148 Safari/604.1	2026-07-31 09:20:09.616
d7eed74a-5cc8-4d36-9310-03cf29c6058c	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	https://fcm.googleapis.com/fcm/send/cNlaLEOs2Z4:APA91bHIhBtbFXhDdOqxBOK7s7-iVq6I-XVilV1JSSQ2ISc3IZ0mFcMEYnt60IFJYO3cQ66Y6-I4Pko06VXHQULJCQhNIQIDOnVrOuz_1IbQvgg0bMbGd3GIzCND4obs4LoT97JO9y_G	BLWWF3SQLcl2PemaT05bW6Uubv8m-ruwup_25d-xlOLczLaLyktgWkQPcYfyEhB3dPYUEJMwaxxFkpuDIonwp6E	kuiN-JbE8VI7hKQJF8RZng	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36	2026-07-31 09:06:42.03
bb25de18-a163-49e5-8f88-0c450a26d7fb	3939fc4c-1695-43de-887a-f36aa87363fb	https://fcm.googleapis.com/fcm/send/e4KbqLvUJEQ:APA91bHIwB9UpxoGnxiH5e5C0YgCuqOBg1PccJzy2YlG2Mc_PU3bRZZyuyrxGQWvpNSr9-XG2pPuWdU1LTE6Sjti1--0n7VdO8xjYlgt8vxFtZ_vJjCHKPSzKW-WMtLNsrTyh8nw_qtF	BGrb_j1IwfbGU2FBjsfFn4Vke2SbRfYsrByMD_gCrrPTul8oR2ZbwPVDLqAgu9-jyagxCxzdWuytIwQwe2In-rU	5EbxBes-EJiMB-quperEBA	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36	2026-07-30 19:23:58.898
a9fb9b97-54a6-47b2-b879-995932b57c50	744a1e04-b73b-4d48-b2b3-bc290a14ec80	https://fcm.googleapis.com/fcm/send/eXzVafJHhho:APA91bGfQYrp9jGl_g3lYnjqyLV7WpwhCA5VPHmx_l3QDrWwdBD0PqxBDVu3-4KPHZ5GU3axHrolVzxNWQEt5EoUX_oksQkPrYoj461uREb495BNe6frU_H3QTRrjpK1p4ld1_obP_GA	BGMljVW284sh_LzRv1hG4YPfrhBKDuXm9n1t1AJBcrq9CrcKRdvOG13w9SaJtONoks5snId6XRCEOdoicyDMxP0	995NKnHXiy7JuW9yqzrYDQ	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-08-03 13:08:44.795
412029aa-7920-4cab-9484-864e5e9f2ca6	3939fc4c-1695-43de-887a-f36aa87363fb	https://fcm.googleapis.com/fcm/send/eDEQzwk4Fp8:APA91bGYVDtForf-Rb7l7-4Ke4N46jyFjmrOayMHpBZBLinD3TlTE9uAehPQVTF2oHXiMOv-ckGKMv4PHxPJ8A7u42gfp_vWOS5-LSy8cBCDNn_VexfqeN_ui51X6Np1qSXVB8orlAQO	BESRQ8sss-clEzlLB3pyXNBkRqTTR7SBwT6kri_WVjKENIqMJLQ6OI9WUhuq5JtNe1FFpPzXG6LxRMJV3KCUaO0	C9On-2lZ2Fd9y3Tz3vHoaA	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-30 19:31:56.5
c296ced9-97e9-44a3-98b3-c5d5385b81fa	744a1e04-b73b-4d48-b2b3-bc290a14ec80	https://fcm.googleapis.com/fcm/send/cCH2vEsNwvk:APA91bFA_WV3I5lV8lNyvfHrw-6Uidh9a3jCtCjLpBIcVBf4ko8KAlCeq1nKApBlIAAkenA-Mq-nGPlEBpF7DMamW0HQqLYo-PCvrQ734IqL1gBmhxYzSNQ8IbNCT3O5WOQKpEtP81Jb	BKZE3ckJOvFCWMDK_9EAwTglYqotgcn8whCjoUC5eDOzkNqzU_Y_f1gv9Mmg3WWfH8sr4977YZ2SvKDlWDPg_dc	PG0VQDo0gBNfJTo24yvu6g	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-08-07 08:32:23.326
6d8a47f1-6425-44b2-85d4-e9f6c8b4a430	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	https://fcm.googleapis.com/fcm/send/exHTnXGwwLI:APA91bGUU8bp-6vCZWh3lXxCoS_lEekVMor3O9finOSW0d2Tl-MRgjwvziOtOqJAqiqd4D2WrkbemWBs-fp2TsxSo56b636nEzhAsUxI3erjZ0xfoE8HKzI-nfv8qawDwK3lNkhOUMss	BHkW8upNepn-AYNC0rBYpeMmEDVc4vZArYrXzn_crFK0VugBaPBccaE3WPMVudkLMcLVT4038tkaTO6avl-mEQU	606r3IgvyhyUZNvtwckzTA	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-08-04 07:55:52.846
19b9e04a-ff62-4ade-9103-2e6419e997c1	744a1e04-b73b-4d48-b2b3-bc290a14ec80	https://fcm.googleapis.com/fcm/send/c_JLpNY2PFw:APA91bFRRqdmN3RPorGiLEwtPo5_ujZAecSOHHXMMpzrkwSTxiwHePZJpfQSZK6oNj2oZRSdtyUzCBaZ4HbUPoCAjnnGNxT8S6mjruAVN2LdsW08kc1AlyzHRfzTFEp9kshYQ30xouZp	BB9XEFWD0WIKVCRD9rM4oJaIP5vP78FH8BnSAB_serkcDKTWTybL-kw9Ve-mOpMn1QmFvq_A0fKxZr7uOoWdN-0	SCWltTgdFNdpPQgNCei0bQ	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-08-07 12:53:43.261
\.


--
-- Data for Name: SocialPost; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SocialPost" (id, title, status, date, targets, brands, service, networks, concessions, "mediaFiles", link, wording, lom, co2, archived, "createdAt", "updatedAt", "archivedAt") FROM stdin;
0bcf9348-d589-4efd-b148-b722b03d3b5a	test3	Rédigé	2026-08-03 00:00:00	{}	{}	Tous Services	{}	{}	{}		ffhf			t	2026-08-03 12:57:34.331	2026-08-03 12:57:56.189	2026-08-03 12:57:56.188
f0b0c465-f35a-4014-af9d-9d2bfe416db3	fff	À venir	2026-08-03 00:00:00	{}	{}	Tous Services	{}	{}	{/uploads/calendar/5e3e8b8c-3dfd-4f49-a470-92e9d58620e1.jpg}					f	2026-08-03 12:58:55.648	2026-08-04 12:35:02.898	\N
\.


--
-- Data for Name: Task; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Task" (id, "projectId", name, provider, channel, cost, status, "assignedUserId", volumetry, "openRate", "npaiRate", "stopRate", "clickRate", "codTxt", "billedAmount", "createdAt", "updatedAt") FROM stdin;
90fe28c6-2059-4d91-bbd3-71905c4dea87	1732ebbb-ac65-4620-8e30-4b53bdecc4b4	Bracelets soirée A390	LVAF		2024	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:32:58.291	2026-08-04 14:25:50.63
5ecad6df-369b-424c-af4e-af135bdb7f39	037552b9-cfeb-4600-927c-9dba9a939059	Hérail Imprimerie — Flyer A5 Clio 6	Hérail Imprimerie	Print	79	Done	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:32:59.269	2026-08-04 14:43:27.029
06196a4b-849e-4ff9-8b95-b3164d031091	037552b9-cfeb-4600-927c-9dba9a939059	Soirée lancement Clio — BSO		Traiteur	27408	Done	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:32:59.269	2026-08-04 14:43:27.065
ea42f44d-ad96-48ff-aef2-8ad068062fc1	037552b9-cfeb-4600-927c-9dba9a939059	Hérail Imprimerie — Flyer A5 Clio 6	Hérail Imprimerie	Print	79	Done	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:32:59.269	2026-08-04 14:43:27.047
lz6sjt355	2du8uofbb		\N		0	Todo	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:26:55.34	2026-08-04 15:26:55.34
1t1q15z65	a9580e52-43d2-4982-84d4-e498d4ea5908	Instructeur 1	Test Driving 63		300	Programmed	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:04:03.178	2026-08-06 07:32:36.724
c334a1e9-fc2e-47b6-b219-7ee6076d0b54	1a20b26c-1a9a-45bf-8d76-57bea4fc0bc3	RCC — Partenariat Rudy Servol	RCC		8000	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:12.338	2026-08-05 22:04:57.553
86stofu78	6inl5fk7a	INVITATION SMS	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 07:29:20.743	2026-08-07 07:30:05.868
zatq7xbag	6inl5fk7a	INVITATION MAIL	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 07:29:25.869	2026-08-07 07:30:05.885
1a619c08-4321-48c3-863d-bd3897324c3e	b17abf10-2b43-4361-ba9d-04c6d1de8aba	ACOMPTE Auverdrive — Convention Agents Groupe	ACOMPTE Auverdrive		2501	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:02.122	2026-08-03 16:33:02.122
0f9911f7-6ea1-4694-861f-b7e7a0ea59c9	b17abf10-2b43-4361-ba9d-04c6d1de8aba	ACOMPTE Auverdrive — Convention Agents Groupe	ACOMPTE Auverdrive		2501.5	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:02.122	2026-08-03 16:33:02.122
43217296-9a4c-491c-b0d2-3db60aca0c2f	b17abf10-2b43-4361-ba9d-04c6d1de8aba	RESTANT DU Auverdrive — Convention Agents Groupe	RESTANT DU Auverdrive		7041	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:02.122	2026-08-03 16:33:02.122
214a72f9-a6f4-4ee9-ab27-7446c0c881c7	b17abf10-2b43-4361-ba9d-04c6d1de8aba	RESTANT DU Auverdrive — Convention Agents Groupe	RESTANT DU Auverdrive		7041	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:02.122	2026-08-03 16:33:02.122
2046917f-a551-4210-ab48-76d4abda9182	17c89861-c6a1-4a8e-b8c5-aaba0d171de3	PARKGT — loc salle relance tel twingo	PARKGT		350	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:03.11	2026-08-03 16:33:03.11
e6b3f267-6b95-4dd3-924e-5e0a9762d25b	17c89861-c6a1-4a8e-b8c5-aaba0d171de3	PAG SOIREE TWINGO — PAG	PAG SOIREE TWINGO		167.28	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:03.11	2026-08-03 16:33:03.11
3f6de5a9-0be4-4a29-af32-0f74defa30a3	17c89861-c6a1-4a8e-b8c5-aaba0d171de3	solignat — Traiteur Twingo clf	solignat		7750	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:03.11	2026-08-03 16:33:03.11
d28768d9-4777-4f42-b5e7-dfaab378c453	17c89861-c6a1-4a8e-b8c5-aaba0d171de3	lvmr — mobilier twingo clf	lvmr		337.23	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:03.11	2026-08-03 16:33:03.11
f58b20b9-701c-491e-8bb4-eff3f7c8080c	17c89861-c6a1-4a8e-b8c5-aaba0d171de3	LA COULISSE — SOIREE TWINGO	LA COULISSE		6780.18	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:03.11	2026-08-03 16:33:03.11
4e932c15-ac4c-4585-b7e6-83036d8537c7	17c89861-c6a1-4a8e-b8c5-aaba0d171de3	COTE COULISSE — ANIMATEUR SOIREE TWINGO	COTE COULISSE		755	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:03.11	2026-08-03 16:33:03.11
xehj2pcx0	6inl5fk7a	MAIL DE REMERCIEMENT	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 07:29:39.145	2026-08-07 07:30:05.902
pq2aolzow	7e0efa80-60b4-46cb-949b-805bb87f53ea	Le QG	Le QG		840	Todo	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:11:31.692	2026-08-04 15:13:30.15
6d676eb5-e905-4739-bcdd-5141a68867f3	f208024e-4153-4b0b-8a2e-6a1bcc9e2434	MOTOR CONTACT — Partenariat GT4 2026	MOTOR CONTACT		15000	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:08.035	2026-08-05 22:05:11.058
0fadcf7c-6fd1-40a7-9c13-43f49385b4db	f0e2640b-83b5-4ba7-a958-03ff109a148d	Renouvellement partenariat	Stade Aurillacois	Lieu	22600	Done	b91965d9-5dfe-4b54-8306-7a3ca846c53d	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:01.195	2026-08-06 14:42:14.68
fzqkhpujr	h6k4gojow	TRAITEUR	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-06 08:15:35.641	2026-08-06 14:08:59.962
d7ece2ff-9580-48f2-bac9-c64a7fe6ebe2	33f8898b-5476-4fa2-9fce-1ef80c113cf5	ASCENT PROD — Portrait collaborateur	ASCENT PROD		159	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:09.263	2026-08-03 19:49:53.104
b086d331-bb4c-4808-bf21-f9025949eb64	33f8898b-5476-4fa2-9fce-1ef80c113cf5	ASCENT PROD — Portrait collaborateur	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:09.263	2026-08-03 19:49:53.121
2ad4b611-ec55-4b5e-b2cc-9720f7a94702	33f8898b-5476-4fa2-9fce-1ef80c113cf5	ASCENT PROD — Portrait collaborateur	ASCENT PROD		159	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:09.263	2026-08-03 19:49:53.139
29c51d14-9922-405e-b617-99ce5f4be761	33f8898b-5476-4fa2-9fce-1ef80c113cf5	ASCENT PROD — Portrait collaborateur	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:09.263	2026-08-03 19:49:53.156
ed5dbf20-c258-4b57-9559-5af31b5fdc26	33f8898b-5476-4fa2-9fce-1ef80c113cf5	ASCENT PROD — Portrait collaborateur	ASCENT PROD		159	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:09.263	2026-08-03 19:49:53.174
gddbtf1j9	g7el0wb3r	Matos 	\N		0	Todo	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-06 12:51:57.222	2026-08-06 12:52:42.295
9271453f-8f32-4867-86da-b2a56706b6ab	33681685-a4d2-419e-96a0-23752309e68b	Renouvellement partenariat	RAF	Lieu	14400	Done	b91965d9-5dfe-4b54-8306-7a3ca846c53d	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:10.159	2026-08-06 14:41:37.645
6646112c-f371-445d-b53d-53745f7f6d9b	5e3a27e8-4a25-44eb-a842-dd493561f5ac	solignat — traiteur twingo mozac	solignat		2480	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:27.33	2026-08-03 16:33:27.33
96cd8fbf-4e0c-4961-86b8-44727c62cab9	5e3a27e8-4a25-44eb-a842-dd493561f5ac	lvmr — mobilier twingo mozac	lvmr		338.74	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:27.33	2026-08-03 16:33:27.33
4577dcde-0c2b-48c3-8e0a-2d2ed0ac0519	5e3a27e8-4a25-44eb-a842-dd493561f5ac	LA COULISSE — SOIREE TWINGO	LA COULISSE		1104.89	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:27.33	2026-08-03 16:33:27.33
0c2963b5-fead-4f18-b16d-59aba86362c6	1732ebbb-ac65-4620-8e30-4b53bdecc4b4	Presta traiteur	Stéphane Ranieri	Traiteur	10912	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:32:58.291	2026-08-04 14:25:50.721
4a118397-54f0-4ff7-b70b-5eba5a682029	33f8898b-5476-4fa2-9fce-1ef80c113cf5	ASCENT PROD — Portrait collaborateur	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:09.263	2026-08-03 19:49:53.193
2fbfbcf8-f2a0-4ce8-9307-f8102af66109	de126b35-0186-4948-9237-e0fcda3049ed	MOBILIER VA MOZAC	LVMR		227.57	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:24.489	2026-08-04 15:04:43.779
68d92200-e0d2-4adb-853a-ddc03178c768	de126b35-0186-4948-9237-e0fcda3049ed	traiteur	Création Gourmande		1931.9	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:24.489	2026-08-04 15:04:43.798
3u7zrepef	4aly4336l	REPAS	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-06 13:10:02.16	2026-08-06 15:20:18.736
hacs70geu	h6k4gojow	SMS	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-06 08:15:45.05	2026-08-06 14:08:59.981
82kmwcmti	or83seebd	VAGUE AOUT 	All My SMS	SMS	0	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 08:35:34.322	2026-08-07 09:00:09.808
1rk6m5l8v	h6k4gojow	MAIL DE REMERCIEMENTS	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-06 08:15:58.768	2026-08-06 14:09:00
7u56n8dst	or83seebd	VAGUE OCTOBRE	All My SMS	SMS	4.77	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 08:35:52.554	2026-08-07 09:00:09.824
00cc468c-75fa-4013-b247-4fe527ea38ca	b21b4f77-e45c-4d68-9dc9-cde53ddcb770	Traiteur + Mobilier	Fromagerie Houlbert	Traiteur	3645.45	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:29.307	2026-08-03 19:25:24.756
b03b504e-9d1e-490b-8892-9034aab3b102	1732ebbb-ac65-4620-8e30-4b53bdecc4b4	Spot A390	ASCENT PROD	Audiovisuel	2000	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:32:58.291	2026-08-04 14:25:50.649
1e82c503-6ea3-46ee-8ffe-347092968e9f	1732ebbb-ac65-4620-8e30-4b53bdecc4b4	Jérôme Gallo 	Coté Coulisse	Audiovisuel	717	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:32:58.291	2026-08-04 14:25:50.667
35ea1d23-8366-40ce-a0ee-85fc72faa1e4	1732ebbb-ac65-4620-8e30-4b53bdecc4b4	accueil + parking soirée A390	PAG		279	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:32:58.291	2026-08-04 14:25:50.685
25595991-764f-4cfa-a58d-001b37d52100	1732ebbb-ac65-4620-8e30-4b53bdecc4b4	Presta orga soirée	Delighter	Audiovisuel	20174	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:32:58.291	2026-08-04 14:25:50.703
jq0gsjtbc	6cbe7065-1256-4c9e-adf1-b1c23fab23c4	Traiteur	DL traiteur	Traiteur	715	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:15:50.389	2026-08-04 15:23:34.758
k18f1jtbc	a9580e52-43d2-4982-84d4-e498d4ea5908	Instructeur 2	LCP		300	Programmed	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:05:03.264	2026-08-06 07:32:36.739
fz8iku0sg	a9580e52-43d2-4982-84d4-e498d4ea5908	Participation clients	Clients		-7250	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:30:52.484	2026-08-06 07:32:36.755
i5rb62tde	nxo8lv1u7	Repas	Restaurant du Golf	Traiteur	0	Programmed	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-06 08:03:07.648	2026-08-06 08:12:13.54
i9w1r8mf9	0b2a369e-7cc6-46f1-bca2-a6a1d19ea06d	Participation clients 	clients		-212	Todo	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:31:41.706	2026-08-06 08:11:02.983
mt7cyp7bf	h6k4gojow	MAIL	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-06 08:15:52.157	2026-08-06 14:09:00.018
r7fgur6cd	a9580e52-43d2-4982-84d4-e498d4ea5908	Instructeur 3	Xavier Ischard		300	Programmed	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:05:50.834	2026-08-06 07:32:36.77
ral0k37xn	993e1573-5d4a-41e7-a167-591111051248	Traiteur VA	Lassalas	Traiteur	800	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:18:50.888	2026-08-04 15:19:48.578
92217264-4980-4906-9b84-60163aed2036	19a3a414-b49e-4eeb-ac75-56693cdb9a75	Hotel Dieppe 2026	Hotel Mercure	Lieu	1993	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:15.344	2026-08-04 14:55:28.217
90962b04-2a2f-4865-a5e1-7982d41bd408	19a3a414-b49e-4eeb-ac75-56693cdb9a75	Resto Dieppe 3	SARL LA FERME DES ROCHES	Traiteur	564	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:15.344	2026-08-04 14:55:28.234
96fe9b40-9b75-4cc6-8850-f9d8d308afbb	19a3a414-b49e-4eeb-ac75-56693cdb9a75	Resto Dieppe 4	O BON PIF	Traiteur	540	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:15.344	2026-08-04 14:55:28.252
34f288bc-9e0f-4711-91eb-34efb01784c1	19a3a414-b49e-4eeb-ac75-56693cdb9a75	accueil café croissant	LE QG	Traiteur	240	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:15.344	2026-08-04 14:55:28.271
adf6dec8-f918-4bd2-b233-9db71ff59859	19a3a414-b49e-4eeb-ac75-56693cdb9a75	Visite Dieppe	SOCIETE AUTO ALPINE	Lieu	1500	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:15.344	2026-08-04 14:55:28.289
5726dda0-8930-4639-aba9-4fc66f7c00f5	19a3a414-b49e-4eeb-ac75-56693cdb9a75	Resto Dieppe 1	Casino Dieppe	Traiteur	789	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:15.344	2026-08-04 14:55:28.306
rcmjpjsg1	or83seebd	VAGUE JUILLET	All My SMS	SMS	0	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 08:35:21.737	2026-08-07 09:00:09.84
8t8hg0k38	or83seebd	VAGUE NOVEMBRE	All My SMS	SMS	6.435	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 08:36:31.247	2026-08-07 09:00:09.856
d8v0242q7	or83seebd	VAGUE MAI 	All My SMS	SMS	0	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 08:35:06.87	2026-08-07 09:00:09.873
7ddaa6b5-a4c6-427f-9a0c-d7da525be4b3	2f8ebecd-5485-44ec-9707-38fb2e3a6cc8	PAG RENEW DAYS — PAG	PAG RENEW DAYS		930.12	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:16.369	2026-08-03 16:33:16.369
53db0ff6-a516-4b33-8bff-fd516131442b	2f8ebecd-5485-44ec-9707-38fb2e3a6cc8	CREATION GOURMANDE — Repas équipe Renew Days	CREATION GOURMANDE		633.25	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:16.369	2026-08-03 16:33:16.369
e199c33b-109b-462c-afee-85bdd07bfc53	2f8ebecd-5485-44ec-9707-38fb2e3a6cc8	allmysms — sms vo	allmysms		519.93	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:16.369	2026-08-03 16:33:16.369
572086d2-cbd6-4c2c-ab0a-472c4a14f51d	2f8ebecd-5485-44ec-9707-38fb2e3a6cc8	parkgt — salle relance	parkgt		320	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:16.369	2026-08-03 16:33:16.369
32324555-45fc-48ef-bb31-c0f45d3faa44	2f8ebecd-5485-44ec-9707-38fb2e3a6cc8	creation gourmande — dejeuner rel tel	creation gourmande		304.04	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:16.369	2026-08-03 16:33:16.369
a795c850-1c06-47db-83c9-37348d12641a	2f8ebecd-5485-44ec-9707-38fb2e3a6cc8	creation gourmande — repas renew days	creation gourmande		633.25	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:16.369	2026-08-03 16:33:16.369
89b2e400-e5f3-4a64-b6e8-0b78a67714e2	2f8ebecd-5485-44ec-9707-38fb2e3a6cc8	takamaka — animation renew days	takamaka		2000	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:16.369	2026-08-03 16:33:16.369
e4e1fb87-52cc-483b-8766-4ea886033e4a	2f8ebecd-5485-44ec-9707-38fb2e3a6cc8	GRAPHIC — panneaux renew days	GRAPHIC		297	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:16.369	2026-08-03 16:33:16.369
3dbbe5d1-a80a-4260-9b7e-5e46ba5742d7	2f8ebecd-5485-44ec-9707-38fb2e3a6cc8	PAG — PAG RENEW DAYS	PAG		1080.12	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:16.369	2026-08-03 16:33:16.369
eaea6456-bb21-4a9d-8b5c-03d5b2126f44	2f8ebecd-5485-44ec-9707-38fb2e3a6cc8	PAG — PAG RENEW DAYS	PAG		167.28	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:16.369	2026-08-03 16:33:16.369
5a68cded-2172-431f-a26e-e33df160671c	17ea8c77-9f87-405f-80b3-7c6833f46b63	location circuit Mornay	POLE POSITION MORNAY	Lieu	3995	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:14.356	2026-08-04 14:39:24.895
9c347d2c-a5c8-4006-9a2f-9683a9d9ac4c	17ea8c77-9f87-405f-80b3-7c6833f46b63	61 repas circuit Mornay	Domaine de l'orangerie	Traiteur	1527	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:14.356	2026-08-04 14:39:24.911
kaobu5gwo	9a6bbb91-a492-4d61-99aa-d66d00113991	test	\N		0	Todo	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:44:23.647	2026-08-04 15:45:12.408
beca5f6c-31f2-46fb-bb57-89c66545e683	a9580e52-43d2-4982-84d4-e498d4ea5908	MAS DU CLOS — Loc circuit 25/09	MAS DU CLOS	Lieu	6000	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:19.288	2026-08-06 07:32:36.785
f1fa2fbb-93da-41dc-95dd-cef812153897	17ea8c77-9f87-405f-80b3-7c6833f46b63	Instructeur Mornay	Test Driving 63		300	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:14.356	2026-08-04 14:39:24.847
qmiqudsqu	or83seebd	VAGUE SEPTEMBRE	All My SMS	SMS	7.11	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 08:35:36.393	2026-08-07 09:00:09.889
mnylkh6st	nxo8lv1u7	Extras	Leclerc		0	Todo	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-06 08:11:49.967	2026-08-06 08:12:13.577
0f3f716c-9f24-48bf-bf99-1293a287ae85	17ea8c77-9f87-405f-80b3-7c6833f46b63	Instructeur Mornay	LCP		300	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:14.356	2026-08-04 14:39:24.863
bd83da4e-53c4-4043-911c-49b83783f619	17ea8c77-9f87-405f-80b3-7c6833f46b63	Vidéo Mornay	Ascent Prod	Audiovisuel	1087	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:14.356	2026-08-04 14:39:24.878
0aa45802-00c3-438b-8336-d543839474f2	772d4c84-fd5d-4e0e-a813-65161b520f69	CAVE SBBM — BOISSONS - INAUGURATION PRO+ PUY	CAVE SBBM	Traiteur	379	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:31.241	2026-08-07 13:22:19.946
knty49ysr	g7el0wb3r	Affiche	\N		0	InProgress	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-06 12:50:27.119	2026-08-06 12:52:42.193
ohj4b87pc	9e484187-b435-4cd3-b621-b1615a45c6e9	Préparer visuel pour le concours R4	Bastien Aruna		0	InProgress	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-04 08:05:00.866	2026-08-06 08:13:20.571
x1o17k6ym	g7el0wb3r	Décharge	\N		0	InProgress	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-06 12:50:44.929	2026-08-06 12:52:42.208
47bvk93ma	g7el0wb3r	Formulaire	\N		0	InProgress	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-06 12:50:54.933	2026-08-06 12:52:42.223
yiiwbv5z2	9a6bbb91-a492-4d61-99aa-d66d00113991	test	\N		0	Todo	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:44:23.982	2026-08-04 15:45:12.356
cbyh287ue	9a6bbb91-a492-4d61-99aa-d66d00113991	Mobilier VA	LVMR	Mobilier	0	Todo	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:22:39.827	2026-08-04 15:45:12.373
b9eoq96aa	9a6bbb91-a492-4d61-99aa-d66d00113991	test	\N		0	Todo	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:44:22.813	2026-08-04 15:45:12.39
74525422-f286-4846-aba8-46fe7e35bd71	0b2a369e-7cc6-46f1-bca2-a6a1d19ea06d	PHA — Course de cote	PHA	Lieu	4800	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:20.41	2026-08-06 08:11:02.999
893a16e3-c119-4114-ae2a-c7e95c8bd593	0b2a369e-7cc6-46f1-bca2-a6a1d19ea06d	PHA — Repas VIP CCDMD 2026	PHA	Traiteur	720	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:20.41	2026-08-06 08:11:03.015
0s1lfmm6w	9a6bbb91-a492-4d61-99aa-d66d00113991	Invitations Email	Sarbacane	E-mail	0	Todo	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:23:02.29	2026-08-04 15:45:12.426
bvoax2fel	9a6bbb91-a492-4d61-99aa-d66d00113991	tests	\N		0	Todo	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:45:04.93	2026-08-04 15:45:12.477
c65ca151-2216-4815-9706-40acfd353dce	8a461f9a-baa6-4f84-8c14-c4a780bf3ab6	BRASSERIE LE FRANCAIS — TRAITEUR TWINGO ISSOIRE	BRASSERIE LE FRANCAIS	Traiteur	2800	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:17.323	2026-08-04 07:57:31.809
a098a82f-177a-4a53-a684-f4acc2870ddf	8a461f9a-baa6-4f84-8c14-c4a780bf3ab6	FROMAGERIE HOULBERT — TRAITEUR SOIREE TWINGO	FROMAGERIE HOULBERT	Traiteur	2800	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:17.323	2026-08-04 07:57:31.826
80a9ab92-0b06-4875-91ac-f9dcdbee69dd	8a461f9a-baa6-4f84-8c14-c4a780bf3ab6	ISSOIRE SONORISATION — Sonorisation Twingo	ISSOIRE SONORISATION	Audiovisuel	880	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:17.323	2026-08-04 07:57:31.842
35f4ef06-b84d-46c8-8d71-b87873a870df	9e484187-b435-4cd3-b621-b1615a45c6e9	Course des filles — partenariat	Course des filles		800	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:05.402	2026-08-06 08:13:20.587
9ppbpkuuh	g7el0wb3r	Invit mail sms	\N		0	Todo	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-06 12:51:04.116	2026-08-06 12:52:42.238
toymhnz0q	g7el0wb3r	Stand caisse	\N		0	Todo	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-06 12:51:25.853	2026-08-06 12:52:42.252
60q0kd4na	or83seebd	VAGUE JUIN	All My SMS	SMS	0	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 08:35:14.587	2026-08-07 09:00:09.905
7d45cb00-cd57-49c7-aa17-6766b6c34bc0	50ad50ad-9bb4-4c8b-99cc-3501bf19e2eb	Toubkalpes — RENEW DAYS RODEZ	Toubkalpes		1600	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:22.491	2026-08-03 16:33:22.491
c0746571-b6e4-420d-be3b-85e5e19ca488	50ad50ad-9bb4-4c8b-99cc-3501bf19e2eb	SECURI PLUS — RENEW DAYS RODEZ	SECURI PLUS		935.28	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:22.491	2026-08-03 16:33:22.491
75c16498-d96e-4c8e-859c-298ca667317c	50ad50ad-9bb4-4c8b-99cc-3501bf19e2eb	TAKAMAKA — RENEW DAYS RODEZ	TAKAMAKA		2140	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:22.491	2026-08-03 16:33:22.491
e3c42397-6104-4c18-893d-3004d189733b	50ad50ad-9bb4-4c8b-99cc-3501bf19e2eb	OXYMEDIA — RENEW DAYS RODEZ	OXYMEDIA		656.6	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:22.491	2026-08-03 16:33:22.491
c73eda6c-e6d7-4147-904b-f549cf5ae330	aae8f445-bd7b-4de5-9851-6c12de1c5b6c	Amazon — Cravates Twingo	Amazon		88	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:26.411	2026-08-03 16:33:26.411
81280025-cf7e-43b2-a0b8-d3561590e3d6	aae8f445-bd7b-4de5-9851-6c12de1c5b6c	DJM SONORISATION — lumières lancement Twingo	DJM SONORISATION		483	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:26.411	2026-08-03 16:33:26.411
33edefca-4d28-41f3-9bf3-45c06b667c56	aae8f445-bd7b-4de5-9851-6c12de1c5b6c	AU PUY DES SAVEURS — Traiteur Twingo PUY	AU PUY DES SAVEURS		3370	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:26.411	2026-08-03 16:33:26.411
d0eb8948-a7c6-4a31-9768-12db6fd4e84e	03d5f0ec-7777-495d-ad56-0b390e086ccf	Roadbook RMC + RDF	Print Conseil	Print	514	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:34.988	2026-08-04 14:46:28.18
4e7a33c6-b1dc-49f6-a605-392004b79cb9	13f4bfee-730b-4e61-92be-3b1371c3c2c1	CREATION GOURMANDE — Traiteur Vichy	CREATION GOURMANDE	Traiteur	4147	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:23.462	2026-08-04 07:57:39.054
44ea9ed8-ebb5-4138-98ad-70fc4baddd87	dd6d8693-ee68-4600-8bae-b469620de10e	relance telephonique BSO	hotel bastide	Lieu	1800	Done	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:32.132	2026-08-03 19:30:16.803
fd8c86fe-dc5c-454d-830a-2dd5c21ae0fb	d0ccde38-7359-46c6-a2e6-5a7b8671e17f	MARLTON — Sonorisation Thiers Twingo	MARLTON	Audiovisuel	850	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:34.061	2026-08-04 08:03:18.86
e9561f82-faf3-4f93-9603-8cdacf8afe88	03d5f0ec-7777-495d-ad56-0b390e086ccf	Resto Monte Carlo	LA REMISE	Traiteur	1716	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:34.988	2026-08-04 14:46:28.198
4yj56qhap	a9580e52-43d2-4982-84d4-e498d4ea5908	Traiteur	La Mijotiere	Traiteur	1900	InProgress	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-05 09:12:18.279	2026-08-06 07:32:36.801
29619674-1f0b-41f3-8235-26b82d4e0a5a	13f4bfee-730b-4e61-92be-3b1371c3c2c1	MARLTON — Sonorisation Vichy Twingo	MARLTON	Audiovisuel	800	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:23.462	2026-08-04 07:57:39.072
4164c5ac-acb1-44da-8b9d-26cc498abda6	d0ccde38-7359-46c6-a2e6-5a7b8671e17f	SAS MATHE FABIEN — Traiteur Thiers Twingo	SAS MATHE FABIEN	Traiteur	2672	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:34.061	2026-08-04 08:03:18.88
d5d596f6-04ea-4402-8e1f-9b3c600b6b90	127e0ad8-55fd-43b6-b864-a3fafa0e6e74	ASCENT PROD — Vidéo Blue Expérience	ASCENT PROD		1700	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:28.326	2026-08-06 08:10:47.598
6ae3d4b2-913f-4d02-9238-9e50ca2589ad	456be7ec-934b-4a01-8b57-4cf6632578e2	PRO+ CIRCUIT ALBI — Location tireuse à bière	PRO+ CIRCUIT ALBI		302.5	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:37.045	2026-08-03 16:33:37.045
8ad1c986-48df-47ee-ad70-42cc1e355ae1	127e0ad8-55fd-43b6-b864-a3fafa0e6e74	MEET — Livraison allé blue expérience	MEET		1700	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:28.326	2026-08-06 08:10:47.615
749dfa2d-4683-4b75-a64a-ee9ef47005b1	3d3f614d-4f8d-4749-a6d6-b4d50681de1c	Traiteur + Galette	Patapain	Traiteur	3385	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:30.278	2026-08-04 14:58:17.218
ec45e0c4-1ff2-4a03-acb8-22a0cbb504d1	127e0ad8-55fd-43b6-b864-a3fafa0e6e74	L'en but — Café offert l'en but	L'en but		488	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:28.326	2026-08-06 08:10:47.631
80f90f78-9053-4ac0-ac0e-64febb882c6e	03d5f0ec-7777-495d-ad56-0b390e086ccf	Plaques rallye	Chaumeil	PLV	218	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:34.988	2026-08-04 14:46:28.143
c599cf22-b1e5-40d4-8cb9-f31639d1c8b7	3a836748-4feb-4366-9c5b-65116623f238	relance telephonique Bony	Grand Mess	Lieu	3524	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:25.472	2026-08-03 19:35:43.342
50acb41f-7731-4b99-8764-9c02b0c40ff6	3a836748-4feb-4366-9c5b-65116623f238	animation jounee phoning	BBowl	Lieu	427	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:25.472	2026-08-03 19:35:43.359
0ab8216b-cdda-4507-aa4a-08fee5bae74e	03d5f0ec-7777-495d-ad56-0b390e086ccf	Photos RMC 2026	Racecar Pictures	Audiovisuel	450	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:34.988	2026-08-04 14:46:28.161
3mrcyey3m	g7el0wb3r	Café 	\N		0	Todo	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-06 12:51:42.109	2026-08-06 12:52:42.281
517wsno4g	9a6bbb91-a492-4d61-99aa-d66d00113991	Invitation SMS	AllMySMS	SMS	0	Todo	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-04 15:23:35.682	2026-08-04 15:45:12.442
7w5xidrgj	g7el0wb3r	Voitures	\N		0	Todo	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-06 12:51:34.191	2026-08-06 12:52:42.267
87b674cf-8f98-49c4-8796-6aa30b754d57	456be7ec-934b-4a01-8b57-4cf6632578e2	PRO+ CIRCUIT ALBI — Traiteur circuit albi	PRO+ CIRCUIT ALBI		2450	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:37.045	2026-08-03 16:33:37.045
fcc8834d-7310-4737-a62b-0e2bd91f1886	cca1228b-7c4c-436b-8f8c-af4215da5386	ASCENT PROD — VIDEO TWINGO	ASCENT PROD		1804	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:40.781	2026-08-03 16:33:40.781
5b489d5e-ebf8-4122-bd0d-67a2a6b16831	1849dd57-122a-487e-bab2-e432276a347c	lvmr — mobilier twingo massagettes	lvmr		701.75	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:44.644	2026-08-03 16:33:44.644
0e9349d6-d719-44ef-ba27-cd9fa45a8821	1849dd57-122a-487e-bab2-e432276a347c	LA COULISSE — SOIREE TWINGO	LA COULISSE		920.96	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:44.644	2026-08-03 16:33:44.644
83009d73-c4e4-4f09-ae2c-d1cded169a06	84811883-f115-4dad-923f-18de211f57c4	Rotary — Partenariat Alpine Handigolf	Rotary		800	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:02.387	2026-08-04 15:24:58.697
2ab5333d-38c1-48f1-8ada-80d4aebe831c	b52de86d-d662-4422-9aef-8d90c371666c	FROMAGERIE HOULBERT — SOIREE BRIOUDE	FROMAGERIE HOULBERT	Traiteur	1500	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:46.545	2026-08-04 07:40:58.764
157814a5-75e1-4552-884e-ea778b937ab0	8acedb50-b681-4060-9ddb-4ee498af7d92	concessionnaires de marques auto de vichy — salon auto de vichy	concessionnaires de marques auto de vichy		1350	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:37.984	2026-08-04 11:40:09.95
dfa93af7-08e7-46b2-a4ce-ad0565ea41fe	8acedb50-b681-4060-9ddb-4ee498af7d92	concessionnaires de marques auto de vichy — salon auto de vichy	concessionnaires de marques auto de vichy		1350	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:37.984	2026-08-04 11:40:10.237
f245b4ea-9e8a-4375-bef5-06fb8e6a4971	df6d498c-d612-4082-abcf-71a8ad0ccbfd	JA VICHY BASKET — PARTENARIAT ANNUEL	JA VICHY BASKET		18488	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:18.291	2026-08-06 14:18:02.105
a43a3e56-bd55-4152-a1fc-3f5f32da1825	51598212-99f9-426c-9f5b-e889bf4c894f	 salle relance	ParkGT	Lieu	320	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:20.674	2026-08-04 15:15:42.846
f33a23a0-4a4a-4181-b962-73c6a86df3c9	51598212-99f9-426c-9f5b-e889bf4c894f	 dejeuner rel tel	Création Gourmande	Traiteur	99.6	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:20.674	2026-08-04 15:15:42.863
dkk7ckpe7	vpbv5diry	Campagne SMS	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-04 12:25:52.505	2026-08-06 14:09:31.926
84747c4e-a85a-4039-9799-2d2e0333ee58	9a6bbb91-a492-4d61-99aa-d66d00113991	Repas VA	Montrognon	Traiteur	1724	Programmed	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:43.682	2026-08-04 15:45:12.46
46f897d7-addf-4796-a617-69b14afa3ec7	17ea8c77-9f87-405f-80b3-7c6833f46b63	petit déj open bar	Circuit de Mornay	Traiteur	550	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:14.356	2026-08-04 14:39:24.928
7xbb4klab	a9580e52-43d2-4982-84d4-e498d4ea5908	Participation alpine bourgade	\N		-500	InProgress	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-05 14:26:37.505	2026-08-06 07:32:36.817
eae318c5-37c6-4dd2-8feb-10b06b26fe4b	772d4c84-fd5d-4e0e-a813-65161b520f69	O CAB — INAUGURATION PRO+	O CAB	Audiovisuel	700	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:31.241	2026-08-07 13:22:19.964
1aaabce6-9212-41b1-89ab-462eb83f54da	17ea8c77-9f87-405f-80b3-7c6833f46b63	1 repas supp	Domaine de l'orangerie	Traiteur	27	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:14.356	2026-08-04 14:39:24.944
kqy5ww93m	17ea8c77-9f87-405f-80b3-7c6833f46b63	Participation clients	Clients		-6750	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-04 14:38:13.137	2026-08-04 14:39:24.96
cc008d16-bd63-4041-9ed8-864c0793488f	abd31f5f-d89e-4c23-8b55-4df4cad76793	dome sancy foot	dome sancy foot		2500	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:38.911	2026-08-04 14:44:37.042
dc72bc18-6c47-4539-9d42-9055127fe8e8	c7a17964-5761-4d4d-b97a-454b0e2f9d3c	Mairie de Rodez — Sponsoring F'estivada	Mairie de Rodez		1900	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:39.805	2026-08-03 16:33:39.805
09c34ff8-e4f3-4a26-9eb5-a16305a1a89f	e2d844eb-2aaa-4909-bdfc-56aac09e4768	EN VRAI — MDA	EN VRAI		404	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:42.676	2026-08-03 16:33:42.676
40efe30e-ec5b-40be-92b5-50b652058091	e2d844eb-2aaa-4909-bdfc-56aac09e4768	EN VRAI — MDA	EN VRAI		40	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:42.676	2026-08-03 16:33:42.676
f464bdd9-7883-4ea1-97bb-766f89ca4e37	e2d844eb-2aaa-4909-bdfc-56aac09e4768	EN VRAI — MDA	EN VRAI		404	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:42.676	2026-08-03 16:33:42.676
76417b54-63ec-4acf-a6e9-6adbbfe0570f	e2d844eb-2aaa-4909-bdfc-56aac09e4768	EN VRAI — MDA	EN VRAI		40	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:42.676	2026-08-03 16:33:42.676
9ebe972b-a3ec-4c35-9fd1-8903f7acd304	e2d844eb-2aaa-4909-bdfc-56aac09e4768	EN VRAI — MDA	EN VRAI		404	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:42.676	2026-08-03 16:33:42.676
afbba8fb-d4d0-4dd0-a96f-11797f5a8aa1	e2d844eb-2aaa-4909-bdfc-56aac09e4768	EN VRAI — MDA	EN VRAI		40	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:42.676	2026-08-03 16:33:42.676
d6c58fe7-7014-4aa0-99ba-94310600adae	e2d844eb-2aaa-4909-bdfc-56aac09e4768	EN VRAI — MDA	EN VRAI		404	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:42.676	2026-08-03 16:33:42.676
ab31b49e-c4fc-4443-835b-5c1f3f4f402c	e2d844eb-2aaa-4909-bdfc-56aac09e4768	EN VRAI — MDA	EN VRAI		40	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:42.676	2026-08-03 16:33:42.676
aa6fa06d-6734-49bb-baf3-01a0d2e35ec5	d57b7e67-f17f-48bf-9031-a4d4f73a6df7	Traiteur	SAS MATHE Fabien	Traiteur	1801.52	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:41.757	2026-08-03 19:24:53.835
d6e953a3-7938-46ed-b539-db1f3d72ec1a	70cdcf76-2539-4c09-83cc-fb770adabb12	BEST WESTERN — REPAS PHONING EAA	BEST WESTERN		1095	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:48.51	2026-08-03 16:33:48.51
a7beab85-1a13-4dba-a468-f7714830ddb2	70cdcf76-2539-4c09-83cc-fb770adabb12	lacoulisse — projo phoning eaa	lacoulisse		92.51	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:48.51	2026-08-03 16:33:48.51
03604785-287a-4107-8b1a-b8e3d20c94ea	70cdcf76-2539-4c09-83cc-fb770adabb12	DA VINCI — dejeuner relance tel	DA VINCI		196.27	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:48.51	2026-08-03 16:33:48.51
2e94f6b9-b841-4974-a088-a98f6a95e17e	b4f54a23-b9fa-4970-9f86-362161061bb5	Traiteur + Mobilier	DV Events	Traiteur	1327.08	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:49.457	2026-08-03 19:25:05.553
sgflaa1zg	qz1og9akw	Orga générale	\N		0	InProgress	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-06 07:12:50.5	2026-08-06 07:14:00.86
1849f1bb-805a-46d4-b64b-5da78eabe34f	f450695f-3597-499b-b143-29076955115f	RP EVENTS — Inscriptions Corporace	RP EVENTS		130	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
74b868e5-5d04-4d1d-a233-e95e5356460a	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		23	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
cbdea384-a7d1-4bf9-97bf-b19e0c9055b1	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		23	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
517a982a-041c-4c35-8f21-589ec327ac28	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		23	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
064c27ff-85ad-4e7e-a0ac-dbf4643127a0	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		23	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
e8aae725-c992-491d-b8e1-16d51407ec08	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		84	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
f732fc8e-7eee-4028-9a2a-84c12c9a9e06	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		84	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
c130fcd5-8b88-4349-af24-0cab3acea8c3	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		84	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
8e715e53-3c9d-46ab-babe-5bbb45cd2efe	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		84	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
ebe7f060-0d7c-4629-906b-cee0a2928814	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		51	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
7c06b20c-d1f7-4cc1-91e9-0ee1ed37c32e	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		51	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
04020eb5-1cd0-49b5-92e2-fd563b9243fe	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		51	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
8a86cf7e-7986-4047-b36f-60916edb5295	f450695f-3597-499b-b143-29076955115f	GOODICOM — T-SHIRT CORPO	GOODICOM		51	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
5e6144d3-fc26-4ac5-8b17-1989be4ee643	f450695f-3597-499b-b143-29076955115f	Au Puy des Saveurs — Traiteur déjeuner des capitaines	Au Puy des Saveurs		308	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:56.275	2026-08-03 16:33:56.275
c0f3c231-ba7e-4e7d-84fb-533df9a3b65d	67f8970c-d0f0-463e-8f27-758d35596a65	Novotel — Comité	Novotel		226	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:57.499	2026-08-03 16:33:57.499
2ecd49bb-eede-47f2-8983-24df1bbc1f97	67f8970c-d0f0-463e-8f27-758d35596a65	Novotel — Comité	Novotel		226	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:57.499	2026-08-03 16:33:57.499
13efd5db-c844-4c29-8a48-f49ad58c1e94	67f8970c-d0f0-463e-8f27-758d35596a65	Novotel — Comité	Novotel		226	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:57.499	2026-08-03 16:33:57.499
e9b5de6e-9afc-4fbb-8bbe-47ae09abc6d0	67f8970c-d0f0-463e-8f27-758d35596a65	Novotel — Comité	Novotel		226	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:57.499	2026-08-03 16:33:57.499
tlj0dccmj	l2t8lq4w0	Orga générale	\N		0	InProgress	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-06 07:14:59.172	2026-08-06 07:15:43.157
c8674a2a-31cd-4c6e-997b-a737db75ee83	c946ade5-8cdb-4b4e-9a1d-3886e7b076fb	traiteur soirée CMV	1964	Traiteur	1075	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:53.08	2026-08-03 19:29:09.635
f57acb9c-fd13-43d1-84c5-2bda0c9be518	6ff34956-2bbc-4654-a285-e27f2c90e83e	Mobilier	LVMR	Mobilier	338.74	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:47.536	2026-08-03 19:17:02.672
131f8089-46d5-403b-b3c1-73fa7bb07d7e	43ed55e2-d0b1-42c3-939b-556542169f40	Tournage	Ascent Prod	Audiovisuel	1500	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:45.585	2026-08-03 19:00:17.602
059a8460-7faf-41bc-9c5f-d5be52659fa7	4bc22e4c-ee7a-4348-b29b-764695a8f6ca	TRAIL NBZ — TRAIL NBZ MASSAGETTES	TRAIL NBZ		800	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:51.355	2026-08-04 14:58:34.023
2aa693bf-b31a-4202-b5ac-4333e631a47b	a4655aea-4793-4946-ba6a-5aa266bbbad5	malintrat — alpine	malintrat		500	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:16.825	2026-08-06 08:09:24.051
086e403d-6b88-46c6-ac86-c0a0671290c7	947e5aad-42e3-4e1f-acc9-66c8f2221d9d	INTERMARCHE CEYRAT — EXPO VN MAI LA ROTONDE	INTERMARCHE CEYRAT		500	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:15.893	2026-08-03 16:34:15.893
ffqb4fa1z	03d5f0ec-7777-495d-ad56-0b390e086ccf	Participation clients	Clients		-5000	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-04 14:42:58.149	2026-08-04 14:46:28.217
vd22qneil	vpbv5diry	Campagne Mail	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-04 12:26:00.007	2026-08-06 14:09:31.945
921d2ff8-e98e-4dd4-a17e-4b2f956cc302	a9c8a863-0fe5-4f7d-abad-58124a8c7aa7	relance tel salle	parkgt	Lieu	350	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:12.143	2026-08-03 18:56:48.043
546fc0e3-3fc1-490a-a7c0-7a274d06edef	a9c8a863-0fe5-4f7d-abad-58124a8c7aa7	dejeuner	Création Gourmande	Traiteur	132.8	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:12.143	2026-08-03 18:56:48.062
7c1def0d-92e6-4f2a-9a53-fd69ed8f994c	a9c8a863-0fe5-4f7d-abad-58124a8c7aa7	mignardise	Création Gourmande	Traiteur	132.8	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:12.143	2026-08-03 18:56:48.08
v8dc4nby3	l2t8lq4w0	Traiteur 	\N		0	Todo	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-06 07:15:15.708	2026-08-06 07:15:43.172
03d486fe-48b9-4fee-8510-18cc1f3f4161	e992194c-3502-4f01-ad35-6ab05bc3c05e	Inscription salon	Salon Aveyr'Auto	Lieu	900	Programmed	de9c517b-0c41-4b81-9c34-87fde2f4f4d8	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:59.301	2026-08-06 14:39:16.419
07valeju3	772d4c84-fd5d-4e0e-a813-65161b520f69	MENAGE	xxxxx		335	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 13:17:58.956	2026-08-07 13:22:19.983
mc5pdei2w	1d5c5797-5bca-4161-9231-a0c99b59cbe9	Participation clients	Clients		-2350	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-04 14:49:51.866	2026-08-04 14:50:40.356
ee930722-9ee4-466b-bfcd-c514036c7ee7	c88b2d33-b0b7-4ff8-abea-9f816d6c52a2	La foulée des 2 roches	La foulée des 2 roches		800	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:01.311	2026-08-04 15:09:51.402
50132d55-eb0a-433f-8af8-e813674016ec	3a5ab6d2-44b1-47fe-8fd6-0f4c922d11a8	Moulins Yzeure Foot — Traiteur VA Moulins	Moulins Yzeure Foot	Traiteur	417	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:21.561	2026-08-04 07:58:16.911
h2pjk71dm	vpbv5diry	Campagne M	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-04 12:26:20.826	2026-08-06 14:09:31.963
acan6k3d8	nxo8lv1u7	Salle de séminaire 	Campanille Vichy	Lieu	183	Programmed	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-06 08:02:53.916	2026-08-06 08:12:13.558
45b60ae3-fb85-4305-91e2-250781e3417c	772d4c84-fd5d-4e0e-a813-65161b520f69	AMAZON — Cravates - PRO+	AMAZON		233	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:31.241	2026-08-07 13:22:20
7299bf8e-3ce4-45f9-a602-371a816cf275	1d5c5797-5bca-4161-9231-a0c99b59cbe9	GRAPHIC — Sticks fromage	Graphic	PLV	157	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:35.974	2026-08-04 14:50:40.271
8f1a87a6-6f6a-4cef-8358-02c8e85ec68b	1d5c5797-5bca-4161-9231-a0c99b59cbe9	29 REPAS EVENT ALPINE	RESTO GOLF MONT DORE	Traiteur	957	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:35.974	2026-08-04 14:50:40.288
73cfe630-eb3d-4cc7-9c5f-8458467c216c	1d5c5797-5bca-4161-9231-a0c99b59cbe9	Fromage event Alpine	FERME DE LAMBRES	Lieu	468	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:35.974	2026-08-04 14:50:40.306
d54a8682-116c-4f56-99a6-bb8e060e6189	1d5c5797-5bca-4161-9231-a0c99b59cbe9	Fromage event alpine	FERME LE ROC	Lieu	519	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:35.974	2026-08-04 14:50:40.322
whxa6psse	6inl5fk7a	Buffet	\N	Traiteur	0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 07:28:09.553	2026-08-07 07:30:05.85
i0btiygyr	4aly4336l	BOISSON	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-06 13:10:34.046	2026-08-06 15:20:18.754
sx2p9btm0	4aly4336l	INVITATION SMS 	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-06 13:10:34.061	2026-08-06 15:20:18.772
iyqfrpspf	4aly4336l	IN	\N		0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-06 13:10:34.076	2026-08-06 15:20:18.79
c4cb0963-789e-4605-9587-b241938c6958	fe178409-a2bc-407c-86d5-a6f0a79eb398	Expo VUVP Figeac — Traiteur	Expo VUVP Figeac		800	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:04.473	2026-08-03 16:34:04.473
5f355a2b-e351-4ba4-b474-861a76470faf	4509847b-abd8-4cd3-93d1-652108997894	Jogging ski triathlon — 15 KM DU PUY partenariat	Jogging ski triathlon		750	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:06.376	2026-08-04 14:16:15.479
498e0ffc-959c-4c23-8699-4997b9e371c2	3cdec894-492a-403c-bf4b-464feaad11d7	ASCENT PROD — PORTRAITS COLLAB	ASCENT PROD		162	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:08.281	2026-08-03 16:34:08.281
5cd79e75-e300-45d4-8d8f-9590724408a8	3cdec894-492a-403c-bf4b-464feaad11d7	ASCENT PROD — PORTRAITS COLLAB	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:08.281	2026-08-03 16:34:08.281
ebaddc76-ae53-4a86-a8a5-9bd00268c4fd	3cdec894-492a-403c-bf4b-464feaad11d7	ASCENT PROD — PORTRAITS COLLAB	ASCENT PROD		162	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:08.281	2026-08-03 16:34:08.281
9811dc5e-6179-41cb-89e6-668e2aa46371	3cdec894-492a-403c-bf4b-464feaad11d7	ASCENT PROD — PORTRAITS COLLAB	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:08.281	2026-08-03 16:34:08.281
59c3740f-c55b-4820-88dc-307661abc8ac	3cdec894-492a-403c-bf4b-464feaad11d7	ASCENT PROD — PORTRAITS COLLAB	ASCENT PROD		162	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:08.281	2026-08-03 16:34:08.281
cc12a4f8-f938-4cc4-9bb9-1f104e7c10ba	3cdec894-492a-403c-bf4b-464feaad11d7	ASCENT PROD — PORTRAITS COLLAB	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:08.281	2026-08-03 16:34:08.281
c0f4a7ea-5f88-47a8-bedb-4999b293c9ab	3cdec894-492a-403c-bf4b-464feaad11d7	ASCENT PROD — PORTRAITS COLLAB	ASCENT PROD		162	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:08.281	2026-08-03 16:34:08.281
393012f4-4df0-45d9-b617-1a11c9f16b76	3cdec894-492a-403c-bf4b-464feaad11d7	ASCENT PROD — PORTRAITS COLLAB	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:08.281	2026-08-03 16:34:08.281
dfc2e659-3ce9-4dcf-9d26-84e86429a2bd	1d5c5797-5bca-4161-9231-a0c99b59cbe9	Boites fromage	Goodicom	PLV	579	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:35.974	2026-08-04 14:50:40.339
59bbdbee-d3d7-48f8-87ef-2cad61e9ee62	4dcbf15b-9291-468b-a62f-869de6657298	Kit Blue Days	POINT MARQUAGE	PLV	434	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:19.708	2026-08-04 14:48:03.989
2f0ef4a7-c1b1-487a-b4e6-8bb378384e6c	93766725-f403-4440-bd29-f8557993d11b	journée phoning vn fevrier clf	Player63	Lieu	610.52	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:13.113	2026-08-04 14:58:40.727
605c59b9-c3b0-4eaf-a579-226d081818a2	6a49bba9-b85e-418d-b266-df0104c8b92b	LVMR — Loc housses	LVMR	Mobilier	60	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:11.227	2026-08-04 15:01:14.42
164dd59f-e5dd-4a1b-abe6-d7115d89ae7b	022baac0-9fa5-40cc-afa5-abeb83d56bfe	ASCENT PROD — PORTRAITS COLLABORATEURS	ASCENT PROD		159	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:10.211	2026-08-03 16:34:10.211
077b3a4d-816d-4bc6-b0ca-6c425e2758e7	022baac0-9fa5-40cc-afa5-abeb83d56bfe	ASCENT PROD — PORTRAITS COLLABORATEURS	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:10.211	2026-08-03 16:34:10.211
0317d0a7-c5af-4da4-9704-a2ba55a51aaa	022baac0-9fa5-40cc-afa5-abeb83d56bfe	ASCENT PROD — PORTRAITS COLLABORATEURS	ASCENT PROD		159	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:10.211	2026-08-03 16:34:10.211
cc8d5501-f91e-453a-bfea-a0b80f801db1	022baac0-9fa5-40cc-afa5-abeb83d56bfe	ASCENT PROD — PORTRAITS COLLABORATEURS	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:10.211	2026-08-03 16:34:10.211
31ffb94b-e2b4-4af9-ad1f-0e6372c0846f	022baac0-9fa5-40cc-afa5-abeb83d56bfe	ASCENT PROD — PORTRAITS COLLABORATEURS	ASCENT PROD		159	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:10.211	2026-08-03 16:34:10.211
7921069a-2cb5-4663-ac9d-3119a5afea1e	022baac0-9fa5-40cc-afa5-abeb83d56bfe	ASCENT PROD — PORTRAITS COLLABORATEURS	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:10.211	2026-08-03 16:34:10.211
dec600da-9891-464d-8e12-2e114e0e4e9c	022baac0-9fa5-40cc-afa5-abeb83d56bfe	ASCENT PROD — PORTRAITS COLLABORATEURS	ASCENT PROD		159	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:10.211	2026-08-03 16:34:10.211
a90a7586-e912-440b-840d-d8ba6989c37a	022baac0-9fa5-40cc-afa5-abeb83d56bfe	ASCENT PROD — PORTRAITS COLLABORATEURS	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:10.211	2026-08-03 16:34:10.211
8a2f180b-1b91-404d-8ffb-2ffd3bc0533e	7cae9a99-13dd-4677-909c-bc00abb07a9c	Inscriptions Corporace	RP EVENTS		1304	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:24.454	2026-08-04 15:12:54.429
9d67c398-e418-4dd0-be2e-e75473f1564e	b604db18-b2ee-4fd2-a0fd-85ae7b8c8d0c	Spot2Com — Sticker sous-rétro RAF	Spot2Com		45.36	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:22.461	2026-08-03 16:34:22.461
738a5a18-d288-4e57-92e5-8eb044e55a2f	b604db18-b2ee-4fd2-a0fd-85ae7b8c8d0c	Ourson Diffusion — Broderie tapis RAF	Ourson Diffusion		330	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:22.461	2026-08-03 16:34:22.461
1685cbd3-2389-4d03-9b61-2fbe9ed7a4ce	1d5c5797-5bca-4161-9231-a0c99b59cbe9	Café d'accueil A290	Le QG	Traiteur	162	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:35.974	2026-08-04 14:50:40.254
1125d714-f683-48f0-afdc-8dee11419cf2	f97ce65e-d511-4327-b5ab-5752c16189b0	Atelier VEZES — Sticker Clio partenariat Rugby 13	Atelier VEZES		300	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:29.328	2026-08-03 16:34:29.328
4aacc3aa-413d-41e0-bb4f-305eeef055d9	993e1573-5d4a-41e7-a167-591111051248	Mobilier VA	LVMR	Mobilier	301.19	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:28.419	2026-08-04 15:19:48.56
65fd3141-d79b-41b5-a410-9113d85f7faa	5119bd87-8d3a-493e-992d-74ab4ca208ba	djm sonorisation	djm sonorisation	Traiteur	483.33	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:17.776	2026-08-03 18:55:15.627
3abe6bfa-0b76-4a62-b247-39b90d151b4e	33f8898b-5476-4fa2-9fce-1ef80c113cf5	ASCENT PROD — Portrait collaborateur	ASCENT PROD		159	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:09.263	2026-08-03 19:49:53.068
6e3e3c30-ad07-44a5-8402-6fe0241f2e29	33f8898b-5476-4fa2-9fce-1ef80c113cf5	ASCENT PROD — Portrait collaborateur	ASCENT PROD		16	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:09.263	2026-08-03 19:49:53.086
9087f0d8-864c-4afc-bf65-fea2bb275230	8a4eabb6-fbb1-4982-b8aa-bd85e0f3635f	FERRARISSIMO — 20 baptêmes	FERRARISSIMO		600	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:14.037	2026-08-04 07:42:03.468
0d618f42-3001-4692-86e4-42f1a6555d8e	6a49bba9-b85e-418d-b266-df0104c8b92b	CREATION GOURMANDE — TRAITEUR SOIREE DEPAILLER	CREATION GOURMANDE	Traiteur	608	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:11.227	2026-08-04 15:01:14.439
8c7377ac-f8f2-43a0-baa4-11e2d13b8267	67483310-de1f-4608-aece-88c0ca8a3c09	Mobilier	LVMR	Mobilier	288.23	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:50.369	2026-08-04 14:58:25.462
c22c132b-8f82-48c6-9667-03066677f561	5e8ca85d-a97e-4f95-a85a-3f8802abc1d7	RP EVENTS — Inscriptions Corporace	RP EVENTS		130	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:55.597	2026-08-03 16:34:55.597
7d51e995-a913-4f26-989e-5ad05cd5985d	43f874c4-c93e-42d6-a689-47c7baa97044	RP EVENTS — Inscriptions Corporace	RP EVENTS		130	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:56.546	2026-08-03 16:34:56.546
1684c7f6-2456-45fe-8e0c-99be860b8808	00cda21f-bcda-4491-80a8-be0bdc051dd3	RP EVENTS — Inscriptions Corporace	RP EVENTS		130	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:57.662	2026-08-03 16:34:57.662
ccc640be-1d4d-4f1e-a7e3-bf768a15c136	67483310-de1f-4608-aece-88c0ca8a3c09	Technique	Lacoulisse	Audiovisuel	920.96	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:50.369	2026-08-04 14:58:25.48
09b5391b-357f-4c15-9a1a-d0163d7639c8	46cf7cf7-de51-477a-88d8-3c64bbbd0dfd	PRINT CONSEIL — Brochures EDF	PRINT CONSEIL	Print	45	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:59.701	2026-08-04 15:02:01.112
582867a1-498e-4d39-a543-efafc3bca311	6ff34956-2bbc-4654-a285-e27f2c90e83e	Technique	Lacoulisse	Audiovisuel	1104.89	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:47.536	2026-08-03 19:17:02.689
4edfff39-307d-4ced-9cf8-69c9b2c6c188	d60e4834-f7bf-4026-bc37-ba2d0d6133e2	EXPOSITION SALON CANOE KAYAK	FNPLCK		263	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:35.699	2026-08-03 19:47:18.354
f3f951b1-ef75-4727-bbb1-ed87d35c2fba	d03c14f8-091b-4f53-9dee-9b817aa635bd	cocktail soiree fisca	Solignat	Traiteur	290	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:32.444	2026-08-03 19:49:32.632
9ccfd714-697e-451e-86f8-1fe31156ca19	8dc191cc-49c7-407e-affe-797f272453b4	GRAPHIC — FLOCAGE TRAFIC PARTENARIAT	GRAPHIC		298.98	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:30.433	2026-08-04 07:41:58.076
bb4fd802-dc1a-40f4-9d01-5d9c0b5634d5	46cf7cf7-de51-477a-88d8-3c64bbbd0dfd	PRINT CONSEIL — Brochures EDF	PRINT CONSEIL	Print	45	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:59.701	2026-08-04 15:02:01.13
3eea9972-3818-437b-b27c-e5da956a9083	72844ee8-9259-499a-aa04-889f8de82bc4	location 7 housses MD + chaises x20	LVMR	Mobilier	133	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:54.694	2026-08-04 15:02:09.979
cfdb5652-9a15-4440-ba92-eb5f50a45206	a1532a06-1dec-4fb4-ba9c-03e73f5fc3ee	Traiteur Clio Vichy	Création Gourmande	Traiteur	3595.29	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:33.162	2026-08-03 19:01:07.327
7d645028-ba8d-4c9e-abf9-c5ec4347fedb	96c084a0-5e75-4774-84ff-4420437bd6c4	Housse soirée 18/05	LVMR	Mobilier	92.84	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:58.582	2026-08-04 15:18:11.734
588fd74b-0d31-4495-959e-e84b4a25d165	6cbe7065-1256-4c9e-adf1-b1c23fab23c4	LVMR — Loc housses	LVMR	Mobilier	60	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:35:01.795	2026-08-04 15:23:34.775
9ee45c04-6642-45e3-b3bd-f38d22089539	d65c124f-494a-4409-9315-e476368af858	LVMR — Loc housses	LVMR	Mobilier	42	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:33.553	2026-08-04 14:22:29.72
045dd23a-4635-43f2-8735-fae044136b04	5ada4024-dcde-45d8-be13-e8b5d5bd9b29	Stickers clio restaurant golf	Atelier 2G Publicité	PLV	250	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:43.879	2026-08-03 19:46:24.838
32192aea-ed1f-4efe-ab1c-8d43e44515d9	d65c124f-494a-4409-9315-e476368af858	LE QG — Accueil café	LE QG	Traiteur	240	Done	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:33.553	2026-08-04 14:22:29.736
b2430584-fb61-4641-8cba-db2643b71346	8bd77070-00e1-4447-90a5-995919163d9c	SUPERU — Traiteur Twingo	SUPERU	Traiteur	48	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:35:02.764	2026-08-04 07:56:46.851
312a54cf-fc68-44d4-a5b8-b904d091b720	a8354671-7497-4fb4-9cbd-3a617318e643	PATAPAIN — Presta café croissant UNAPL	PATAPAIN	Traiteur	152	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:53.585	2026-08-04 15:25:40.948
8a7f7523-686d-45cc-820a-182d9dfb6c55	5acbf744-5bed-470c-95e9-94404c98ab7b	Repas relance Tel VP	Boeuf Brezet	Traiteur	297	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:31.462	2026-08-04 15:21:40.941
5a6907d8-bc52-4344-a79f-2601c36cd267	7e0efa80-60b4-46cb-949b-805bb87f53ea	LVMR — loc housses	LVMR		76	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:35:00.677	2026-08-04 15:13:30.169
8c2e2304-f6dc-4579-a652-cbf7ccd59155	a4f70142-e786-4bb7-ad03-8f2c413bdc4e	Blue Days sms campagne	Phonecontact	SMS	361	Done	15025839-a51c-4bf2-8cff-703d5e7be91c	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:34:23.55	2026-08-04 14:14:02.066
7b30a5f1-9b25-4d05-8660-e5bd670156fe	3d3f614d-4f8d-4749-a6d6-b4d50681de1c	Mobilier	LVMR	Mobilier	150.48	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:30.278	2026-08-04 14:58:17.236
5c7e8e36-2c1b-4823-9263-f95e64d7b89b	3d3f614d-4f8d-4749-a6d6-b4d50681de1c	Projo	Lacoulisse	Audiovisuel	92.51	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:30.278	2026-08-04 14:58:17.254
f9e48966-45e8-43f8-b02d-1b5c06b9c768	772d4c84-fd5d-4e0e-a813-65161b520f69	PRINT CONSEIL — INVITATIONS PRO+ PUY SUPP	PRINT CONSEIL	Print	160	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-07 13:18:43.164	2026-08-07 13:22:20.019
57ce9e95-403f-49ca-856b-a4fd4bba3546	66648793-1458-43fe-a40d-e552e974048d	Mobilier soirée Clio	LVMR	Mobilier	701.75	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:00.232	2026-08-03 19:18:30.917
d84f9145-c193-4a71-997b-7ed085b84122	66648793-1458-43fe-a40d-e552e974048d	Technique soirée Clio	Lacoulisse	Audiovisuel	12394.46	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:00.232	2026-08-03 19:18:30.936
18763872-7886-48a4-87c9-992a47757503	66648793-1458-43fe-a40d-e552e974048d	Jérôme Gallo soirée Clio	Coté Coulisse	Audiovisuel	717.25	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:00.232	2026-08-03 19:18:30.954
58fb4bc0-401a-4e81-8bb7-041579cc053b	66648793-1458-43fe-a40d-e552e974048d	Vidéo soirée lancement Clio	Ascent Prod	Audiovisuel	500	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:00.232	2026-08-03 19:18:30.973
ade00b7f-eb15-47c9-b38e-12b11238782d	66648793-1458-43fe-a40d-e552e974048d	Traiteur	Montrognon	Traiteur	9570	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:00.232	2026-08-03 19:18:30.991
gx7givjlj	6ff34956-2bbc-4654-a285-e27f2c90e83e	Traiteur	Montrognon	Traiteur	2900	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 19:16:26.653	2026-08-03 19:17:02.705
4281cbf2-1d6d-47a4-bcf7-500a4bf898f3	66648793-1458-43fe-a40d-e552e974048d	Accueil et Emargement	Pag		436.02	Done	3939fc4c-1695-43de-887a-f36aa87363fb	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:00.232	2026-08-03 19:18:31.009
xu2ekv4gt	vpbv5diry	Buffet	\N	Traiteur	0	Todo	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-04 12:25:33.389	2026-08-06 14:09:31.982
1b60cfbc-71b9-4e7f-a8f7-63b588b0a9d9	772d4c84-fd5d-4e0e-a813-65161b520f69	VELAY RECEPTION — INAUGURATION PRO+	VELAY RECEPTION	Mobilier	2810	Done	744a1e04-b73b-4d48-b2b3-bc290a14ec80	\N	\N	\N	\N	\N	\N	\N	2026-08-03 16:33:31.241	2026-08-07 13:22:20.036
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, "loginId", "passwordHash", name, role, "avatarColor", "createdAt", "updatedAt", "avatarUrl", birthdate, sites) FROM stdin;
f777e039-859f-4632-aaba-92ea63a64eb8	morgane	$2b$10$Va6XGQ.jZnJ/8ECAqHPUnuZ0.JcTl21oyONrKQ8fivmpBniVPSXaC	Morgane Barthe	Digital Manager	#8cc7d	2026-07-08 15:26:27.565	2026-08-06 14:24:02.279	/uploads/avatar/253e6d78-43e4-4694-a7c8-fe2fbf49ef28.jpg	\N	{}
a7e87340-b7ff-4efc-991b-e83db4ebcc62	isabelle	$2b$10$O5DyAYddsyEgTUTknMPvz.A9pd1OKwqMAqieSOUsedN8P3jZU.DQm	Isabelle Auclair	Guest	#c4791f	2026-07-08 15:27:21.565	2026-08-05 09:32:18.859	/uploads/avatar/b974e3d5-85e2-4f65-8883-4322dd3f25c0.jpg	\N	{}
ceefebb1-4c69-42f3-95d5-91e7e3b34cf9	ludivine	$2b$10$H3jFJ2Q..1KgPgGZe1DQve1mQrLX2ZHm0I8IobvmUKhgxLn4TCF2C	Ludivine Roux	Guest	#fa009a	2026-07-08 15:29:00.524	2026-08-05 09:32:30.859	/uploads/avatar/2fa954da-4514-4fcd-aaf4-cb42bb747129.jpg	\N	{}
115b7640-65f4-4b6f-9c82-fb59b5ffffc2	lucien	$2b$10$LGkEQX4IfjRnfCvXqMtF3euwKv85UkisFme4RDyMeJsATFZy2MKNi	Lucien Marchetti	Site Manager	#3e58cc	2026-08-05 22:29:48.638	2026-08-05 22:29:48.638	\N	\N	{Mozac}
af47c934-5e71-4adf-9a0a-92f966af2fdc	hugo	$2b$10$PD43gHi4sXKAJgdYOLT0.O1.XMGr5V539qcDcVS62/SuDL/hrqBrq	Hugo Culetto	Digital Manager	#e9202c	2026-07-08 15:16:13.707	2026-08-05 09:33:04.337	/uploads/avatar/4fb20e8d-bf7c-49b4-8473-ee5c813a7bb6.jpg	\N	{}
46dcf78a-a158-4a4a-a064-52a843ddb935	claire	$2b$10$y9YqmYYD7Ns7oKx3yZz9k.Zgot3pcInDsceY5uWoR7SQYvG94wXiG	Claire Richard	Administrator	#bb7f84	2026-07-08 15:12:54.93	2026-08-05 09:33:31.417	/uploads/avatar/0e1dfdb7-f1b6-464d-a514-d83383be08cb.jpg	\N	{}
b91965d9-5dfe-4b54-8306-7a3ca846c53d	christian	$2b$10$NGTQ1ahdNl0pfbI43/.PPO4et.dUiGiJVPyzAdshIbqcumO7Y6FhG	Christian Charlier	Director	#11b7dc	2026-07-08 15:21:13.832	2026-08-06 08:04:09.948	/uploads/avatar/f8fb956c-e754-4665-b3ac-125f24fda59f.jpg	\N	{}
49a49666-4c68-4d05-8d45-c8e3a1dc7e08	ali	$2b$10$5seMp93rk.4v6B6TRXcOoecadrsn6cYmLuGOxTljx4itnZj7aGkqO	Ali Abou El Jinane	External	#715e7	2026-07-08 15:21:47.369	2026-08-06 08:04:37.968	/uploads/avatar/17119efe-eda6-4ec3-8b73-35017defd978.jpg	\N	{}
b7d91c00-d926-4665-a67a-48ad186097b0	bruno	$2b$10$14SXMcB2D1CmAyvgU1J/COYSRU7LDkwQbhBJR41TXJn5TFnM6vPd6	Bruno Walkowiak	Guest	#64871e	2026-08-03 13:10:23.249	2026-08-06 13:21:16.276	/uploads/avatar/77c34f5b-cf39-442e-b5a2-eb4f81c81f5f.jpg	\N	{}
3939fc4c-1695-43de-887a-f36aa87363fb	theo	$2b$10$aNhNQhBdbV5.CV32AQhbNuo9ZRrOBEKSAKAiq2hUC2wMLD2pATYl6	Théo Labonne	Master	#f75632	2026-07-06 16:06:19.732	2026-08-04 15:54:11.136	/uploads/avatar/c9dde54e-5d62-4c36-8104-df6265184ea8.jpg	1998-05-14	{}
15025839-a51c-4bf2-8cff-703d5e7be91c	bastien	$2b$10$rsw/IBoIPyzXQyoTTqKigeqEWAdX2I/XkV3BDdmO6PIoIqoiiQGly	Bastien Fuziol	Coordinator	#270bc0	2026-07-08 15:17:49.956	2026-08-06 13:22:00.221	/uploads/avatar/7b2e8148-4afb-4d6f-a266-95aa4201cada.jpg	2001-03-02	{}
744a1e04-b73b-4d48-b2b3-bc290a14ec80	romane	$2b$10$IN9zrCmwMWXuTF0i3GQzqu7pkUFtZsUA86YzYDDEgHgufjqvrhb2m	Romane Chambon	Coordinator	#dac06d	2026-07-08 15:13:27.112	2026-08-06 13:28:42.646	/uploads/avatar/5a777661-06ba-41bc-b65a-2a8227f69770.jpg	2002-10-22	{}
de9c517b-0c41-4b81-9c34-87fde2f4f4d8	alexis	$2b$10$E/1TyNYVRTiyKLWkYs5D2eZLHsuxaVDY8Pw2nggA7IpyiEvzR2pGm	Alexis Perz	Coordinator	#1cce70	2026-07-08 15:23:44.355	2026-08-06 14:02:42.15	/uploads/avatar/1cf1ccce-fa36-432e-888a-5b6d468a84db.jpg	2000-11-07	{}
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
a587fa45-8ae4-4505-9b49-19db393f7c1b	d34db5aab2250ad00675cc2f205ce645e8571d143298d9a6923a056616e3fc10	2026-07-06 16:06:00.372845+00	20260706160559_init	\N	\N	2026-07-06 16:06:00.014548+00	1
2daabb6b-658e-4ce4-924e-c6493f2c39bc	16a6bf61492649dc3f50675fd456e62d62f3888c21c3be18abd707c7d806ac8a	2026-07-08 11:48:31.502587+00	20260708114830_add_avatar_and_archived_at	\N	\N	2026-07-08 11:48:31.134881+00	1
9998cdaa-4acf-489e-9a00-9f86714a2a11	033b8a0a125a61347ddcfe5dabc175fb2f29b10261fa06b8ecaeed0e926c941c	2026-07-30 18:48:13.924593+00	20260730184718_add_push_subscriptions_and_chat_mute	\N	\N	2026-07-30 18:48:13.713841+00	1
6e0cb304-8fa7-49ce-92df-0d641ef4b6b5	785463c3c5a766867fb8ecc51d278734d95b35f6dbf7ad41ddff97d4ca1c3aab	2026-08-04 11:05:14.391719+00	20260804110458_add_nissan_share	\N	\N	2026-08-04 11:05:14.11264+00	1
17154396-98b6-4891-8424-3611c0aaf0aa	708f2c20d685ca4de0b92f05803bc0b82f02088bb8dac7ba4c6ac82a3b0aeb39	2026-08-04 15:26:04.390115+00	20260804152533_add_user_birthdate	\N	\N	2026-08-04 15:26:04.071179+00	1
ac901a56-d629-4acc-9063-370c9d7d918e	e7f4dd2764a4ef564b3beb326bede3edde4449c2df5bb1e9ff87ffe9ceca6b1a	2026-08-05 08:21:53.514478+00	20260805082122_add_chat_attachments	\N	\N	2026-08-05 08:21:53.2209+00	1
3c38b83d-97dc-4aa2-961a-e9e2e1c4aff5	63547987d9030ab1567602a248abf7a5e9e0de8382c91a015bbcecc11b0a1727	2026-08-05 13:17:12.82634+00	20260805131643_add_games	\N	\N	2026-08-05 13:17:12.533634+00	1
b8e8723a-7ab6-46e2-b856-66d3f5234132	3d0caae641e9a862a79474fb0da41aaf5e244493c93ec86d6da98b5d78b45395	2026-08-05 19:00:49.356782+00	20260805190033_add_user_sites	\N	\N	2026-08-05 19:00:49.176388+00	1
1fd5f92b-1194-4ed8-83c6-cc0c7b5801dc	b6da93c82827bfd14ea1094f4d18ae29f4c671852e1114c09d29cd07a2dfc878	2026-08-06 08:59:04.764105+00	20260806103000_add_chat_conversation_avatar	\N	\N	2026-08-06 08:59:04.445776+00	1
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-07-06 14:51:49
20211116045059	2026-07-06 14:51:50
20211116050929	2026-07-06 14:51:50
20211116051442	2026-07-06 14:51:50
20211116212300	2026-07-06 14:51:50
20211116213355	2026-07-06 14:51:50
20211116213934	2026-07-06 14:51:50
20211116214523	2026-07-06 14:51:50
20211122062447	2026-07-06 14:51:50
20211124070109	2026-07-06 14:51:50
20211202204204	2026-07-06 14:51:50
20211202204605	2026-07-06 14:51:51
20211210212804	2026-07-06 14:51:51
20211228014915	2026-07-06 14:51:51
20220107221237	2026-07-06 14:51:51
20220228202821	2026-07-06 14:51:51
20220312004840	2026-07-06 14:51:51
20220603231003	2026-07-06 14:51:51
20220603232444	2026-07-06 14:51:51
20220615214548	2026-07-06 14:51:52
20220712093339	2026-07-06 14:51:52
20220908172859	2026-07-06 14:51:52
20220916233421	2026-07-06 14:51:52
20230119133233	2026-07-06 14:51:52
20230128025114	2026-07-06 14:51:52
20230128025212	2026-07-06 14:51:52
20230227211149	2026-07-06 14:51:52
20230228184745	2026-07-06 14:51:52
20230308225145	2026-07-06 14:51:53
20230328144023	2026-07-06 14:51:53
20231018144023	2026-07-06 14:51:53
20231204144023	2026-07-06 14:51:53
20231204144024	2026-07-06 14:51:53
20231204144025	2026-07-06 14:51:53
20240108234812	2026-07-06 14:51:53
20240109165339	2026-07-06 14:51:53
20240227174441	2026-07-06 14:51:53
20240311171622	2026-07-06 14:51:53
20240321100241	2026-07-06 14:51:54
20240401105812	2026-07-06 14:51:54
20240418121054	2026-07-06 14:51:54
20240523004032	2026-07-06 14:51:54
20240618124746	2026-07-06 14:51:54
20240801235015	2026-07-06 14:51:55
20240805133720	2026-07-06 14:51:55
20240827160934	2026-07-06 14:51:55
20240919163303	2026-07-06 14:51:55
20240919163305	2026-07-06 14:51:55
20241019105805	2026-07-06 14:51:55
20241030150047	2026-07-06 14:51:55
20241108114728	2026-07-06 14:51:55
20241121104152	2026-07-06 14:51:56
20241130184212	2026-07-06 14:51:56
20241220035512	2026-07-06 14:51:56
20241220123912	2026-07-06 14:51:56
20241224161212	2026-07-06 14:51:56
20250107150512	2026-07-06 14:51:56
20250110162412	2026-07-06 14:51:56
20250123174212	2026-07-06 14:51:56
20250128220012	2026-07-06 14:51:56
20250506224012	2026-07-06 14:51:56
20250523164012	2026-07-06 14:51:56
20250714121412	2026-07-06 14:51:57
20250905041441	2026-07-06 14:51:57
20251103001201	2026-07-06 14:51:57
20251120212548	2026-07-06 14:51:57
20251120215549	2026-07-06 14:51:57
20260218120000	2026-07-06 14:51:57
20260326120000	2026-07-06 14:51:57
20260514120000	2026-07-06 14:51:57
20260527120000	2026-07-06 14:51:57
20260528120000	2026-07-06 14:51:58
20260603120000	2026-07-06 14:51:58
20260605120000	2026-07-06 14:51:58
20260606110000	2026-07-06 14:51:58
20260616120000	2026-07-06 14:51:58
20260624120000	2026-07-06 14:51:58
20260626120000	2026-07-06 14:51:59
20260706120000	2026-07-07 07:31:14
20260707120000	2026-07-28 07:21:15
20260709120000	2026-07-28 07:21:15
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-07-06 14:52:26.067586
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-07-06 14:52:26.079023
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-07-06 14:52:26.086528
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-07-06 14:52:26.102357
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-07-06 14:52:26.113474
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-07-06 14:52:26.120382
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-07-06 14:52:26.127799
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-07-06 14:52:26.136058
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-07-06 14:52:26.143179
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-07-06 14:52:26.150361
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-07-06 14:52:26.157564
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-07-06 14:52:26.164563
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-07-06 14:52:26.172839
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-07-06 14:52:26.180504
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-07-06 14:52:26.188018
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-07-06 14:52:26.216867
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-07-06 14:52:26.225006
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-07-06 14:52:26.23187
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-07-06 14:52:26.238787
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-07-06 14:52:26.24749
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-07-06 14:52:26.254511
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-07-06 14:52:26.26298
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-07-06 14:52:26.276952
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-07-06 14:52:26.289874
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-07-06 14:52:26.29669
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-07-06 14:52:26.303889
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-07-06 14:52:26.311018
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-07-06 14:52:26.317517
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-07-06 14:52:26.32411
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-07-06 14:52:26.330953
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-07-06 14:52:26.337261
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-07-06 14:52:26.343652
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-07-06 14:52:26.349904
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-07-06 14:52:26.360762
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-07-06 14:52:26.367193
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-07-06 14:52:26.37438
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-07-06 14:52:26.381794
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-07-06 14:52:26.388253
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-07-06 14:52:26.397021
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-07-06 14:52:26.407745
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-07-06 14:52:26.414083
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-07-06 14:52:26.420511
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-07-06 14:52:26.428166
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-07-06 14:52:26.436039
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-07-06 14:52:26.444141
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-07-06 14:52:26.451334
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-07-06 14:52:26.462887
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-07-06 14:52:26.470325
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-07-06 14:52:26.476924
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-07-06 14:52:26.496473
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-07-06 14:52:26.503734
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-07-06 14:52:26.521946
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-07-06 14:52:26.524341
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-07-06 14:52:26.537391
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-07-06 14:52:26.54149
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-07-06 14:52:26.543955
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-07-06 14:52:26.551467
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-07-06 14:52:26.559424
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-07-06 14:52:26.569309
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-07-06 14:52:26.576978
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-07-06 14:52:26.584032
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: ActivityLog ActivityLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ActivityLog"
    ADD CONSTRAINT "ActivityLog_pkey" PRIMARY KEY (id);


--
-- Name: BudgetLine BudgetLine_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BudgetLine"
    ADD CONSTRAINT "BudgetLine_pkey" PRIMARY KEY (id);


--
-- Name: Campaign Campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "Campaign_pkey" PRIMARY KEY (id);


--
-- Name: ChatConversation ChatConversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatConversation"
    ADD CONSTRAINT "ChatConversation_pkey" PRIMARY KEY (id);


--
-- Name: ChatMessage ChatMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_pkey" PRIMARY KEY (id);


--
-- Name: Contact Contact_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT "Contact_pkey" PRIMARY KEY (id);


--
-- Name: DigitalTags DigitalTags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DigitalTags"
    ADD CONSTRAINT "DigitalTags_pkey" PRIMARY KEY (id);


--
-- Name: EquipmentBooking EquipmentBooking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EquipmentBooking"
    ADD CONSTRAINT "EquipmentBooking_pkey" PRIMARY KEY (id);


--
-- Name: Equipment Equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Equipment"
    ADD CONSTRAINT "Equipment_pkey" PRIMARY KEY (id);


--
-- Name: FixedExpense FixedExpense_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FixedExpense"
    ADD CONSTRAINT "FixedExpense_pkey" PRIMARY KEY (id);


--
-- Name: GameChallenge GameChallenge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GameChallenge"
    ADD CONSTRAINT "GameChallenge_pkey" PRIMARY KEY (id);


--
-- Name: GameSession GameSession_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GameSession"
    ADD CONSTRAINT "GameSession_pkey" PRIMARY KEY (id);


--
-- Name: OneOffExpense OneOffExpense_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OneOffExpense"
    ADD CONSTRAINT "OneOffExpense_pkey" PRIMARY KEY (id);


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: PushSubscription PushSubscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PushSubscription"
    ADD CONSTRAINT "PushSubscription_pkey" PRIMARY KEY (id);


--
-- Name: SocialPost SocialPost_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SocialPost"
    ADD CONSTRAINT "SocialPost_pkey" PRIMARY KEY (id);


--
-- Name: Task Task_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: BudgetLine_site_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "BudgetLine_site_key" ON public."BudgetLine" USING btree (site);


--
-- Name: GameChallenge_fromUserId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "GameChallenge_fromUserId_status_idx" ON public."GameChallenge" USING btree ("fromUserId", status);


--
-- Name: GameChallenge_toUserId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "GameChallenge_toUserId_status_idx" ON public."GameChallenge" USING btree ("toUserId", status);


--
-- Name: GameSession_player1Id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "GameSession_player1Id_status_idx" ON public."GameSession" USING btree ("player1Id", status);


--
-- Name: GameSession_player2Id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "GameSession_player2Id_status_idx" ON public."GameSession" USING btree ("player2Id", status);


--
-- Name: GameSession_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "GameSession_status_idx" ON public."GameSession" USING btree (status);


--
-- Name: PushSubscription_endpoint_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PushSubscription_endpoint_key" ON public."PushSubscription" USING btree (endpoint);


--
-- Name: PushSubscription_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PushSubscription_userId_idx" ON public."PushSubscription" USING btree ("userId");


--
-- Name: User_loginId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_loginId_key" ON public."User" USING btree ("loginId");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: ChatMessage ChatMessage_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatMessage"
    ADD CONSTRAINT "ChatMessage_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."ChatConversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EquipmentBooking EquipmentBooking_equipmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EquipmentBooking"
    ADD CONSTRAINT "EquipmentBooking_equipmentId_fkey" FOREIGN KEY ("equipmentId") REFERENCES public."Equipment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PushSubscription PushSubscription_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PushSubscription"
    ADD CONSTRAINT "PushSubscription_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Task Task_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


--
-- PostgreSQL database dump complete
--

\unrestrict nrSJjLQGb5xgRvqDsaWwKT1CeHj6o7BY1IpuNVupkqCAvyRVaWUwuJ0l1J10nSE

